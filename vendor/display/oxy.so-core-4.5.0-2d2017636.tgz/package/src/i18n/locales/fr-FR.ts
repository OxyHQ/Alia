const dict = {
  signin: {
    title: 'Se connecter',
    subtitle: 'Utilisez votre compte Oxy',
    addAccountTitle: 'Ajouter un autre compte',
    addAccountSubtitle: 'Se connecter avec un autre compte',
    actions: {
      continue: 'Continuer',
      back: 'Retour',
    },
    createAccountLink: 'Nouveau sur Oxy ? Créez un compte',
    status: {
      signingIn: 'Connexion…',
    },
    subtitleToApp: 'pour continuer vers {{app}}',
    orContinueWith: 'ou continuer avec',
    qr: {
      caption: 'Scannez avec Commons pour vous connecter',
      renew: 'Afficher un nouveau code',
    },
    errors: {
      rateLimited: 'Trop de tentatives. Réessayez dans {{seconds}} s.',
      invalidCredentials: "Le nom d'utilisateur, l'e-mail ou le mot de passe est incorrect.",
      codeInvalid: "Ce code n'est pas bon, ou il a expiré.",
      requestExpired: 'Cette connexion a expiré. Envoyez un nouvel e-mail.',
      secondFactorInvalid: "Ce code n'est pas bon. Essayez le code actuel.",
      originNotAllowed: "La connexion n'est pas disponible ici.",
      generic: 'Un problème est survenu. Veuillez réessayer.',
      notConfigured: "La connexion n'est pas disponible",
      notConfiguredDescription:
        "{{app}} n'est pas encore configurée pour la connexion. Contactez le développeur de l'application.",
      failed: 'Impossible de lancer la connexion',
      failedDescription: 'Un problème est survenu. Veuillez réessayer.',
    },
    chooser: {
      subtitleToApp: 'pour continuer vers {{app}}',
      title: 'Choisissez un compte',
      subtitle: "Continuez avec l'un de vos comptes, ou utilisez-en un autre.",
      useAnother: 'Utiliser un autre compte',
      continueAs: 'Continuer en tant que {{name}}',
    },
    terms: {
      before: 'En continuant, vous acceptez nos',
      termsLink: 'Conditions d’utilisation',
      and: 'et notre',
      privacyLink: 'Politique de confidentialité',
    },
    noAccount: 'Pas encore de compte ?',
    createAccount: 'Créer un compte',
    identifier: {
      label: "E-mail ou nom d'utilisateur",
      placeholder: 'vous@exemple.com',
      required: "Saisissez votre e-mail ou votre nom d'utilisateur.",
    },
    checkEmail: {
      title: 'Consultez vos e-mails',
      description:
        'Si un compte correspond à {{identifier}}, nous lui avons envoyé un code et un lien de connexion.',
      codeLabel: 'Code',
      codeHint: "Saisissez le code de l'e-mail, ou ouvrez son lien dans ce navigateur.",
      codeHasLetters: 'Votre code contient des lettres ?',
      codeDigitsOnly: 'Votre code ne contient que des chiffres ?',
      resend: 'Envoyer un nouvel e-mail',
      resendIn: 'Envoyer un nouvel e-mail dans {{seconds}} s',
      resent: 'Nous avons envoyé un nouvel e-mail.',
      retryLater:
        'Nous avons déjà envoyé plusieurs e-mails. Attendez quelques minutes et réessayez.',
      usePassword: 'Utiliser plutôt votre mot de passe',
      differentAccount: 'Utiliser un autre compte',
    },
    password: {
      title: 'Saisissez votre mot de passe',
      label: 'Mot de passe',
      required: 'Saisissez votre mot de passe.',
      forgot: 'Oublié ? Recevez un code par e-mail',
    },
    secondFactor: {
      title: 'Validation en deux étapes',
      description: "Saisissez le code de votre application d'authentification.",
      backupDescription:
        "Saisissez l'un de vos codes de secours. Chacun ne fonctionne qu'une fois.",
      label: "Code d'authentification",
      backupLabel: 'Code de secours',
      useBackup: 'Utiliser un code de secours',
      useAuthenticator: "Utiliser votre application d'authentification",
    },
    link: {
      approvedTitle: 'Vous êtes connecté',
      approvedDescription:
        "Revenez à l'application où vous avez demandé à vous connecter : elle continue toute seule. Vous pouvez fermer cet onglet.",
      otherDeviceTitle: 'Ouvrez le lien dans le même navigateur',
      otherDeviceDescription:
        "Ce lien ne fonctionne que dans le navigateur où vous avez demandé à vous connecter. Ouvrez-le là-bas, ou saisissez le code de l'e-mail dans l'application.",
      invalidTitle: 'Ce lien ne peut pas être utilisé',
      invalidDescription:
        "Il a expiré ou a déjà été utilisé. Demandez un nouvel e-mail dans l'application, ou saisissez le code du plus récent.",
    },
  },
  signup: {
    title: 'Créez votre compte',
    subtitle: "Choisissez votre nom d'utilisateur. Nous confirmerons ensuite votre e-mail.",
    createInCommons: 'La créer plutôt dans Commons',
    backToSignInLink: 'Vous avez déjà un compte ? Connectez-vous',
    username: {
      label: "Nom d'utilisateur",
      placeholder: 'votrenom',
      required: "Choisissez un nom d'utilisateur.",
      taken: "Ce nom d'utilisateur est déjà pris.",
    },
    email: {
      title: 'Quelle est votre adresse e-mail ?',
      subtitle:
        "Elle sert à vous connecter : nous vous envoyons un code à chaque fois. Personne d'autre ne la voit.",
      label: 'E-mail',
      placeholder: 'vous@exemple.com',
      invalid: 'Saisissez une adresse e-mail valide.',
    },
    commonsSubtitle: 'Ou créez votre identité dans Commons, et gardez votre propre clé.',
    laterNote:
      "Vous pourrez ajouter un mot de passe ou une application d'authentification plus tard, dans les paramètres de sécurité de votre compte.",
  },
  accountSwitcher: {
    loading: 'Chargement des comptes...',
    qrHeadline: 'Connectez-vous avec votre identité Oxy',
    signInWithOxy: 'Se connecter avec Oxy',
    signUpWithOxy: "S'inscrire avec Oxy",
    getCommons: 'Obtenir Commons',
    commonsNotInstalled:
      "Pas de Commons ? Téléchargez l'app pour vous connecter avec votre Oxy ID.",
    showQrAnyway: "J'ai Commons sur un autre appareil",
    switchWhileSignedInAs: 'Changer de compte, connecté en tant que {{name}}',
    manageOnDevice: 'Gérer les comptes sur cet appareil',
    continueWithOxy: 'Continuer avec Oxy',
    havingTrouble: 'Un problème ?',
    progress: {
      preparing: 'Préparation de la demande',
      awaitingApproval: "En attente d'approbation",
      scanWithCommons: 'Scannez avec Commons sur votre téléphone',
      continueInCommons: 'Continuez dans Commons',
      checkCommons: 'Consultez Commons sur votre téléphone',
      openedInCommons: 'Ouvert dans Commons',
      confirming: "Confirmation de l'identité",
      confirmed: 'Identité confirmée',
    },
    signInFailures: {
      denied: 'La connexion a été refusée dans Commons.',
      expired: 'La demande de connexion a expiré. Veuillez réessayer.',
      network: 'Impossible de joindre Oxy. Vérifiez votre connexion et réessayez.',
      notConfigured: "Cette app n'est pas encore configurée pour la connexion.",
      unsupportedFlow: 'Cette connexion ne peut pas être finalisée ici.',
      claimFailed:
        "La connexion a été approuvée, mais nous n'avons pas pu la finaliser. Veuillez réessayer.",
      generic: 'La connexion a échoué. Veuillez réessayer.',
    },
    linkOpenFailed: "Impossible d'ouvrir le lien. Veuillez réessayer.",
  },
  common: {
    stepOf: 'Étape {{step}} sur {{total}}',
    actions: {
      back: 'Retour',
      continue: 'Continuer',
      next: 'Suivant',
      getStarted: 'Commencer',
      createAccount: 'Créer un compte',
      signIn: 'Se connecter',
      verify: 'Vérifier',
      resetPassword: 'Réinitialiser le mot de passe',
      signedOut: 'Déconnecté',
      close: 'Fermer',
      tryAgain: 'Réessayer',
    },
    links: {
      recoverAccount: 'Récupérer votre compte',
      signUp: "S'inscrire",
    },
    labels: {
      username: "Nom d'utilisateur",
      email: 'Email',
      password: 'Mot de passe',
      confirmPassword: 'Confirmer le mot de passe',
    },
    revoke: 'Revoke',
    errors: {
      signOutAllFailed:
        'Un problème est survenu lors de la déconnexion de tous les comptes. Veuillez réessayer.',
    },
  },
  notifications: {
    title: 'Notifications',
    subtitle: 'Manage push, email, and security alerts',
    updateError: 'Failed to update notification preferences',
    sections: {
      channels: 'Channels',
      alerts: 'Alerts',
      marketing: 'Marketing',
    },
    items: {
      push: {
        title: 'Push notifications',
        subtitle: 'Real-time alerts on your devices',
      },
      emailDigest: {
        title: 'Email digest',
        subtitle: 'Periodic summary of your account activity',
      },
      securityAlerts: {
        title: 'Security alerts',
        subtitle: 'Sign-ins, recovery codes, and key changes',
      },
      marketingEmails: {
        title: 'Marketing emails',
        subtitle: 'Product news and occasional offers',
      },
    },
  },
  preferences: {
    title: 'Preferences',
    subtitle: 'Theme, motion, and regional settings',
    sections: {
      appearance: 'Appearance',
      language: 'Language',
      region: 'Region',
    },
    theme: {
      light: 'Light',
      dark: 'Dark',
      system: 'System default',
    },
    items: {
      theme: {
        title: 'Theme',
      },
      reduceMotion: {
        title: 'Reduce motion',
        subtitle: 'Minimise animations across Oxy apps',
        systemOn: 'Following system: reduce motion is on',
      },
      language: {
        title: 'Language',
      },
      timezone: {
        title: 'Timezone',
        unknown: 'Unable to detect timezone',
      },
      about: {
        title: 'About preferences',
        subtitle: 'Preferences sync across every Oxy app you sign into',
      },
    },
  },
  connectedApps: {
    title: 'Connected apps',
    subtitle: 'Manage third-party app access',
    empty: {
      title: 'No connected apps',
      subtitle: 'Apps you authorize to sign in with your Oxy account will appear here',
    },
    item: {
      granted: 'Accordé {{relative}}',
      lastUsed: 'Last used {{relative}}',
    },
    confirm: {
      title: 'Revoke access',
      message: "Revoke {{name}}'s access to your Oxy account?",
    },
    toasts: {
      revoked: 'Revoked access for {{name}}',
      revokeFailed: 'Failed to revoke access',
    },
  },
  accountMenu: {
    label: 'Menu du compte',
    manage: 'Gérer votre compte Oxy',
    viewProfile: 'Voir le profil',
    addAnother: 'Ajouter un autre compte',
    signOutAll: 'Se déconnecter de tous les comptes',
    open: 'Menu du compte',
    openHint: 'Ouvre le menu du compte',
    openWithUser: 'Menu du compte de {{name}}',
    switching: 'Changement de compte…',
    signOutAccount: 'Déconnecter {{name}}',
    greeting: 'Bonjour, {{name}} !',
    switchAccount: 'Changer de compte',
    storage: {
      title: 'Stockage Oxy',
      usage: '{{used}} sur {{total}} utilisés',
      used: 'Utilisé',
      free: 'Libre',
      unavailable: "Détails d'utilisation indisponibles",
      upgrade: "Améliorer l'offre",
      manage: 'Gérer le stockage',
    },
    data: 'Vos données dans Oxy',
    settings: 'Paramètres Oxy',
    help: 'Aide et commentaires',
    signOut: 'Se déconnecter',
    privacy: 'Politique de confidentialité',
    terms: "Conditions d'utilisation",
  },
  emailCode: {
    title: 'Consultez vos e-mails',
    sentTo: 'Nous avons envoyé un code à 6 chiffres à {{email}}.',
    label: 'Code',
    resend: 'Envoyer un nouveau code',
    resent: 'Nous avons envoyé un nouveau code.',
    changeEmail: 'Utiliser un autre e-mail',
    errors: {
      codeInvalid: "Ce code n'est pas bon, ou il a expiré.",
      tooManyAttempts: 'Trop de codes erronés. Demandez-en un nouveau.',
      expired: 'Trop de temps a passé. Recommencez.',
      unavailable: "Oxy ne peut pas envoyer d'e-mails pour le moment. Réessayez plus tard.",
      rateLimited: 'Trop de codes. Réessayez plus tard.',
    },
  },
  deleteAccount: {
    keyless: {
      subtitle:
        "@{{username}} et tout son contenu sont supprimés définitivement. Saisissez votre nom d'utilisateur, puis confirmez avec un code que nous vous envoyons par e-mail.",
      action: 'Supprimer le compte',
      done: 'Votre compte est supprimé.',
      doneDescription: 'Vous avez été déconnecté.',
      keyed:
        'Ce compte utilise Commons : supprimez-le dans Oxy Commons, Réglages > Supprimer le compte, avec sa clé.',
    },
    handoff: {
      elsewhereMessage:
        "La suppression de votre compte nécessite votre clé d'identité, et elle n'est pas sur cet appareil. Ouvrez Oxy Commons sur l'appareil qui la détient et allez dans Réglages > Supprimer le compte.",
    },
  },
  linkCommons: {
    title: 'Associer Commons',
    subtitle:
      "Gardez votre propre clé : associez Commons et ce compte n'appartient qu'à vous. Son e-mail est supprimé, et votre phrase de récupération dans Commons vous permet d'y revenir.",
    scan: 'Sur votre téléphone, ouvrez Commons, choisissez « J’ai un compte Oxy sur le web » et scannez ce code.',
    waiting: 'En attente de Commons…',
    compareTitle: 'Vérifiez le code',
    compare: 'Commons affiche le même code. Sinon, annulez.',
    confirm: 'Oui, associer Commons',
    cancel: 'Annuler',
    doneTitle: 'Commons est associé',
    done: "Ce compte est désormais en autogarde. Son e-mail a été supprimé : votre phrase de récupération dans Commons vous permet d'y revenir.",
    already: 'Ce compte utilise déjà Commons.',
    expired: 'Ce code a expiré.',
    renew: 'Afficher un nouveau code',
    failed: "Commons n'a pas pu être associé. Réessayez.",
    confirmTitle: "Confirmez l'association",
    confirmDescription:
      "Pour terminer, confirmez qu'il s'agit bien de vous avec un code que nous vous envoyons par e-mail.",
    row: 'Gardez votre propre clé avec Commons',
  },
  reauth: {
    title: "Confirmez qu'il s'agit bien de vous",
    emailDescription:
      'Nous allons envoyer un code à votre adresse e-mail pour confirmer ce changement.',
    sendCode: 'Envoyer le code',
    codeSent: 'Nous avons envoyé un code à 6 chiffres à votre adresse e-mail.',
    codeLabel: 'Code reçu par e-mail',
    passwordLabel: 'Mot de passe actuel',
    usePassword: 'Utiliser plutôt votre mot de passe',
    useEmail: 'Recevoir plutôt un code par e-mail',
    errors: {
      invalid: "Cela n'a pas fonctionné. Vérifiez votre saisie et réessayez.",
      totpRequired: "Saisissez aussi le code de votre application d'authentification.",
    },
  },
  signInSecurity: {
    password: {
      title: 'Mot de passe',
      setTitle: 'Définir un mot de passe',
      changeTitle: 'Modifier votre mot de passe',
      description:
        "Connectez-vous avec votre mot de passe plutôt qu'avec un code par e-mail. Utilisez au moins {{min}} caractères.",
      newLabel: 'Nouveau mot de passe',
      repeatLabel: 'Confirmez le mot de passe',
      tooShort: 'Utilisez au moins {{min}} caractères.',
      mismatch: 'Les mots de passe ne correspondent pas.',
      signOutOthers: 'Se déconnecter partout ailleurs',
      save: 'Enregistrer le mot de passe',
      saved: 'Votre mot de passe est enregistré.',
      row: 'Facultatif : se connecter avec un mot de passe',
    },
    totp: {
      title: "Application d'authentification",
      description:
        "Après votre code par e-mail ou votre mot de passe, Oxy vous demande aussi un code provenant d'une application comme Google Authenticator ou 1Password.",
      setUp: 'Configurer',
      scan: "Scannez ce code QR avec votre application d'authentification, ou saisissez la clé de configuration.",
      secretLabel: 'Clé de configuration',
      codeLabel: "Code de l'application",
      enable: 'Activer',
      enabled: "L'application d'authentification est activée.",
      disable: "Désactiver l'application d'authentification",
      disabled: "L'application d'authentification est désactivée.",
      on: 'Activée',
      off: 'Désactivée',
      backupTitle: 'Enregistrez vos codes de secours',
      backupDescription:
        'Si vous perdez votre téléphone, chaque code vous connecte une fois. Conservez-les en lieu sûr : ils ne seront plus affichés.',
      copy: 'Copier les codes',
      copied: 'Codes de secours copiés.',
      savedThem: 'Je les ai enregistrés',
      regenerate: 'Obtenir de nouveaux codes de secours',
      regenerateDescription: 'Vos anciens codes de secours ne fonctionneront plus.',
      remaining: '{{count}} codes de secours restants',
      row: 'Une deuxième étape à la connexion',
    },
  },
};
export default dict;
