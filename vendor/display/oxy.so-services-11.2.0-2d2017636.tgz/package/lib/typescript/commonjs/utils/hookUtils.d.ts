/**
 * React hook utilities for common patterns and state management
 */
/**
 * Hook for managing async operations with loading, error, and data states
 */
export declare function useAsync<T>(asyncFn: () => Promise<T>, deps?: React.DependencyList): {
    data: T | null;
    loading: boolean;
    error: Error | null;
    execute: () => Promise<T>;
};
/**
 * Hook for managing async operations that execute on mount
 */
export declare function useAsyncEffect<T>(asyncFn: () => Promise<T>, deps?: React.DependencyList): {
    data: T | null;
    loading: boolean;
    error: Error | null;
};
/**
 * Hook for debounced values
 */
export declare function useDebounce<T>(value: T, delay: number): T;
/**
 * Hook for throttled values
 */
export declare function useThrottle<T>(value: T, delay: number): T;
/**
 * Hook for previous value
 */
export declare function usePrevious<T>(value: T): T | undefined;
/**
 * Hook for boolean state with toggle
 */
export declare function useToggle(initialValue?: boolean): {
    value: boolean;
    toggle: () => void;
    setTrue: () => void;
    setFalse: () => void;
    setValue: import("react").Dispatch<import("react").SetStateAction<boolean>>;
};
/**
 * Hook for counter state
 */
export declare function useCounter(initialValue?: number): {
    count: number;
    increment: () => void;
    decrement: () => void;
    reset: () => void;
    setValue: (value: number) => void;
};
/**
 * Hook for local storage (platform-safe)
 */
export declare function useLocalStorage<T>(key: string, initialValue: T): readonly [T, (value: T | ((val: T) => T)) => void];
/**
 * Hook for session storage (platform-safe)
 */
export declare function useSessionStorage<T>(key: string, initialValue: T): readonly [T, (value: T | ((val: T) => T)) => void];
/**
 * Hook for window size (platform-safe)
 */
export declare function useWindowSize(): {
    width: number;
    height: number;
};
/**
 * Hook for scroll position (platform-safe)
 */
export declare function useScrollPosition(): number;
/**
 * Hook for online/offline status (platform-safe)
 */
export declare function useOnlineStatus(): boolean;
/**
 * Hook for media queries (platform-safe)
 */
export declare function useMediaQuery(query: string): boolean;
/**
 * Hook for keyboard events (platform-safe)
 */
export declare function useKeyPress(targetKey: string): boolean;
/**
 * Hook for click outside detection (platform-safe)
 */
export declare function useClickOutside(ref: React.RefObject<HTMLElement>, handler: () => void): void;
/**
 * Hook for form validation
 */
export declare function useFormValidation<T extends Record<string, unknown>>(initialValues: T, validationSchema: (values: T) => Partial<Record<keyof T, string>>): {
    values: T;
    errors: Partial<Record<keyof T, string>>;
    touched: Partial<Record<keyof T, boolean>>;
    isValid: boolean;
    setValue: (field: keyof T, value: T[keyof T]) => void;
    setTouchedField: (field: keyof T) => void;
    setValues: import("react").Dispatch<import("react").SetStateAction<T>>;
    setErrors: import("react").Dispatch<import("react").SetStateAction<Partial<Record<keyof T, string>>>>;
    setTouched: import("react").Dispatch<import("react").SetStateAction<Partial<Record<keyof T, boolean>>>>;
};
//# sourceMappingURL=hookUtils.d.ts.map