/**
 * The ONE place `@oxy.so/services` touches `expo-notifications`.
 *
 * Every Oxy app that receives push needs the identical adapter — native-only,
 * dynamically imported, reading the OS permission and minting an EXPO push
 * token — so it lives here instead of being copied into each app. The
 * bearer-authenticated transport (`registerPushToken` / `unregisterPushToken`)
 * already lives in `@oxy.so/core`; core may never import an `expo-*` module, and
 * this adapter is the Expo-side half that closes that gap.
 *
 * ## Reached through its OWN entry point, never the root barrel
 *
 * ```ts
 * import { getExpoPushToken } from '@oxy.so/services/notifications';
 * ```
 *
 * This is the only module in the package that depends on peers an app which
 * does not use push genuinely never installs, and a barrel export would put it
 * in EVERY consumer's import graph. `tsc` resolves the specifier of an
 * `import()` even when the call is lazy and inside a try/catch, so a barrel
 * export turned "optional peer" into a hard requirement: consumers with no
 * interest in push failed to type-check with TS2307. The subpath is what keeps
 * the optionality honest — see the note in `src/index.ts`.
 *
 * Metro resolves a dynamic `import()` at build time too, so being dynamic is not
 * enough: it bundles without the package only because each `import()` below is
 * a direct statement of a `try` block, the one shape Metro marks as an OPTIONAL
 * dependency (the `catch` then takes over at runtime). Moved out of the `try`,
 * or nested one block deeper inside it, it fails the consumer's build exactly
 * like a static import — which is what `clipboard.native.ts` once did.
 * `__tests__/packaging/optionalPeerLoads.test.ts` holds every optional peer to
 * that shape.
 *
 * ## Native-only by construction
 *
 * Every entry point resolves its null/no-op result from `Platform.OS` BEFORE the
 * dynamic `import()`, so a web bundle never requests `expo-notifications` at all.
 * `expo-notifications` and `expo-constants` are OPTIONAL peer dependencies: an
 * app that does not use push never installs them, and a build without them
 * degrades to "notifications unavailable" rather than throwing at
 * module-evaluation time.
 *
 * ## The token is an EXPO push token — never a raw device token
 *
 * {@link getExpoPushToken} calls `getExpoPushTokenAsync()`, which returns the
 * `ExponentPushToken[…]` handle Expo's push service delivers through — the only
 * form it accepts. `getDevicePushTokenAsync()` — the raw APNs/FCM token — is
 * deliberately NOT used anywhere: registering one of those looks entirely
 * successful (the row is stored, the endpoint returns 200) and then every push
 * silently fails at delivery time. `@oxy.so/core`'s `registerPushToken` rejects a
 * raw device token before sending, and this module is the reason it never has to.
 *
 * ## The payload is untrusted
 *
 * Nothing here surfaces a notification's `title` / `body` / `subtitle`. The only
 * payload that leaves this module is the raw `content.data` — the routing keys —
 * typed `unknown`, so a caller has to validate it before acting on it and there
 * is no exported shape that invites rendering push-delivered text. The
 * foreground handler likewise answers with a visibility verdict and nothing else.
 */
import type { PushTokenPlatform } from '@oxy.so/core';
/**
 * The platform tag the push-token registry stores this installation under, or
 * `null` on a platform Oxy does not deliver push to.
 *
 * Synchronous and import-free — the answer is a property of the bundle, not of
 * any native module.
 *
 * Web is `null` on purpose: the registry accepts a `web` platform, but browser
 * push needs a VAPID key + service-worker subscription no Oxy app has wired, so
 * there is no token to register and claiming otherwise would store a row nothing
 * can ever deliver to.
 */
export declare function pushTokenPlatform(): PushTokenPlatform | null;
/**
 * Whether the OS notification permission is ALREADY granted.
 *
 * Never prompts, so an app can re-check on every cold boot without ever asking
 * the user twice. Use {@link requestNotificationPermission} for the one place
 * that is allowed to show the system dialog.
 */
export declare function hasNotificationPermission(): Promise<boolean>;
/**
 * Ensure the OS notification permission, prompting at most once.
 *
 * An installation that already answered the system dialog is never asked again:
 * an already-granted permission resolves `true` without a second dialog, and a
 * denial with `canAskAgain: false` resolves `false` without issuing a request
 * the OS would silently ignore.
 *
 * @returns Whether notifications are granted once this call is done.
 */
export declare function requestNotificationPermission(): Promise<boolean>;
/**
 * This installation's Expo push token (`ExponentPushToken[…]`), or `null` when
 * one cannot be minted.
 *
 * Deliberately `getExpoPushTokenAsync` — see the module header for why the raw
 * device-token variant is never used.
 *
 * Every `null` is logged with the reason it happened. A missing EAS project id
 * in particular is a BUILD MISCONFIGURATION, not a user state: no token can ever
 * be minted, so push is off for every install of that build until the config is
 * fixed. It is reported as such rather than blending into the
 * indistinguishable "permission denied / offline" bucket.
 */
export declare function getExpoPushToken(): Promise<string | null>;
/**
 * Take the payload of the notification that COLD-LAUNCHED the app, if any.
 *
 * "Take" is literal: the response is cleared from `expo-notifications` once
 * read, so a listener attached later in the same launch is not handed the same
 * tap again. Clearing is best-effort across OS/module versions, so a caller that
 * must not act twice still needs its own idempotency ledger.
 *
 * @returns The raw, untrusted `content.data` of the launching notification, or
 *   `null`. Parsing/validation is the caller's job.
 */
export declare function takeLaunchNotificationData(): Promise<unknown>;
/**
 * What the OS should do with a notification that arrives while the app is
 * FOREGROUNDED.
 *
 * `'suppress'` is `expo-notifications`' own default for a foregrounded app, so a
 * decision function that only ever returns `'show'` for the payloads it
 * recognises leaves every other notification exactly as it behaves today.
 */
export type ForegroundPresentation = 'show' | 'suppress';
/** How prominently Android surfaces a channel's notifications. */
export type NotificationChannelImportance = 'default' | 'high';
/** An Android notification channel this app delivers on. */
export interface NotificationChannelSpec {
    /**
     * The channel id. It MUST match the id the sender attaches: Android 8+ drops
     * a notification whose channel the app has not created, silently and with no
     * error on either side, which is the hardest push symptom there is to
     * diagnose. Ids that cross the wire belong in `@oxy.so/contracts`, not in a
     * string typed on both sides.
     */
    id: string;
    /** User-visible channel name — app copy, so the caller localizes it. */
    name: string;
    /** User-visible description shown in Android's notification settings. */
    description?: string;
    importance?: NotificationChannelImportance;
}
/**
 * Create (or update) an Android notification channel.
 *
 * A no-op everywhere but Android: iOS has no channels, and web never loads the
 * native module. Call it BEFORE registering a push token, so the very first
 * notification the server sends already has a channel to land on.
 *
 * Failure is non-fatal and logged: a missing channel costs visibility, and
 * refusing to register a token over it would cost the feature entirely.
 *
 * @returns Whether the channel was actually created (`false` off Android, or
 *   when the native module is unavailable, or when creation failed).
 */
export declare function ensureNotificationChannel(spec: NotificationChannelSpec): Promise<boolean>;
/**
 * Install the ONE process-wide handler that decides whether an incoming
 * notification is shown while the app is in the FOREGROUND.
 *
 * Without a handler, `expo-notifications` shows nothing at all while the app is
 * open — which is exactly when a time-critical notification (a "Sign in with
 * Oxy" approval request, say) matters most, because the user is already holding
 * the phone.
 *
 * The handler ONLY decides visibility. It never navigates, never acts on the
 * notification, and never reads the payload for display — `decide` is handed the
 * raw, untrusted `content.data` and may answer nothing but `'show'` /
 * `'suppress'`. Acting on a notification stays with a TAP, routed by
 * {@link subscribeToNotificationResponses}. No notification actions/categories
 * are registered here, so the banner cannot carry an action button.
 *
 * The one-shot latch is set BEFORE the first `await`, so concurrent callers
 * cannot both reach `setNotificationHandler`.
 *
 * @param decide - Maps the raw, untrusted payload to a presentation verdict.
 *   Must not throw; a throw is reported by the OS as a handling error and the
 *   notification is dropped.
 * @returns Whether a handler was installed by THIS call (`false` on a repeat
 *   call, on web, or when the native module is unavailable).
 */
export declare function installForegroundNotificationHandler(decide: (data: unknown) => ForegroundPresentation): Promise<boolean>;
/**
 * Subscribe to notification TAPS (responses) while the app is running.
 *
 * @param listener - Receives the raw, untrusted `content.data` of the tapped
 *   notification. Parsing/validation is the caller's job.
 * @returns An unsubscribe function. Safe to call even if the subscription could
 *   not be established.
 */
export declare function subscribeToNotificationResponses(listener: (data: unknown) => void): Promise<() => void>;
//# sourceMappingURL=deviceNotifications.d.ts.map