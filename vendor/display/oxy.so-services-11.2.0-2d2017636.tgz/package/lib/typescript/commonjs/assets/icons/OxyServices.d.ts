import type React from 'react';
import type { ViewStyle } from 'react-native';
interface OxyLogoProps {
    width?: number;
    height?: number;
    style?: ViewStyle;
    /**
     * Primary fill color for the logo
     * If not provided, the theme's primary color will be used
     */
    fillColor?: string;
    /**
     * Secondary fill color for the inner glow effect
     * If not provided, a lighter shade of the fillColor will be used
     */
    secondaryFillColor?: string;
}
/**
 * SVG logo component for Oxy
 * This component renders the Oxy logo as an SVG and uses theme colors by default
 */
export declare const OxyServicesLogo: React.FC<OxyLogoProps>;
export default OxyServicesLogo;
//# sourceMappingURL=OxyServices.d.ts.map