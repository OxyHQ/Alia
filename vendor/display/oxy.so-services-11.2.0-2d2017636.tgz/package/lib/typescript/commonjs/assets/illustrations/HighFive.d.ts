import type React from 'react';
interface HighFiveProps {
    width?: number;
    height?: number;
}
declare const HighFive: React.FC<HighFiveProps>;
export default HighFive;
//# sourceMappingURL=HighFive.d.ts.map