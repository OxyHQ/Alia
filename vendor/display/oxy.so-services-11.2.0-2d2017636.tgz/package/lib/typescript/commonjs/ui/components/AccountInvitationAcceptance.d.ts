/** The link never grants access on navigation, preview, sign-in or account switching. */
export declare function AccountInvitationAcceptance({ token }: {
    token: string;
}): import("react").JSX.Element;
//# sourceMappingURL=AccountInvitationAcceptance.d.ts.map