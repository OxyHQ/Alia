/**
 * The follow button's product rules, without the button.
 *
 * Pure: no React, no Bloom. `FollowTargetButton` renders them, and an
 * application drawing its own affordance (a chip grid, a compact row) imports
 * them from here — through `@oxy.so/services/ui/client` — without paying for the
 * button's dropdown menu.
 */
import type { FollowApplicationMode } from '@oxy.so/contracts';
/** A timed-follow choice offered in the menu. */
export interface FollowDuration {
    label: string;
    seconds: number;
}
/**
 * Whether an action leaves the target ACTIVE in this application.
 *
 * One table, read by both the primary button and the menu, because the same
 * action reached from two controls once reported differently — and a rule
 * living in two switch statements is a rule that drifts. `Record` rather than
 * a function with a default, so a new action is a compile error instead of a
 * silent `false`.
 */
export declare const FOLLOW_ACTION_LEAVES_ACTIVE: Record<'follow' | 'follow-timed' | 'enable-here' | 'disable-here' | 'unfollow', boolean>;
/** One line in the disclosure menu. */
export interface FollowMenuItem {
    key: string;
    label: string;
    /** What the component should call. Named so the table below stays pure. */
    action: {
        type: 'follow-timed';
        seconds: number;
        durationLabel: string;
    } | {
        type: 'enable-here';
    } | {
        type: 'disable-here';
    } | {
        type: 'unfollow';
    };
}
/**
 * Which choices exist, given the state.
 *
 * Pure and exported because this is the product decision, not a rendering
 * detail: a timed follow is only offered before following, turning it off here
 * is only offered while following, and NEITHER is offered before the server has
 * answered — every one of them addresses a relationship that does not exist
 * yet, so offering them mid-write would mean sending a guessed id.
 */
/**
 * What the main button should do for the current state.
 *
 * Exported because the product rule is not obvious from the label alone: a
 * follow switched off here still reads as "following" globally, so the primary
 * press must re-enable here — not unfollow everywhere.
 */
export declare function resolveFollowPrimaryAction(input: {
    isFollowing: boolean;
    applicationMode: FollowApplicationMode;
}): 'follow' | 'unfollow' | 'enable-here';
export declare function buildFollowMenuItems(input: {
    following: boolean;
    applicationMode: FollowApplicationMode;
    hasRelationship: boolean;
    isPending: boolean;
    durations: FollowDuration[] | false;
    idleVerb: string;
    applicationName: string;
}): FollowMenuItem[];
//# sourceMappingURL=followRules.d.ts.map