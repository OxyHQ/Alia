import type React from 'react';
import type { FileMetadata } from '@oxy.so/core';
import type { useUploadFile } from '../../../hooks/mutations/useAccountMutations';
import { type PendingUploadFile } from '../shared';
/** Aggregate progress across a multi-file upload. */
export interface FileUploadAggregateProgress {
    current: number;
    total: number;
}
/** Dependencies threaded into the upload-state hook from the orchestrator. */
export interface UseFileUploadStateParams {
    targetUserId?: string;
    uploadFileMutation: ReturnType<typeof useUploadFile>;
    defaultVisibility: 'private' | 'public' | 'unlisted';
    selectMode: boolean;
    multiSelect: boolean;
    afterSelect: 'close' | 'back' | 'none';
    onSelect?: (file: FileMetadata) => void;
    /** Forward-navigation picker: see {@link FileManagementScreenProps.onPicked}. */
    onPicked?: (file: FileMetadata) => void;
    goBack?: () => void;
    onClose?: () => void;
    /** When true, the document picker and pre-upload validation accept images only. */
    imagesOnly?: boolean;
    selectedIds: Set<string>;
    setSelectedIds: React.Dispatch<React.SetStateAction<Set<string>>>;
    t: (key: string, vars?: Record<string, string | number>) => string;
}
/** Public surface returned to the orchestrator. */
export interface UseFileUploadStateResult {
    isPickingDocument: boolean;
    pendingFiles: PendingUploadFile[];
    showUploadPreview: boolean;
    /** Whether an upload is in flight (drives the "Uploading…" banner). */
    uploading: boolean;
    /** Aggregate progress across the current upload, or null. */
    uploadProgress: FileUploadAggregateProgress | null;
    handleFileUpload: () => Promise<void>;
    handleConfirmUpload: () => Promise<void>;
    handleCancelUpload: () => void;
    removePendingFile: (id: string) => void;
}
/**
 * Owns the self-contained document-picking + upload-preview state and handlers
 * extracted from FileManagementScreen. Behaviour is preserved verbatim — the
 * orchestrator simply threads in the values these handlers depend on and
 * consumes the returned state/handlers.
 */
export declare const useFileUploadState: ({ targetUserId, uploadFileMutation, defaultVisibility, selectMode, multiSelect, afterSelect, onSelect, onPicked, goBack, onClose, imagesOnly, selectedIds, setSelectedIds, t, }: UseFileUploadStateParams) => UseFileUploadStateResult;
export default useFileUploadState;
//# sourceMappingURL=useFileUploadState.d.ts.map