/**
 * User display name and date formatting utilities.
 *
 * Display-name helpers follow the API contract: prefer `name.displayName` when
 * present, otherwise fall back to the normalized handle via
 * `getNormalizedUserHandle`.
 */
import { type DisplayNameUserShape } from '@oxy.so/core';
/**
 * Formats a date string to a readable format (e.g., "Feb 21, 2025")
 */
export declare const formatDate: (dateString: string | undefined | null | Date) => string;
/**
 * Gets a display name from user data.
 *
 * Prefers API `name.displayName`, then the normalized handle.
 */
export declare const getDisplayName: (user: DisplayNameUserShape | null | undefined) => string;
/**
 * Gets a short display name (first token) for compact UI.
 */
export declare const getShortDisplayName: (user: DisplayNameUserShape | null | undefined) => string;
//# sourceMappingURL=userUtils.d.ts.map