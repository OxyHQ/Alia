/**
 * The "Having trouble?" progressive disclosure (issue #691, Phase 5).
 *
 * The normal sign-in surface presents ONE primary action. Every alternative —
 * scanning a QR from another device, getting Commons,
 * creating an account — lives here, hidden until the user asks for it or the
 * chosen primary route fails.
 *
 * Two renderings:
 *  - `revealed` (the primary route failed, or there IS no primary route): the
 *    alternatives ARE the surface's content now, so they render plainly. There
 *    is nothing left to hide them behind.
 *  - otherwise: a single-item Bloom `Accordion`, whose trigger is the small
 *    "Having trouble?" affordance.
 *
 * The disclosure is CONTROLLED because Bloom 1.0.0's `Accordion` — which
 * replaced the deleted `Collapsible` — takes `value`/`onValueChange` and has no
 * uncontrolled mode. Splitting on `revealed` still matters: it decides whether
 * a disclosure exists at all, so the open state below only ever describes the
 * collapsed rendering.
 */
import type React from 'react';
import type { OxySignInSurfaceAction, Theme, Translate } from './types';
interface TroubleDisclosureProps {
    /** The alternative routes out of the current surface. Always subordinate links. */
    actions: readonly OxySignInSurfaceAction[];
    /**
     * `true` when the primary route could not be carried out (`signIn.routeFailed`)
     * or the surface has no working primary at all (a failed request). The
     * alternatives are shown without asking.
     */
    revealed: boolean;
    theme: Theme;
    t: Translate;
}
declare const TroubleDisclosure: React.FC<TroubleDisclosureProps>;
export default TroubleDisclosure;
//# sourceMappingURL=TroubleDisclosure.d.ts.map