/**
 * The single web entry point for third-party "Sign in with Oxy".
 *
 * Picks the transport (`popup` or `redirect`), drives it, and returns ONE typed
 * result — so callers (`OxySignInButton`, and any RP with its own button) never
 * touch `window.open`, `postMessage`, or the token exchange themselves.
 *
 * Popup mode keeps the relying party mounted: its route, scroll position, and
 * unsaved state survive because the tab never navigates. Redirect mode is the
 * compatibility fallback, and is also where popup mode lands when the browser
 * blocks the window — a blocked popup must still sign the user in, not dead-end.
 *
 * Native is NOT handled here: `openAuthorizeUrlNative` (an in-app auth session)
 * remains the native lane and is untouched by this module.
 */
import { type OxyAuthScreen } from '@oxy.so/core';
import type { OxyServices } from '@oxy.so/core';
import type { OAuthPopupHandle, OAuthSessionCommitInput, WebAuthMode, WebOAuthSignInResult } from './types';
/** Provider-owned wiring for a web sign-in — everything that is not per-press. */
export interface WebOAuthTransportContext {
    /** The provider's `webAuthMode`. */
    mode: WebAuthMode;
    oxyServices: OxyServices;
    /** The app's registered client id; `null` disables third-party sign-in. */
    clientId: string | null;
    /** Authorize endpoint override (local/staging deployments). */
    authorizeBaseUrl?: string;
    /** `sessionMode: 'identity'` — no third-party OAuth lane exists by design. */
    identityBound: boolean;
    /** The provider's session commit funnel. */
    commitSession: (input: OAuthSessionCommitInput) => Promise<void>;
}
/** Per-press inputs for {@link startWebOAuthSignIn}. */
export interface StartWebOAuthSignInOptions {
    /** EXACT registered redirect URI for this application. */
    redirectUri: string;
    /**
     * The popup to drive, when the caller already opened one.
     *
     * - omitted — this call opens the window itself, which is only valid when it
     *   was invoked SYNCHRONOUSLY from the user's click (gesture attribution);
     * - `null` — the caller tried and the browser blocked it: fall back to a
     *   full-page redirect;
     * - a handle — use exactly this window.
     *
     * Callers that must `await` before signing in (resolving the application, for
     * instance) have to open the window in their press handler and pass it here;
     * a window opened after an `await` is silently blocked by every browser.
     */
    popup?: OAuthPopupHandle | null;
    /** Requested scope; defaults to the SDK's standard sign-in scope. */
    scope?: string;
    /**
     * The transport for this press, whatever the provider's `webAuthMode`. An
     * Oxy app's own account dialog asks for `popup`: auth.oxy.so's window over
     * the app, where the browser's shared session lives.
     */
    transport?: WebAuthMode;
    /** The IdP screen a person with no session there lands on. */
    screen?: OxyAuthScreen;
    /** Popup timeout override (ms). */
    timeoutMs?: number;
}
export declare function startWebOAuthSignIn(context: WebOAuthTransportContext, options: StartWebOAuthSignInOptions): Promise<WebOAuthSignInResult>;
//# sourceMappingURL=browserAuthTransport.d.ts.map