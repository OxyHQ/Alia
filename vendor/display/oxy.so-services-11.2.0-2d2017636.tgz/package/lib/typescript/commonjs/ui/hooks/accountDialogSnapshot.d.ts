import type { AccountDialogController, AccountDialogSnapshot } from '@oxy.so/core/session';
/**
 * The snapshot `useSyncExternalStore` reads before a controller exists.
 *
 * `useSyncExternalStore` calls `getSnapshot` several times per commit and
 * compares by identity, so the no-controller answer has to be one constant
 * reference — a fresh object literal loops.
 *
 * It is ONE constant because there were three, byte-identical, in the hook and
 * both dialog surfaces. Adding a field to `AccountDialogSnapshot` broke all
 * three at once and would have gone on doing so; a shared constant makes the
 * compiler point at one place.
 */
export declare const EMPTY_ACCOUNT_DIALOG_SNAPSHOT: AccountDialogSnapshot;
/**
 * Bind a surface to `controller`'s snapshot (the inert one while there is no
 * controller). `getSnapshot` returns a stable reference between changes, so
 * it is `useSyncExternalStore`-safe.
 */
export declare function useAccountDialogSnapshot(controller: AccountDialogController | null): AccountDialogSnapshot;
//# sourceMappingURL=accountDialogSnapshot.d.ts.map