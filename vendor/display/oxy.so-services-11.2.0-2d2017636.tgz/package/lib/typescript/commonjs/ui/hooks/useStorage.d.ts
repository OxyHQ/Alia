import type { ApiError } from '@oxy.so/core';
import { type StorageInterface } from '../utils/storageHelpers';
export interface UseStorageOptions {
    onError?: (error: ApiError) => void;
    logger?: (message: string, error?: unknown) => void;
}
export interface UseStorageResult {
    storage: StorageInterface | null;
    isReady: boolean;
}
/**
 * Simple React hook that initializes platform-appropriate storage.
 * Returns storage instance once ready, or null if initialization failed.
 */
export declare const useStorage: ({ onError, logger }?: UseStorageOptions) => UseStorageResult;
//# sourceMappingURL=useStorage.d.ts.map