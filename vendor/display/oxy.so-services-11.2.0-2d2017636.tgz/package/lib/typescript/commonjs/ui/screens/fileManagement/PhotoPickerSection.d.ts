import React from 'react';
import type { FileMetadata } from '@oxy.so/core';
/**
 * Props for the dedicated photo picker view. Used by FileManagementScreen
 * only when `selectMode + image-only` is active. All callbacks are wired by
 * the parent — this component is purely presentational.
 */
export interface PhotoPickerViewProps {
    photos: FileMetadata[];
    selectedIds: Set<string>;
    multiSelect: boolean;
    maxSelection?: number;
    allowUpload: boolean;
    refreshing: boolean;
    uploading: boolean;
    isPickingDocument: boolean;
    hasMore: boolean;
    loadingMore: boolean;
    /**
     * Initial-load flag. While `true` AND no photos have arrived yet, the picker
     * renders its OWN loading skeleton (placement-aware grid of shimmer tiles)
     * instead of the empty state — so the loading UI matches the picker's shape
     * and container width, not the browse file-manager chrome.
     */
    loading: boolean;
    /** Terminal load failure (nothing cached) — renders a distinct error state. */
    loadError: boolean;
    /** Retry the failed list load (wired to the query's refetch). */
    onRetry: () => void;
    reduceMotion: boolean;
    getThumbUrl: (file: FileMetadata) => string | undefined;
    primaryColor: string;
    isOwner: boolean;
    onTogglePhoto: (photo: FileMetadata) => void;
    onPreviewPhoto: (photo: FileMetadata) => void;
    onUpload: () => void;
    onRefresh: () => void;
    onLoadMore: () => void;
    t: (key: string, vars?: Record<string, string | number>) => string;
}
declare const PhotoPickerView: React.FC<PhotoPickerViewProps>;
export default PhotoPickerView;
//# sourceMappingURL=PhotoPickerSection.d.ts.map