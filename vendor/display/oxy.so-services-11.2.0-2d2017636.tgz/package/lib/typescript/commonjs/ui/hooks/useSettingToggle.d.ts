interface UseSettingToggleOptions {
    /** Initial value of the setting */
    initialValue: boolean;
    /** Function to save the setting to the server */
    onSave: (value: boolean) => Promise<void>;
    /** Success message when saving */
    successMessage?: string;
    /** Error message when save fails */
    errorMessage?: string;
    /** Whether to revert on error (default: true) */
    revertOnError?: boolean;
    /** Whether to show success toast (default: false) */
    showSuccessToast?: boolean;
}
interface UseSettingToggleReturn {
    /** Current value */
    value: boolean;
    /** Whether the setting is being saved */
    isSaving: boolean;
    /** Toggle the setting (optimistic update with revert on error) */
    toggle: () => Promise<void>;
    /** Set the value directly */
    setValue: (value: boolean) => void;
}
/**
 * Hook for handling boolean toggle settings with optimistic updates.
 * Automatically reverts to the previous value if the save fails.
 *
 * @example
 * const { value, toggle, isSaving } = useSettingToggle({
 *   initialValue: user.notificationsEnabled,
 *   onSave: (value) => api.updateNotifications(value),
 *   errorMessage: 'Failed to update notifications',
 * });
 *
 * <Switch value={value} onValueChange={toggle} disabled={isSaving} />
 */
export declare function useSettingToggle(options: UseSettingToggleOptions): UseSettingToggleReturn;
/**
 * Hook for managing multiple toggle settings at once.
 * Useful when you have several related boolean settings.
 */
export declare function useSettingToggles<T extends {
    [K in keyof T]: boolean;
}>(options: {
    initialValues: T;
    onSave: (key: keyof T, value: boolean) => Promise<void>;
    errorMessage?: string | ((key: keyof T) => string);
    revertOnError?: boolean;
}): {
    values: T;
    savingKeys: Set<keyof T>;
    toggle: (key: keyof T) => Promise<void>;
    setValues: (values: Partial<T>) => void;
};
export default useSettingToggle;
//# sourceMappingURL=useSettingToggle.d.ts.map