import type React from 'react';
import type { BaseScreenProps } from '../types/navigation';
/**
 * Create a new account in the unified account graph (an organization, project,
 * or bot). The caller becomes its owner. Optionally nested under a parent
 * account via the `parentAccountId` prop. NOT the cryptographic Commons/DID
 * "identity" — that is a separate concept.
 */
declare const CreateAccountScreen: React.FC<BaseScreenProps>;
export default CreateAccountScreen;
//# sourceMappingURL=CreateAccountScreen.d.ts.map