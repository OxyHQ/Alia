import type React from 'react';
import { type SurfaceControls } from '@oxy.so/bloom/surfaces';
import type { FileMetadata } from '@oxy.so/core';
interface FileDetailsModalProps {
    /** The presenting surface's controls (from `surfaces.present`). */
    surface: SurfaceControls;
    file: FileMetadata;
    onDownload: (fileId: string, filename: string) => void;
    onDelete: (fileId: string, filename: string) => void;
    isOwner: boolean;
}
/**
 * File-detail panel — a rich presented surface (NOT a yes/no confirm): a file's
 * icon + metadata plus download / delete / cancel actions. Each action first
 * dismisses this surface, then runs its handler, so a follow-up delete confirm
 * stacks cleanly above whatever remains. Presented via {@link presentFileDetails}.
 */
export declare const FileDetailsModal: React.FC<FileDetailsModalProps>;
/** Options accepted by {@link presentFileDetails} (everything but `surface`). */
type PresentFileDetailsOptions = Omit<FileDetailsModalProps, 'surface'>;
/** Present the file-detail panel on the shared surface stack. */
export declare function presentFileDetails(options: PresentFileDetailsOptions): void;
export {};
//# sourceMappingURL=FileDetailsModal.d.ts.map