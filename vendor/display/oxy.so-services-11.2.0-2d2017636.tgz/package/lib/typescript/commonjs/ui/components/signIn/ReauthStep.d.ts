/**
 * "Confirm it's you": the fresh proof a sensitive change carries (`reauth`) —
 * a code sent to the account's email for THIS change, or the current password
 * where the change accepts one — plus the authenticator's code (or a backup
 * code) when the account has one. The screen that needs it puts its own fields
 * above (`children`) and names its own action; this owns the proof.
 */
import type React from 'react';
import { type ReauthAction, type ReauthProof } from '@oxy.so/contracts';
export interface ReauthStepProps {
    title: string;
    description?: string;
    /** The change the emailed code is for: it works for nothing else. */
    action: ReauthAction;
    /** The account has a password, and this change accepts it. */
    allowPassword?: boolean;
    /** The account has an authenticator: its code is required too. */
    totpEnabled: boolean;
    /** The screen's action, once the proof is ready. */
    submitLabel: string;
    destructive?: boolean;
    /** The screen's own fields, checked before anything is sent. */
    validate?: () => string | null;
    /** Make the change with the proof. A rejection is reported in place. */
    onSubmit: (proof: ReauthProof) => Promise<void>;
    /** A way out (Cancel / Back). */
    secondary?: {
        label: string;
        onPress: () => void;
    };
    children?: React.ReactNode;
}
export declare const ReauthStep: React.FC<ReauthStepProps>;
//# sourceMappingURL=ReauthStep.d.ts.map