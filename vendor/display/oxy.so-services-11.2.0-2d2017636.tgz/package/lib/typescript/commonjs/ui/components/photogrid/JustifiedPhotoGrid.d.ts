import React from 'react';
import type { FileMetadata } from '@oxy.so/core';
/** Fixed photos-per-row for the justified grid (Apple Photos-style trio). */
export declare const PHOTOS_PER_ROW = 3;
/** Chunk a photo list into fixed-length rows (last row may be short). */
export declare function chunkPhotos(photos: FileMetadata[], perRow: number): FileMetadata[][];
export interface JustifiedPhotoGridProps {
    photos: FileMetadata[];
    /**
     * Resolve a private-safe thumbnail URL for a photo (or `undefined` while the
     * URL is still resolving). The grid measures each photo's intrinsic size from
     * this URL and re-measures automatically once a pending URL resolves.
     */
    getThumbUrl: (photo: FileMetadata) => string | undefined;
    renderJustifiedPhotoItem: (photo: FileMetadata, width: number, height: number, isLast: boolean) => React.ReactElement;
    textColor: string;
    /**
     * Full available width from parent. If omitted, component will measure itself and adapt responsively.
     */
    containerWidth?: number;
    gap?: number;
    minRowHeight?: number;
    maxRowHeight?: number;
    dateFormatLocale?: string;
}
declare const _default: React.NamedExoticComponent<JustifiedPhotoGridProps>;
export default _default;
//# sourceMappingURL=JustifiedPhotoGrid.d.ts.map