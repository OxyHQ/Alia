import type React from 'react';
declare const AvatarCameraBadge: React.FC;
export default AvatarCameraBadge;
//# sourceMappingURL=AvatarCameraBadge.d.ts.map