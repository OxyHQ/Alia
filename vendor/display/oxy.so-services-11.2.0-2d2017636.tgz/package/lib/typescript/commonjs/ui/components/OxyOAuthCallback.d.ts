export interface OxyOAuthCallbackProps {
    /** Where to navigate after OAuth exchange completes. @default '/' */
    redirectTo?: string;
}
/**
 * Optional dedicated OAuth callback route for apps using `/oauth/callback`.
 * `OxyProvider` cold boot handles `?code=` on any route; mount this on the
 * callback path for a Clerk-style loading shell while auth resolves.
 */
export declare function OxyOAuthCallback({ redirectTo }: OxyOAuthCallbackProps): import("react").JSX.Element;
//# sourceMappingURL=OxyOAuthCallback.d.ts.map