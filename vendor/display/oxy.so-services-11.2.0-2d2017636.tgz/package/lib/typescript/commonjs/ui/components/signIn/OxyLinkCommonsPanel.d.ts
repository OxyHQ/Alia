/**
 * Linking Commons to an account that has no key of its own, from the account's
 * settings (the account dialog's "Manage your account", or the Accounts app):
 *
 *   QR → Commons scans and signs with its key → both screens show the same
 *   code → the person confirms it's them with a code sent to the account's
 *   email (+ the authenticator's code) → linked
 *
 * Afterwards the account is self-custodied: its root is the key Commons holds,
 * its email, password and authenticator are deleted, and its phrase in Commons
 * is how it gets back in. It must be rendered signed in as the account.
 */
import type React from 'react';
/** How often the page asks whether Commons has signed. */
export declare const IDENTITY_LINK_POLL_MS = 2000;
export interface OxyLinkCommonsPanelProps {
    /** Commons is linked. */
    onLinked?: () => void;
}
export declare const OxyLinkCommonsPanel: React.FC<OxyLinkCommonsPanelProps>;
//# sourceMappingURL=OxyLinkCommonsPanel.d.ts.map