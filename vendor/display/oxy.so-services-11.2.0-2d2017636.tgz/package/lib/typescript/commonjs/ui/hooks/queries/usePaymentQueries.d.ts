import type { Subscription, Payment, Wallet, WalletTransactionsResponse } from './paymentTypes';
/**
 * Payment / wallet / subscription query hooks.
 *
 * These replace the imperative `oxyServices.*` + `Promise.allSettled` +
 * `useEffect` pattern used in app screens. Each hook:
 *  - is gated on `isAuthenticated` (the underlying SDK methods read the
 *    current user id off the access token and throw when unauthenticated),
 *  - routes through `authenticatedApiCall` so a stale token is refreshed and
 *    auth errors are handled consistently (matches `useUserDevices` /
 *    `usePrivacySettings`),
 *  - keeps its `queryFn` pure — no store writes, no side effects.
 *
 * The wrapped SDK methods (`@oxy.so/core` payment mixin) return `any`; the
 * generic on `authenticatedApiCall<T>` pins the resolved value to the
 * precise domain type so consumers get full typing.
 */
/**
 * Get the current user's subscription.
 *
 * Wraps `oxyServices.billing.subscription()`
 * (`GET /subscription/:userId`, billing-first). Returns the persisted
 * subscription or the API's `{ plan: 'basic' }` fallback when the user has
 * never subscribed.
 */
export declare const useUserSubscription: (options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<Subscription, Error>;
/**
 * Get the current user's payment / billing history.
 *
 * Wraps `oxyServices.billing.payments()` (`GET /payments/user`), which
 * returns the user's `deposit` and `purchase` transactions newest-first.
 */
export declare const useUserPayments: (options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<Payment[], Error>;
/**
 * Get the current user's FairCoin wallet balance.
 *
 * Wraps `oxyServices.billing.wallet()` (`GET /wallet/:userId`).
 * Balance changes frequently, so the fresh window is intentionally short.
 */
export declare const useUserWallet: (options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<Wallet, Error>;
/**
 * Get the current user's wallet transaction history (paginated).
 *
 * Wraps `oxyServices.billing.walletTransactions(options)`
 * (`GET /wallet/transactions/:userId`). The API responds with a
 * `{ data, pagination }` envelope, preserved here as
 * `WalletTransactionsResponse`.
 *
 * @param params - Optional `limit` / `offset` pagination controls. These are
 *   part of the query key, so distinct pages cache independently.
 */
export declare const useUserWalletTransactions: (params?: {
    limit?: number;
    offset?: number;
}, options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<WalletTransactionsResponse, Error>;
//# sourceMappingURL=usePaymentQueries.d.ts.map