import type React from 'react';
import type { BaseScreenProps } from '../types/navigation';
/** `DeleteAccount`: delete an account without a key, with a code by email. */
declare const DeleteAccountScreen: React.FC<BaseScreenProps>;
export default DeleteAccountScreen;
//# sourceMappingURL=DeleteAccountScreen.d.ts.map