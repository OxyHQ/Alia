/**
 * The shell every Oxy sign-in screen shares — the in-app account dialog and
 * every page of the auth.oxy.so IdP render these, so the two cannot drift:
 *
 *   header   the Oxy mark (56), then the title (48/800, tight) and a 18px
 *            description, 8 apart
 *   screen   blocks 24 apart, at most 448 wide
 *   split    from `md`, Bloom `AuthCard`'s split base — max 880, radius 24,
 *            1px border, two equal columns, the right one on the secondary
 *            surface; below `md` the right column is dropped, not stacked
 *   loading  an indeterminate spinner holding the screen's height
 *   terms    one centred caption linking the Terms of Service and Privacy Policy
 *
 * Layout is NativeWind `className` (breakpoints included). Type stays on
 * Bloom `Text`'s own ramp through `style` — a `className` there drops its
 * default family — and colours come from the Bloom theme.
 */
import type React from 'react';
export interface OxyAuthScreenHeaderProps {
    title: string;
    description?: React.ReactNode;
}
/** The Oxy mark over the screen's title and description. */
export declare const OxyAuthScreenHeader: React.FC<OxyAuthScreenHeaderProps>;
/** A sign-in screen's column: its blocks 24 apart. `className` extends it (the split's form column). */
export declare const OxyAuthScreen: React.FC<{
    children: React.ReactNode;
    className?: string;
}>;
/**
 * The split card: `children` on the left and, from `md`, `aside` on the right.
 * `bare` inside a surface that already is the card (the account dialog): no
 * border of its own, and the right column is a rounded tile within the
 * dialog's margins.
 */
export declare const OxyAuthSplit: React.FC<{
    children: React.ReactNode;
    aside: React.ReactNode;
    bare?: boolean;
}>;
/** The screen while there is nothing to show yet: Bloom's spinner, named for assistive technology. */
export declare const OxyAuthLoading: React.FC;
/** "By continuing, you agree to our Terms of Service and Privacy Policy." */
export declare const OxyAuthTerms: React.FC;
//# sourceMappingURL=OxyAuthScreen.d.ts.map