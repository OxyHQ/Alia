import type { OxyServices } from '@oxy.so/core';
import type { Asset, AssetMetadata, AssetRecord, AssetVariant, UploadedAsset } from '@oxy.so/core';
export declare const setOxyAssetInstance: (instance: OxyServices) => void;
/**
 * Hook for managing assets with Zustand store integration
 */
export declare const useAssets: () => {
    assets: Asset[];
    uploadProgress: Record<string, import("@oxy.so/core").AssetUploadProgress>;
    loading: {
        uploading: boolean;
        linking: boolean;
        deleting: boolean;
    };
    errors: {
        upload?: string;
        link?: string;
        delete?: string;
    };
    upload: (file: File, metadata?: AssetMetadata) => Promise<UploadedAsset | null>;
    link: (assetId: string, app: string, entityType: string, entityId: string) => Promise<void>;
    unlink: (assetId: string, app: string, entityType: string, entityId: string) => Promise<void>;
    getUrl: (assetId: string, variant?: string, expiresIn?: number) => Promise<string>;
    getAsset: (assetId: string) => Promise<AssetRecord>;
    deleteAsset: (assetId: string, force?: boolean) => Promise<void>;
    restore: (assetId: string) => Promise<void>;
    getVariants: (assetId: string) => Promise<AssetVariant[]>;
    getAssetsByApp: (app: string) => Asset[];
    getAssetsByEntity: (app: string, entityType: string, entityId: string) => Asset[];
    getAssetUsageCount: (assetId: string) => number;
    isAssetLinked: (assetId: string, app: string, entityType: string, entityId: string) => boolean;
    clearErrors: () => void;
    reset: () => void;
};
//# sourceMappingURL=useAssets.d.ts.map