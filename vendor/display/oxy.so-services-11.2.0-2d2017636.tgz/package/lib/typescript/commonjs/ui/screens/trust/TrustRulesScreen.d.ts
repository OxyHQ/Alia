import type React from 'react';
import type { BaseScreenProps } from '../../types/navigation';
declare const TrustRulesScreen: React.FC<BaseScreenProps>;
export default TrustRulesScreen;
//# sourceMappingURL=TrustRulesScreen.d.ts.map