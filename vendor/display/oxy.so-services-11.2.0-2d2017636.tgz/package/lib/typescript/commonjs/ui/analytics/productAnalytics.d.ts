export type OxyProductEvent = 'oxy_auth_resolved' | 'oxy_session_started' | 'oxy_session_ended' | 'oxy_account_switched';
export interface ProductAnalytics {
    capture(event: OxyProductEvent, properties?: Readonly<Record<string, boolean | number | string>>): void;
    identify(distinctId: string): void;
    reset(): void;
}
/**
 * Loads a vendor SDK only after the first analytics operation. Calls retain
 * their original order and loader failures remain outside the product runtime.
 */
export declare function createDeferredProductAnalytics(load: () => Promise<ProductAnalytics>): ProductAnalytics;
interface AnalyticsAuthState {
    authResolved: boolean;
    userId: string | null;
}
/**
 * Emits a deliberately small, non-sensitive auth lifecycle vocabulary.
 * Analytics is observational only: failures are isolated and can never affect
 * authentication, rendering, or account switching.
 */
export declare function ProductAnalyticsObserver({ analytics }: {
    analytics?: ProductAnalytics;
}): null;
export declare function recordAuthStateChange(analytics: ProductAnalytics, previous: AnalyticsAuthState | null, current: AnalyticsAuthState): void;
export {};
//# sourceMappingURL=productAnalytics.d.ts.map