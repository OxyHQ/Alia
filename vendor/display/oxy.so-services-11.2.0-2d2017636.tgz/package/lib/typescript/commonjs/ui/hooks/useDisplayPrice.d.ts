/** Display conversion only. Pricing and checkout request bodies retain their source units. */
export declare function useDisplayPrice(): {
    currency: import("./useDisplayCurrency").DisplayCurrency;
    formatUsd: (minorUnits: number) => string;
};
//# sourceMappingURL=useDisplayPrice.d.ts.map