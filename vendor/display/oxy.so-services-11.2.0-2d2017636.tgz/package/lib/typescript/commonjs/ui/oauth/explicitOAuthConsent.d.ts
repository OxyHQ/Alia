/**
 * Explicit OAuth consent for an already-authenticated Oxy user.
 *
 * This is deliberately separate from sign-in routing. First-party applications
 * normally use the account dialog, but a consent-required scope (for example
 * `acting-as:offline`) still has to go through the OAuth authorize surface. The
 * caller must invoke this operation from a real user gesture; it never runs on
 * mount, retries silently, or grants anything locally.
 */
import type { OxyServices } from "@oxy.so/core";
import type { OAuthSessionCommitInput, WebAuthMode, WebOAuthFailureReason, WebOAuthRedirectReason } from "./types";
export interface RequestOAuthConsentOptions {
    /** Exact, registered redirect URI. It is never inferred or normalized. */
    redirectUri: string;
    /** Exact application scopes to present to the user, in caller-supplied order. */
    scopes: readonly string[];
    /** Optional timeout for the web popup lane. */
    timeoutMs?: number;
}
export type OAuthConsentFailureReason = WebOAuthFailureReason | "invalid-redirect-uri" | "invalid-scopes" | "scope-not-configured" | "client-resolution-failed" | "native-callback-invalid" | "state-mismatch" | "exchange-failed" | "subject-mismatch";
export type OAuthConsentUnsupportedReason = "missing-client-id" | "identity-bound" | "not-authenticated" | "unsupported-platform";
export type OAuthConsentResult = {
    status: "consented";
} | {
    status: "redirecting";
    via: WebOAuthRedirectReason;
} | {
    status: "cancelled";
} | {
    status: "timed-out";
} | {
    status: "failed";
    reason: OAuthConsentFailureReason;
    description?: string;
} | {
    status: "unsupported";
    reason: OAuthConsentUnsupportedReason;
};
export interface OAuthConsentContext {
    platform: "web" | "native" | "unsupported";
    mode: WebAuthMode;
    oxyServices: OxyServices;
    clientId: string | null;
    authorizeBaseUrl?: string;
    identityBound: boolean;
    /** User who triggered the consent request; a different returned subject is rejected. */
    expectedUserId: string | null;
    commitSession: (input: OAuthSessionCommitInput) => Promise<void>;
}
/**
 * Ask the current user to grant exact application scopes through Oxy OAuth.
 *
 * Scope syntax is checked before any window opens. After that, the exact client
 * id resolves its public Application and every requested scope must be present
 * in that application's configured scope list. Unknown, trimmed, duplicated or
 * reordered-by-the-SDK values are never sent to the IdP.
 */
export declare function requestOAuthConsent(context: OAuthConsentContext, options: RequestOAuthConsentOptions): Promise<OAuthConsentResult>;
//# sourceMappingURL=explicitOAuthConsent.d.ts.map