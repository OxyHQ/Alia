import type React from 'react';
import type { ViewStyle, TextStyle, StyleProp } from 'react-native';
import type { BulkFollowResult, BulkUnfollowResult } from '@oxy.so/core';
/** Props shared by both single- and multi-user follow modes. */
interface FollowButtonBaseProps {
    size?: 'sm' | 'md' | 'lg';
    style?: StyleProp<ViewStyle>;
    textStyle?: StyleProp<TextStyle>;
    disabled?: boolean;
    showLoadingState?: boolean;
    preventParentActions?: boolean;
    theme?: 'light' | 'dark';
    onFollowChange?: (isFollowing: boolean) => void;
}
/** Single-user mode — follows/unfollows one user (existing behavior). */
export interface SingleFollowButtonProps extends FollowButtonBaseProps {
    userId: string;
    initiallyFollowing?: boolean;
    /**
     * The account's handle, with or without the `@`. A screen reader then hears
     * "Following @nate" rather than a bare "Following"; omit it and the name
     * still follows the state.
     */
    username?: string;
    userIds?: never;
}
/** Multi-user mode — follows MANY users in one "Follow all" action (follow-only). */
export interface MultiFollowButtonProps extends FollowButtonBaseProps {
    userIds: string[];
    initiallyAllFollowing?: boolean;
    followAllLabel?: string;
    followedAllLabel?: string;
    onBulkFollow?: (result: BulkFollowResult) => void;
    onBulkUnfollow?: (result: BulkUnfollowResult) => void;
    userId?: never;
}
/**
 * FollowButton accepts EITHER single-user mode (`userId`) or multi-user mode
 * (`userIds`), never both. Existing `{ userId, ... }` callers remain valid.
 */
export type FollowButtonProps = SingleFollowButtonProps | MultiFollowButtonProps;
declare const FollowButton: React.FC<FollowButtonProps>;
export { FollowButton };
export default FollowButton;
//# sourceMappingURL=FollowButton.d.ts.map