import type { OxyLanguageConfig } from '../types/navigation';
/**
 * `OxyProvider`'s language config prop, realized. Oxy decides which
 * language an account (or, signed out, the device/guest locale) should see;
 * this is the ONE place that decision reaches the host app's own i18n library
 * — so an app never re-derives or imperatively tracks a language of its own,
 * and never mounts anything extra to get it. It owns only its translation
 * catalogs.
 *
 * `currentLanguage` may name a locale the host app never shipped a catalog
 * for — {@link coerceToSupportedLocale} narrows it to the closest one the app
 * actually has (exact match, then same base language, then `fallbackLocale`).
 *
 * Renders nothing. Mounted by `OxyProvider` INSIDE `OxyRuntimeProvider` only
 * when this config is supplied, so an app with no i18n of its own pays
 * nothing.
 */
export declare function LanguageBridge({ supportedLocales, fallbackLocale, onChange, onError, }: OxyLanguageConfig): null;
//# sourceMappingURL=LanguageBridge.d.ts.map