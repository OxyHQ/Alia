import type { SecurityActivity, SecurityActivityResponse, SecurityEventType } from '@oxy.so/core';
/**
 * Get user's security activity with pagination
 */
export declare const useSecurityActivity: (options?: {
    limit?: number;
    offset?: number;
    eventType?: SecurityEventType;
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<SecurityActivityResponse, Error>;
/**
 * Get recent security activity (convenience hook)
 */
export declare const useRecentSecurityActivity: (limit?: number) => import("@tanstack/react-query").UseQueryResult<SecurityActivity[], Error>;
/**
 * Get user's security activity with infinite pagination.
 * Each page returns up to `limit` events; `getNextPageParam` walks the
 * `offset` cursor until the API reports `hasMore: false`.
 */
export declare const useInfiniteSecurityActivity: (options?: {
    limit?: number;
    eventType?: SecurityEventType;
    enabled?: boolean;
}) => import("@tanstack/react-query").UseInfiniteQueryResult<import("@tanstack/react-query").InfiniteData<SecurityActivityResponse, unknown>, Error>;
//# sourceMappingURL=useSecurityQueries.d.ts.map