import type { User } from '@oxy.so/core';
export interface CommitDeviceSetAndResolveDeps {
    /**
     * Whether this commit is a deliberate sign-in on THIS device (activates the
     * account and BLOCKS on the device-set reconcile before resolving) vs. a
     * cold-boot restore (resolves auth from the profile fetch FIRST, then
     * reconciles the device set in the background).
     */
    activate: boolean;
    /** Trusted provider provenance from the completed third-party OAuth exchange. */
    isolatedOAuth?: boolean;
    /** Cold boot already carries authoritative device state from the mint. */
    hasDeviceState?: boolean;
    /** The committing account id (only used by `registerAndActivate`). */
    userId?: string;
    /** Minimal user carried by the commit input; used if the profile fetch fails. */
    fallbackUser: User | null;
    /** Deliberate sign-in: register + activate the account in the device set. */
    registerAndActivate: (userId?: string) => Promise<void>;
    /** Cold boot: ensure membership only; the server's `activeAccountId` wins. */
    addCurrentAccount: () => Promise<void>;
    /** Start the device-scoped socket. */
    startSocket: () => Promise<void>;
    /** Project the server-authoritative device state onto local sessions. */
    syncFromClient: () => Promise<void>;
    /** Hydrate the full profile (the commit input carries only minimal data). */
    getCurrentUser: () => Promise<User | null>;
    loginSuccess: (user: User) => void;
    onAuthStateChange?: (user: User | null) => void;
    markAuthResolved: () => void;
}
/**
 * Device-set registration + full-user hydration + auth-resolution gate flip.
 *
 * On a deliberate sign-in (`activate: true`) the device-set reconcile is awaited
 * BEFORE hydrating and resolving — unchanged legacy ordering. On a cold boot
 * (`activate: false`) auth resolves from the profile fetch FIRST so the app can
 * paint an authenticated shell without waiting on device-set registration, the
 * socket connect, and the authoritative sessions projection — those reconcile in
 * a DETACHED background task a moment later.
 */
export declare function commitDeviceSetAndResolve(deps: CommitDeviceSetAndResolveDeps): Promise<void>;
//# sourceMappingURL=commitSessionFlow.d.ts.map