import type { McpOAuthWriteAction } from '@oxy.so/contracts';
/** The requesting application, resolved by the caller (never user-supplied raw). */
export interface OxyConsentApplication {
    /** Display name of the requesting application. */
    name: string;
    /** Application icon — a URL or bare file id passed straight to `<Avatar source>`. */
    iconUrl?: string;
    /** Public website of the application, shown as a link when present. */
    websiteUrl?: string;
    /** Privacy policy URL, shown as a link when present. */
    privacyPolicyUrl?: string;
    /** Terms of service URL, shown as a link when present. */
    termsUrl?: string;
    /** Human-readable publisher, used for the "Published by …" provenance line. */
    developerName?: string;
    /** True for first-party / official Oxy applications. */
    isOfficial?: boolean;
}
/** The account that will authorize the request (the currently signed-in user). */
export interface OxyConsentUser {
    /** Exact effective account bound to the grant. */
    accountId?: string;
    /** Real display name, when the profile has one. */
    displayName?: string;
    /** Normalized handle — the sanctioned fallback when `displayName` is absent. */
    handle?: string;
    /** Avatar — a URL or bare file id passed straight to `<Avatar source>`. */
    avatarUri?: string;
}
export interface OxyConsentResource {
    /** Oxy application that owns the protected MCP resource. */
    application: {
        name: string;
        iconUrl?: string;
    };
    /** Canonical protected-resource URI bound into the access token. */
    uri: string;
    /** Effectful tools enabled by the requested capabilities. */
    writeActions: McpOAuthWriteAction[];
}
export interface OxyConsentScreenProps {
    /** The resolved requesting application. */
    application: OxyConsentApplication;
    /** OAuth scopes requested by the client (mapped to friendly labels). */
    scopes: string[];
    /** The account that will authorize the request, when known. */
    user?: OxyConsentUser;
    /** Exact protected resource for an external MCP connection. */
    resource?: OxyConsentResource;
    /** Approve handler — the caller mints the code / completes the flow. */
    onAllow: () => void | Promise<void>;
    /** Deny handler — the caller cancels the flow. */
    onDeny: () => void;
    /** True while a decision is in flight; disables both actions and spins Allow. */
    busy?: boolean;
    /**
     * Disables Allow WITHOUT a spinner, leaving Deny live. For a host that owns an
     * extra gate the person must clear first — e.g. the device approval page's
     * mandatory "I started this sign-in myself" acknowledgement, which is the
     * login-CSRF control for a request that arrived as a bare code and cannot be
     * skipped. `busy` would be wrong there: nothing is in flight, and a spinning
     * button reads as "working" rather than "not yet".
     */
    allowDisabled?: boolean;
    /** A blocking error message for the request, when present. */
    error?: string | null;
}
export declare function OxyConsentScreen({ application, scopes, user, resource, onAllow, onDeny, busy, allowDisabled, error, }: OxyConsentScreenProps): import("react").JSX.Element;
export default OxyConsentScreen;
//# sourceMappingURL=OxyConsentScreen.d.ts.map