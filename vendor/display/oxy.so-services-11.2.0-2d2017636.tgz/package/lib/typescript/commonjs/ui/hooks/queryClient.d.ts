/**
 * Offline-first QueryClient with cross-restart persistence.
 *
 * Wires together:
 * - TanStack Query with `networkMode: 'offlineFirst'` for queries and mutations
 *   so cached data is served immediately and mutations are queued (paused) while
 *   the browser/device reports offline.
 * - `attachQueryPersistence(...)` so that query results AND paused mutations
 *   survive a cold restart (kill-and-relaunch); see `persistedQueryCache.ts`.
 * - `onlineManager` resume hook so paused mutations replay the moment the
 *   network is reported back, even if the host app swapped in a custom
 *   onlineManager implementation.
 *
 * Storage layer: the platform `StorageInterface` (AsyncStorage on native,
 * localStorage on web).
 *
 * Whitelist policy:
 * - Persist every account/user/session/privacy query and every queued mutation.
 * - DO NOT persist large list queries (e.g. activity feeds) — they go stale
 *   fast and would balloon storage. Add new keys to `PERSISTED_QUERY_PREFIXES`
 *   (`persistedQueryCache.ts`) when introducing reads that should survive restart.
 */
import { QueryClient } from '@tanstack/react-query';
import type { PersistedClient } from '@tanstack/react-query-persist-client';
import type { StorageInterface } from '../utils/storageHelpers';
import { type AccountQueriesConfig } from './accountQueryPersistence';
/** Retry only failures that another attempt can plausibly change. */
export declare function shouldRetryQuery(failureCount: number, error: unknown): boolean;
/**
 * Create a QueryClient with offline-first defaults.
 *
 * Mutations marked with `networkMode: 'offlineFirst'` are queued by TanStack
 * Query when offline (status "paused") and resumed automatically when
 * `onlineManager` transitions back to online. Network monitoring wiring lives
 * in `OxyProvider.tsx`.
 *
 * Persistence is attached separately via `attachQueryPersistence(...)`.
 * Splitting the steps lets test/SSR callers create a stateless client.
 */
export declare const createQueryClient: () => QueryClient;
export interface AttachPersistenceResult {
    /** Promise that resolves once the persisted cache has been restored. */
    restored: Promise<void>;
    /** Detach the persistence subscription (tests + teardown). */
    unsubscribe: () => void;
}
/**
 * Restore, then keep writing, the account-agnostic cache.
 *
 * Queries written by another build are dropped; queued mutations are kept
 * (`persistedQueryCache.ts`). Whatever the app declared account-scoped
 * (`accountQueries`) is left to `createAccountQueryPersistence`, even under
 * one of the SDK's prefixes, so private rows never land in the shared blob and
 * a paused mutation cannot replay twice or under another account.
 *
 * Safe to no-op if `storage` is null/undefined (e.g. server-side render
 * with no host storage).
 */
export declare const attachQueryPersistence: (queryClient: QueryClient, storage: StorageInterface | null | undefined, accountQueries?: AccountQueriesConfig) => AttachPersistenceResult;
/**
 * Remove the persisted query+mutation cache (used on full sign-out / data reset).
 * Safe to call even if persistence was never attached.
 */
export declare const clearQueryCache: (storage: StorageInterface) => Promise<void>;
/**
 * Re-export the persisted client shape so callers can type custom persisters.
 */
export type { PersistedClient };
//# sourceMappingURL=queryClient.d.ts.map