import type { OxyServices, BulkFollowResult, BulkUnfollowResult } from '@oxy.so/core';
/**
 * useFollow — Hook for follow state management.
 *
 * Performance fixes:
 * 1. Uses granular Zustand selectors instead of subscribing to the entire store.
 *    The old `useFollowStore()` caused every component using this hook to re-render
 *    on ANY store change (any user's follow status, loading state, error, or count).
 * 2. Callbacks depend on primitive values (userId, isFollowing) not object references,
 *    so they remain stable across renders.
 * 3. Store action methods are accessed via getState() in callbacks to avoid
 *    subscribing to the action functions themselves (they never change but including
 *    them in selectors would cause unnecessary selector recalculations).
 */
export declare const useFollow: (userId?: string | string[]) => {
    isFollowing: boolean;
    isLoading: boolean;
    error: string | null;
    toggleFollow: () => Promise<void>;
    setFollowStatus: (following: boolean) => void;
    fetchStatus: () => Promise<void>;
    clearError: () => void;
    followerCount: number | null;
    followingCount: number | null;
    isLoadingCounts: boolean;
    fetchUserCounts: () => Promise<void>;
    setFollowerCount: (count: number) => void;
    setFollowingCount: (count: number) => void;
    followData?: undefined;
    toggleFollowForUser?: undefined;
    setFollowStatusForUser?: undefined;
    fetchStatusForUser?: undefined;
    fetchAllStatuses?: undefined;
    followAllUsers?: undefined;
    unfollowAllUsers?: undefined;
    clearErrorForUser?: undefined;
    isAnyLoading?: undefined;
    hasAnyError?: undefined;
    allFollowing?: undefined;
    allNotFollowing?: undefined;
} | {
    followData: Record<string, {
        isFollowing: boolean;
        isLoading: boolean;
        error: string | null;
    }>;
    toggleFollowForUser: (targetUserId: string) => Promise<void>;
    setFollowStatusForUser: (targetUserId: string, following: boolean) => void;
    fetchStatusForUser: (targetUserId: string) => Promise<void>;
    fetchAllStatuses: () => Promise<void>;
    followAllUsers: () => Promise<BulkFollowResult>;
    unfollowAllUsers: () => Promise<BulkUnfollowResult>;
    clearErrorForUser: (targetUserId: string) => void;
    isAnyLoading: boolean;
    hasAnyError: boolean;
    allFollowing: boolean;
    allNotFollowing: boolean;
    isFollowing?: undefined;
    isLoading?: undefined;
    error?: undefined;
    toggleFollow?: undefined;
    setFollowStatus?: undefined;
    fetchStatus?: undefined;
    clearError?: undefined;
    followerCount?: undefined;
    followingCount?: undefined;
    isLoadingCounts?: undefined;
    fetchUserCounts?: undefined;
    setFollowerCount?: undefined;
    setFollowingCount?: undefined;
};
/**
 * useFollowForButton — Lightweight follow hook for FollowButton in list contexts.
 *
 * Unlike useFollow, this hook:
 * - Accepts oxyServices directly (no useOxy() context subscription)
 * - Only subscribes to the specific user's follow and loading state
 * - Returns only what FollowButton needs (no counts, no multi-user)
 */
export declare const useFollowForButton: (userId: string, oxyServices: OxyServices, initiallyFollowing?: boolean) => {
    isFollowing: boolean;
    isKnown: boolean;
    isLoading: boolean;
    error: string | null;
    toggleFollow: () => Promise<boolean>;
    resolveStatus: () => void;
    setFollowStatus: (following: boolean) => void;
    clearError: () => void;
};
/**
 * useSeedFollowStatuses — returns a stable callback that bulk-seeds follow
 * statuses into the store (seed-only-if-absent; never clobbers a live value).
 *
 * Wire this at the app root to seed from `oxyServices.follows.viewerGraph()
 * .followingIds` (map each followed id → `true`) so a page of `FollowButton`s
 * paints the correct label on first render with ZERO follow-status network
 * calls — the batched resolver then skips every seeded id.
 */
export declare const useSeedFollowStatuses: () => (statuses: Record<string, boolean>) => void;
export declare const useFollowerCounts: (userId: string) => {
    followerCount: number;
    followingCount: number;
    isLoadingCounts: boolean;
    fetchUserCounts: () => Promise<void>;
    setFollowerCount: (count: number) => void;
    setFollowingCount: (count: number) => void;
};
//# sourceMappingURL=useFollow.d.ts.map