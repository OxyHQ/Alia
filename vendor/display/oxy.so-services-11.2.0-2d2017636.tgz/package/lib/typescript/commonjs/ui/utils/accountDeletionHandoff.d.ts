/**
 * Commons' own delete-account screen (`app/(tabs)/(settings)/delete-account.tsx`
 * in packages/commons). Expo Router drops the route groups, so the scheme path
 * `delete-account` resolves to it; `oxycommons://` is the scheme the account
 * dialog already probes and hands sign-in approvals to.
 */
export declare const COMMONS_DELETE_ACCOUNT_URL = "oxycommons://delete-account";
/** The scheme root `Linking.canOpenURL` probes to tell whether Commons is installed. */
export declare const COMMONS_APP_SCHEME = "oxycommons://";
type Translate = (key: string, vars?: Record<string, string | number>) => string | undefined;
export interface AccountDeletionHandoffDeps {
    /** Whether THIS app can read an identity key it could sign the deletion with. */
    hasIdentity: () => Promise<boolean>;
    canOpenURL: (url: string) => Promise<boolean>;
    openURL: (url: string) => Promise<unknown>;
    t: Translate;
}
/**
 * `'local'`: this app holds the identity key, so the caller runs its own
 * delete-account surface. `'handled'`: it does not, and the user has been sent
 * to where the deletion can actually be signed (or told why not).
 */
export type AccountDeletionHandoffResult = 'local' | 'handled';
/**
 * Decide where a native account deletion can happen, before anything is deleted.
 *
 * Deleting an account is signed with the identity private key. When the key
 * lives in Oxy Commons rather than in this app, the API call cannot be made from
 * here, so the deletion is delegated to Commons' own screen when Commons is
 * installed, and explained otherwise. Nothing on the delegated paths calls the
 * deletion API.
 */
export declare function runAccountDeletionHandoff(deps: AccountDeletionHandoffDeps): Promise<AccountDeletionHandoffResult>;
export {};
//# sourceMappingURL=accountDeletionHandoff.d.ts.map