/**
 * Pure link-display helpers for the profile "links" editor. Kept out of the
 * screen component so the string-coercion guard can be unit-tested without
 * rendering the whole React Native screen.
 */
/** Strip the protocol and any trailing slash from a link URL for display. */
export declare const getLinkTitle: (url: string) => string;
/** Human-readable description for a link URL. */
export declare const getLinkDescription: (url: string) => string;
export interface LinkListItem {
    id: string;
    url: string;
    title: string;
    description: string;
}
/**
 * Build editable list items from a raw links array. The array can come from
 * legacy or untrusted profile data whose elements are not guaranteed to be
 * strings, so each entry is coerced with `String(item ?? '')` before formatting
 * — a non-string element must never crash the editor.
 */
export declare function linksToListItems(links: readonly unknown[]): LinkListItem[];
//# sourceMappingURL=linkFormat.d.ts.map