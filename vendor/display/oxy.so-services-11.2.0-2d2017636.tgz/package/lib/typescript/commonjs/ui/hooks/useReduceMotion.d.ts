/**
 * useReduceMotion
 *
 * Reactive boolean reflecting the OS "reduce motion" accessibility preference.
 * Wraps `AccessibilityInfo` as an external store via `useSyncExternalStore` — the
 * effect-free, React-Compiler-safe way to read an external mutable source. The
 * initial value is read asynchronously once (the platform API is a Promise) and
 * cached module-side; subsequent changes arrive via the `reduceMotionChanged`
 * event. Mirrors the `useOnlineStatus` pattern.
 *
 * Consumers use it to pin entrance/stagger animations off under reduce-motion.
 */
export declare function useReduceMotion(): boolean;
//# sourceMappingURL=useReduceMotion.d.ts.map