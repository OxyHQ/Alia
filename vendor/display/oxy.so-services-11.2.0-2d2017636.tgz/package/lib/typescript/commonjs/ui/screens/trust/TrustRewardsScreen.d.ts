import type React from 'react';
import type { BaseScreenProps } from '../../types/navigation';
declare const TrustRewardsScreen: React.FC<BaseScreenProps>;
export default TrustRewardsScreen;
//# sourceMappingURL=TrustRewardsScreen.d.ts.map