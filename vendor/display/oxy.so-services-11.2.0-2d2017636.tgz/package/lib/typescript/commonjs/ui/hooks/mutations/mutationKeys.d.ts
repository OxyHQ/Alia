/**
 * Stable mutation key factories.
 *
 * Mutations that may be queued while offline MUST declare a stable
 * `mutationKey`. When the network comes back, TanStack Query resumes
 * paused mutations grouped by key — so the keys here should be stable
 * across renders and across reloads when persistence is enabled.
 */
export declare const mutationKeys: {
    readonly account: {
        readonly updateProfile: readonly ["mutation", "account", "updateProfile"];
        readonly uploadAvatar: readonly ["mutation", "account", "uploadAvatar"];
        readonly updateSettings: readonly ["mutation", "account", "updateSettings"];
        readonly updatePrivacySettings: readonly ["mutation", "account", "updatePrivacySettings"];
        readonly updateNotificationPreferences: readonly ["mutation", "account", "updateNotificationPreferences"];
        readonly updateUserPreferences: readonly ["mutation", "account", "updateUserPreferences"];
        readonly uploadFile: readonly ["mutation", "account", "uploadFile"];
    };
    readonly session: {
        readonly switch: readonly ["mutation", "session", "switch"];
        readonly logout: readonly ["mutation", "session", "logout"];
        readonly logoutAll: readonly ["mutation", "session", "logoutAll"];
        readonly updateDeviceName: readonly ["mutation", "session", "updateDeviceName"];
        readonly removeDevice: readonly ["mutation", "session", "removeDevice"];
    };
    readonly connectedApps: {
        readonly revoke: readonly ["mutation", "connectedApps", "revoke"];
    };
};
//# sourceMappingURL=mutationKeys.d.ts.map