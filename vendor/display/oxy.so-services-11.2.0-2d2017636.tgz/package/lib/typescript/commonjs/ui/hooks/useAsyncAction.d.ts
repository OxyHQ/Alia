interface UseAsyncActionOptions<T> {
    /** Function to execute */
    action: () => Promise<T>;
    /** Success message to display */
    successMessage?: string;
    /** Error message to display (or function to get message from error) */
    errorMessage?: string | ((error: unknown) => string);
    /** Callback on success */
    onSuccess?: (result: T) => void;
    /** Callback on error */
    onError?: (error: unknown) => void;
    /** Show loading toast */
    showLoadingToast?: boolean;
    /** Loading message */
    loadingMessage?: string;
}
interface UseAsyncActionReturn<T> {
    /** Execute the action */
    execute: () => Promise<T | undefined>;
    /** Whether the action is currently executing */
    isLoading: boolean;
    /** The last error that occurred */
    error: Error | null;
    /** Reset the error state */
    resetError: () => void;
}
/**
 * Hook for handling async actions with loading state, error handling, and toast notifications.
 * Reduces boilerplate for common patterns like try-catch with toast feedback.
 *
 * @example
 * const { execute, isLoading } = useAsyncAction({
 *   action: () => api.saveSettings(settings),
 *   successMessage: 'Settings saved!',
 *   errorMessage: 'Failed to save settings',
 * });
 *
 * <Button onPress={execute} disabled={isLoading}>Save</Button>
 */
export declare function useAsyncAction<T = void>(options: UseAsyncActionOptions<T>): UseAsyncActionReturn<T>;
/**
 * Simplified version that just executes an async action with toast feedback.
 * Useful for one-off actions.
 */
export declare function executeWithToast<T>(action: () => Promise<T>, options?: {
    successMessage?: string;
    errorMessage?: string;
    loadingMessage?: string;
}): Promise<T | undefined>;
export default useAsyncAction;
//# sourceMappingURL=useAsyncAction.d.ts.map