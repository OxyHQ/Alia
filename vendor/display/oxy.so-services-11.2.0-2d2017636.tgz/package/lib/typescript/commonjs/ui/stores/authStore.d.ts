import type { User } from '@oxy.so/core';
import type { OxyRuntime } from '../runtime';
/**
 * The signed-in user, as a zustand-shaped read/write surface.
 *
 * It used to BE a zustand store, and that made it a second owner of the
 * session: the provider wrote `user`/`isAuthenticated` here, `SessionClient`
 * wrote the same facts into its device state, and nothing reconciled them —
 * when they disagreed, which one was right was not answerable. It is now a
 * projection of the ONE `OxyRuntime` (ADR 0004): reads come off the runtime
 * snapshot and writes go into the runtime, so there is nothing left to drift.
 *
 * The zustand SHAPE is kept deliberately — `useAuthStore(selector)`,
 * `.getState()`, `.setState()`, `.subscribe()` — because a dozen call sites
 * across this package and the Commons app read the user out of band, from
 * mutation success handlers and cache helpers that are not inside a render.
 * Rewriting them is Phase 8's cut, not this one's.
 *
 * `fetchUser` and `lastUserFetch` are GONE rather than projected: they were a
 * five-minute profile cache with zero readers anywhere in the monorepo, and the
 * Query cache has owned that job since long before this change.
 */
export interface AuthState {
    user: User | null;
    isAuthenticated: boolean;
    isLoading: boolean;
    error: string | null;
    loginSuccess: (user: User) => void;
    loginFailure: (error: string) => void;
    logout: () => void;
    /** Replace the signed-in profile after a write (a rename, a new avatar). */
    setUser: (user: User) => void;
}
/** The subset of `AuthState` a caller may push back in through `setState`. */
export type AuthStatePatch = Partial<Pick<AuthState, 'user' | 'isLoading' | 'error'>>;
/**
 * Point this surface at the provider's runtime. Called once by
 * `OxyRuntimeProvider`; the returned function detaches it again on unmount.
 *
 * With nothing bound, reads answer signed-out and writes are dropped. That is
 * the honest answer for the two places it happens — the SSR shim, and a unit
 * test poking the store with no provider mounted — and it is why binding is an
 * explicit call rather than a lazily-created default runtime, which is exactly
 * the fabricated-forever-loading runtime ADR 0004 deleted.
 */
export declare function bindAuthStoreToRuntime(runtime: OxyRuntime): () => void;
declare function useAuthStoreHook<T>(selector: (state: AuthState) => T): T;
/**
 * Read the signed-in user. Zustand-shaped, projected from the runtime.
 *
 * A selector that builds an object must be wrapped in `useShallow` (as every
 * call site here already does) — otherwise a structurally-equal result reads as
 * a change on every publish.
 */
export declare const useAuthStore: typeof useAuthStoreHook & {
    getState: () => AuthState;
    setState: (patch: AuthStatePatch) => void;
    subscribe: (listener: () => void) => (() => void);
};
export {};
//# sourceMappingURL=authStore.d.ts.map