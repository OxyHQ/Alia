import type React from 'react';
import type { BaseScreenProps } from '../types/navigation';
/** `SignInPassword`: set or change the account's password. */
declare const SignInPasswordScreen: React.FC<BaseScreenProps>;
export default SignInPasswordScreen;
//# sourceMappingURL=SignInPasswordScreen.d.ts.map