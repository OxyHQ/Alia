import type { FeedbackData, FeedbackState } from './types';
export declare const useFeedbackForm: () => {
    feedbackData: FeedbackData;
    feedbackState: FeedbackState;
    setFeedbackState: import("react").Dispatch<import("react").SetStateAction<FeedbackState>>;
    updateField: <K extends keyof FeedbackData>(field: K, value: FeedbackData[K]) => void;
    resetForm: () => void;
};
//# sourceMappingURL=useFeedbackForm.d.ts.map