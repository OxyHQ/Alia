import type React from 'react';
import type { ViewStyle } from 'react-native';
interface LogoIconProps {
    /**
     * Color of the primary fill. Defaults to the resolved Bloom theme primary
     * color. Pass an explicit color for splash screens or contexts where the
     * Bloom theme is not yet mounted.
     */
    color?: string;
    /**
     * Color of the interior letter overlay. Defaults to white. Override only
     * when rendering on a light background where white would disappear.
     */
    letterColor?: string;
    /** Height in pixels. Width is derived from the SVG viewBox aspect ratio. */
    height?: number;
    /** Style passed through to the root SVG element. */
    style?: ViewStyle;
}
export declare const LogoIcon: React.FC<LogoIconProps>;
export default LogoIcon;
//# sourceMappingURL=LogoIcon.d.ts.map