/**
 * RequireOxyAuth — the optional signed-out gate primitive (React Native).
 *
 * ONE shared way for any Oxy app to opt into a signed-out gate. It is entirely
 * OPTIONAL: a public app renders its children untouched (`prompt="off"`); an
 * auth-required app blocks them behind a signed-out state (`prompt="hard"`); an
 * app that mostly works signed-out but wants a nudge shows a dismissible banner
 * (`prompt="soft"`). Every mode reuses the ONE account dialog the provider
 * already mounts — opening the sign-in surface is always
 * `useOxy().openAccountDialog('signin')`; there is NO second dialog.
 *
 * Readiness gating (CRITICAL): the gate keys on the SDK's own readiness state
 * (`useOxy().canUsePrivateApi` / `isPrivateApiPending`), NEVER on app-local
 * hooks. While auth is still resolving (`isPrivateApiPending`) it renders a
 * neutral loading state so the signed-out wall never flashes before the
 * device-first cold boot concludes (the documented cold-boot race).
 *
 * Styling follows the sibling `OxyAccountDialogScreen`/`OxySignInButton` pattern —
 * `useTheme()` + `StyleSheet` (NOT NativeWind), so the gate renders correctly in
 * EVERY consumer, including apps that do not run NativeWind (e.g. the accounts
 * app).
 */
import type React from 'react';
import { type ReactNode } from 'react';
/**
 * How `RequireOxyAuth` treats a signed-out (or still-resolving) session.
 *  - `off`  — always render children (public app; a no-op provided for symmetry).
 *  - `soft` — render children, plus a dismissible sign-in banner when signed out.
 *  - `hard` — block children behind a centered signed-out state until signed in.
 */
export type RequireOxyAuthPrompt = 'off' | 'soft' | 'hard';
export interface RequireOxyAuthProps {
    children: ReactNode;
    /** Gate behavior. @default 'hard' */
    prompt?: RequireOxyAuthPrompt;
    /** Replaces the neutral loading UI shown while auth is still resolving. */
    loadingFallback?: ReactNode;
    /** Replaces the entire default signed-out wall (`prompt="hard"`). */
    signedOutFallback?: ReactNode;
    /** Title for the default `prompt="hard"` wall. */
    title?: string;
    /** Subtitle for the default `prompt="hard"` wall. */
    subtitle?: string;
    /** Message for the `prompt="soft"` banner. */
    bannerMessage?: string;
    /** CTA label for the `prompt="soft"` banner. */
    bannerActionLabel?: string;
}
/**
 * Optional signed-out gate. Wrap any subtree (or the whole app via the
 * provider's `requireAuth` prop) to opt into a shared, readiness-safe wall.
 */
export declare const RequireOxyAuth: React.FC<RequireOxyAuthProps>;
export default RequireOxyAuth;
//# sourceMappingURL=RequireOxyAuth.d.ts.map