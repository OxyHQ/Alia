import type { QueryClient } from '@tanstack/react-query';
/**
 * Patch `relationship.isFollowing` on every cached single-profile entry for
 * `targetUserId` (by-id and viewer-scoped by-username keys) after a follow
 * toggle. Lives outside `userCache.ts` so hooks like `useFollow` can import it
 * without pulling the auth store (which `userCache` uses for viewer defaults).
 */
export declare function patchCachedUserRelationship(queryClient: QueryClient, targetUserId: string, isFollowing: boolean): void;
//# sourceMappingURL=userCacheRelationship.d.ts.map