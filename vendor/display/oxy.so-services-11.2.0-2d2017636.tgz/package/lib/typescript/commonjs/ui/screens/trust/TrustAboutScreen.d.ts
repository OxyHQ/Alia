import type React from 'react';
import type { BaseScreenProps } from '../../types/navigation';
declare const TrustAboutScreen: React.FC<BaseScreenProps>;
export default TrustAboutScreen;
//# sourceMappingURL=TrustAboutScreen.d.ts.map