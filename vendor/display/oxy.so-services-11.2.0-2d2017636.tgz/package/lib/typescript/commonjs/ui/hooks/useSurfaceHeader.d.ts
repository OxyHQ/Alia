import type { DialogHeaderConfig } from '@oxy.so/bloom/dialog';
/**
 * The header content a mounted surface screen contributes at runtime: its
 * (translated) title/subtitle and optional slot nodes. Back/close affordances
 * are owned by the surface host (`SurfaceScreen`) — a screen never wires them.
 *
 * Alongside the classic slots (`left`/`right`) a screen can declare the rich
 * design-system fields Bloom's nav header supports: the single trailing
 * `primaryAction` CTA (Upload / Save), a trailing icon `actions` row, a header
 * `search` / `segments` in the large-title zone, an `onImage` `tone` over media,
 * and a wizard `progress` bar.
 *
 * Only the NODE fields (`left`/`right`/`titleContent`, and an action's `icon`)
 * must be referentially stable — a node can only be compared by identity, so an
 * inline one thrashes the header. The rich OBJECT fields are compared by value
 * (see {@link surfaceHeaderContentEqual}), so an inline `primaryAction` /
 * `actions` / `search` / `segments` / `progress` is safe to pass.
 */
export type SurfaceHeaderContent = Pick<DialogHeaderConfig, 'title' | 'titleContent' | 'subtitle' | 'largeTitle' | 'left' | 'right' | 'onBack' | 'primaryAction' | 'actions' | 'search' | 'segments' | 'tone' | 'progress'>;
interface SurfaceHeaderContextValue {
    setContent: (content: SurfaceHeaderContent | null) => void;
}
/**
 * Provided by {@link ../components/SurfaceScreen}. Bridges a screen's runtime
 * header contribution up to the host, which merges it with the back/close
 * wiring and drives the Dialog's own nav header. `null` outside a surface (or in
 * a headerless surface), so {@link useSurfaceHeader} is a safe no-op there.
 */
export declare const SurfaceHeaderContext: import("react").Context<SurfaceHeaderContextValue | null>;
/**
 * Declare the Dialog nav header's content from within a surface screen — its
 * title/subtitle and any action slot. Merges over nothing (the host owns
 * back/close), replaces on change, and clears on unmount. Call it unconditionally;
 * it is a no-op outside a header-mode surface.
 *
 * Screens pass an INLINE `content` object (a fresh reference every render), so the
 * push is guarded by {@link surfaceHeaderContentEqual}: the host's `setContent` is
 * called only when the VALUE actually changes. Without that guard the setState
 * would fire every render → the screen re-renders → the effect runs again → an
 * infinite update loop (React error #185) in any consumer that does not memoize
 * the object for us (i.e. anything not compiled by the React Compiler).
 */
export declare function useSurfaceHeader(content: SurfaceHeaderContent | null | undefined): void;
export {};
//# sourceMappingURL=useSurfaceHeader.d.ts.map