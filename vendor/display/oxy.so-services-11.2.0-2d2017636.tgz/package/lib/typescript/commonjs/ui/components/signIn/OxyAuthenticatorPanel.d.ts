/**
 * The account's authenticator app (TOTP), from its settings:
 *
 *   off  → "Set up" → the QR (`otpauth://`) and its setup key → the app's
 *          first code, confirmed like any sensitive change → the backup codes,
 *          shown once
 *   on   → new backup codes, or turn it off — each confirmed like any
 *          sensitive change (with the authenticator's code too)
 *
 * Once on, every sign-in (email code, link or password) asks for the app's code
 * as a second step, or a backup code.
 */
import type React from 'react';
export interface OxyAuthenticatorPanelProps {
    /** The person is done here (after saving backup codes, or turning it off). */
    onDone?: () => void;
}
export declare const OxyAuthenticatorPanel: React.FC<OxyAuthenticatorPanelProps>;
//# sourceMappingURL=OxyAuthenticatorPanel.d.ts.map