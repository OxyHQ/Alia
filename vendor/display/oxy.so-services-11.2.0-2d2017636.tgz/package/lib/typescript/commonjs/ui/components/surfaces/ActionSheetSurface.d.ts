import type React from 'react';
import { type SurfaceControls } from '@oxy.so/bloom/surfaces';
/**
 * A single choice in an {@link ActionSheetSurface} — a labelled button that
 * resolves the surface with `value` when pressed.
 */
export interface ActionSheetOption<T extends string> {
    label: string;
    value: T;
    /** Render as a destructive (negative) button. */
    destructive?: boolean;
}
export interface ActionSheetSurfaceProps<T extends string> {
    /** The presenting surface's controls (from `surfaces.present`). */
    surface: SurfaceControls;
    /** Headline. */
    title: string;
    /** Optional supporting copy. */
    message?: string;
    /** The choices; each dismisses the surface with its `value`. */
    options: ActionSheetOption<T>[];
    /** Cancel button label — dismisses with `undefined`. */
    cancelLabel: string;
}
/**
 * A multi-choice action sheet rendered as a shared-stack surface — the
 * many-option counterpart to Bloom's two-way `surfaces.confirm`. Each option
 * button resolves the surface's `present()` promise with that option's `value`;
 * cancel / backdrop / Escape resolve `undefined`. Presented via
 * {@link presentActionSheet}.
 */
export declare function ActionSheetSurface<T extends string>({ surface, title, message, options, cancelLabel, }: ActionSheetSurfaceProps<T>): React.ReactElement;
/**
 * Present an {@link ActionSheetSurface} on the shared stack and resolve with the
 * chosen option `value`, or `undefined` if cancelled/dismissed.
 */
export declare function presentActionSheet<T extends string>(options: Omit<ActionSheetSurfaceProps<T>, 'surface'>): Promise<T | undefined>;
//# sourceMappingURL=ActionSheetSurface.d.ts.map