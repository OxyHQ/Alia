import type React from 'react';
import { ScrollView } from 'react-native';
import type { FileMetadata } from '@oxy.so/core';
import type { useTheme } from '@oxy.so/bloom/theme';
type ThemeColors = ReturnType<typeof useTheme>['colors'];
/** A pre-built list row descriptor (produced by the orchestrator's memo). */
export interface FileListItem {
    id: string;
    icon?: React.ReactNode;
    title: string;
    description?: string;
    onPress: () => void;
    rightElement?: React.ReactNode;
}
export interface FileListSectionProps {
    scrollViewRef: React.RefObject<ScrollView | null>;
    filteredFiles: FileMetadata[];
    searchQuery: string;
    items: FileListItem[];
    paging: {
        loadingMore: boolean;
        hasMore: boolean;
    };
    refreshing: boolean;
    colors: ThemeColors;
    t: (key: string, vars?: Record<string, string | number>) => string;
    onRefresh: () => void;
    onLoadMore: () => void;
    onClearSearch: () => void;
    /** Rendered when there are no files at all (not a search miss). */
    renderEmptyState: () => React.ReactNode;
}
/**
 * The non-photo file list (list-style `all`/`videos`/`documents`/`audio`
 * views). Extracted verbatim from FileManagementScreen — the orchestrator
 * still owns the item construction and pagination logic and threads them in.
 */
declare const FileListSection: React.FC<FileListSectionProps>;
export default FileListSection;
//# sourceMappingURL=FileListSection.d.ts.map