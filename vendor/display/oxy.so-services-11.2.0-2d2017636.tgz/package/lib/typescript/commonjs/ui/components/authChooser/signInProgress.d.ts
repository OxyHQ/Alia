/**
 * The sign-in status line's copy (issue #691, Phase 5).
 *
 * One responsibility: map the controller's DERIVED `signIn.progress` — plus the
 * chosen route, which only disambiguates the generic waiting step — onto a
 * sentence. Pure and total, with no clock and no state of its own: the line can
 * therefore only advance when the controller observed a real signal, never on a
 * timer and never optimistically.
 *
 * The ladder the user sees:
 *
 *     Preparing request
 *     Check Commons on your phone
 *     Opened in Commons
 *     Confirming identity
 *     Identity confirmed
 */
import type { CommonsDeliveryRoute } from '@oxy.so/core';
import type { SignInProgress } from '@oxy.so/core/session';
import type { Translate } from './types';
/**
 * The status sentence for the active request, or `null` when there is nothing
 * honest to say (no live request, or a terminal error — which is toasted, never
 * rendered inline).
 */
export declare function signInProgressLabel(progress: SignInProgress, route: CommonsDeliveryRoute | null, t: Translate): string | null;
//# sourceMappingURL=signInProgress.d.ts.map