import type { FC, ReactNode } from 'react';
/** Native keyboard integration is an explicit, statically checked dependency. */
export declare const KeyboardBoundary: FC<{
    children: ReactNode;
}>;
//# sourceMappingURL=KeyboardBoundary.native.d.ts.map