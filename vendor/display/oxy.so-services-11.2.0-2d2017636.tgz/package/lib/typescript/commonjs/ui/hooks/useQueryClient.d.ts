import type { QueryClient } from '@tanstack/react-query';
/**
 * Custom hook to access the QueryClient
 * Provides type safety and ensures client is available
 */
export declare const useQueryClient: () => QueryClient;
//# sourceMappingURL=useQueryClient.d.ts.map