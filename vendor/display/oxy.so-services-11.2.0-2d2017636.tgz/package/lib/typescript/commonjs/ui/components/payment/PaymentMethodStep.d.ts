import type React from 'react';
import type { PaymentMethod, PaymentColors, PaymentStepAnimations } from './types';
interface PaymentMethodStepProps {
    availablePaymentMethods: PaymentMethod[];
    selectedMethod: string;
    onSelectMethod: (method: string) => void;
    colors: PaymentColors;
    animations: PaymentStepAnimations;
    onBack: () => void;
    onNext: () => void;
}
declare const PaymentMethodStep: React.FC<PaymentMethodStepProps>;
export default PaymentMethodStep;
//# sourceMappingURL=PaymentMethodStep.d.ts.map