import type React from 'react';
import type { FollowGraphSort } from '@oxy.so/core';
import type { BaseScreenProps } from '../types/navigation';
interface FollowingListScreenProps extends BaseScreenProps {
    userId: string;
    initialCount?: number;
    /** List ordering — see `UserListScreen`. Omitted ⇒ the server default. */
    sort?: FollowGraphSort;
}
declare const FollowingListScreen: React.FC<FollowingListScreenProps>;
export default FollowingListScreen;
//# sourceMappingURL=FollowingListScreen.d.ts.map