/**
 * The ACTIVE REQUEST surface (`qr` view) as the account dialog drives it —
 * `AccountDialogController`'s device flow bound to the shared, presentational
 * {@link OxySignInRequestSurface} (issue #691, Phase 5).
 *
 * This module owns WIRING only. Every pixel comes from the shared surface, which
 * the auth.oxy.so IdP mounts from its own OAuth-bound request; there is one
 * implementation of the request presentation, not two. What lives here is what
 * only the account dialog knows:
 *
 *  - which of the controller's facts map onto the surface's props;
 *  - which alternatives are genuine ones for the CURRENT presentation (a QR
 *    link is redundant while the QR itself is the primary visual);
 *  - the one piece of local intent the controller has no opinion on: leaving the
 *    acquisition surface via "I have Commons on another device".
 *
 * Failures are NOT rendered here. The container toasts them at the point they
 * arrive (owner mandate: no error renders inline inside the dialog); this view
 * only reports that the request failed, so the surface can offer "Try again".
 */
import type React from 'react';
import type { AccountDialogSnapshot } from '@oxy.so/core/session';
import type { SignInAlternatives, Translate } from './types';
interface SignInRequestViewProps {
    snapshot: AccountDialogSnapshot;
    t: Translate;
    /** Restart the request after a failure. */
    onRetry: () => void;
    alternatives: SignInAlternatives;
}
declare const SignInRequestView: React.FC<SignInRequestViewProps>;
export default SignInRequestView;
//# sourceMappingURL=SignInRequestView.d.ts.map