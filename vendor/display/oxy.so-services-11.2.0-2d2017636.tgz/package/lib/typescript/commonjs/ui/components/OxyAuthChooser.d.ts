/**
 * OxyAuthChooser — the account switcher + sign-in/sign-up surface, WITHOUT
 * any dialog chrome.
 *
 * A thin React Native binding over the headless `AccountDialogController` in
 * `@oxy.so/core` (bound via `useSyncExternalStore`) — the same data/state
 * machine {@link OxyAccountDialogScreen} renders, extracted so it can be mounted in
 * TWO places: wrapped in Bloom's `<Dialog>` by `OxyAccountDialogScreen` (the normal
 * in-app surface), and mountable bare by any other host — same chooser, two
 * completion strategies via the `onComplete` prop. Neither host duplicates view
 * logic.
 *
 * This file owns WIRING only: the controller binding, the action handlers, and
 * which view module renders. Every view lives in `./authChooser/`, one
 * responsibility each:
 *
 *  - `accounts` → `AccountsMenuView` — the signed-in Oxy account menu.
 *  - `add` / `signin` → `OxySignInPanel` — THE sign-in screen, the one
 *    auth.oxy.so renders too: the device's accounts, then the Commons way in
 *    (the embedded QR, or "Continue with Oxy"), then an email or username —
 *    a code or link by email, a password, the authenticator — all in place.
 *  - `qr` → `SignInRequestView` — the ACTIVE REQUEST: the controller-bound
 *    wiring over the shared, presentational `OxySignInRequestSurface` (the same
 *    component the auth.oxy.so IdP mounts from its OAuth-bound request). It maps
 *    `snapshot.signIn` onto that surface's props; alternatives stay behind
 *    "Having trouble?" until the chosen route reports `routeFailed`.
 *  - `signup` → `OxySignUpPanel` — account creation, in place: a username, an
 *    email and its code (Commons stays the recommended way to hold a key).
 *
 * Per-account color re-theming uses Bloom's `APP_COLOR_PRESETS` + `BloomColorScope`
 * (same visual language auth.oxy.so uses). Base theming is `useTheme()` + a
 * `StyleSheet`, so this renders correctly in EVERY consumer — including apps
 * that do not use NativeWind (e.g. the accounts app).
 */
import type React from 'react';
export interface OxyAuthChooserProps {
    /** Called after a completed switch, sign-in, or sign-up. */
    onComplete?: () => void;
}
/**
 * The account switcher + sign-in/sign-up chooser. Mounted by `OxyAccountDialogScreen`
 * (wrapped in Bloom's `<Dialog>`) today; mountable bare by any future host that
 * supplies its own `onComplete`.
 */
declare const OxyAuthChooser: React.FC<OxyAuthChooserProps>;
export default OxyAuthChooser;
//# sourceMappingURL=OxyAuthChooser.d.ts.map