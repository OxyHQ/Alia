import React from 'react';
import type { BaseScreenProps } from '../types/navigation';
declare const _default: React.NamedExoticComponent<BaseScreenProps>;
export default _default;
//# sourceMappingURL=SearchSettingsScreen.d.ts.map