/**
 * The photos the sign-in split card's carousel turns through. Shipped with the
 * SDK and imported like its icon fonts, so every host serves them from its own
 * origin — nothing to allow in anyone's CSP.
 */
import type { AuthMediaSlide } from '@oxy.so/bloom/auth-card';
export declare const SIGN_IN_SLIDES: AuthMediaSlide[];
//# sourceMappingURL=artwork.d.ts.map