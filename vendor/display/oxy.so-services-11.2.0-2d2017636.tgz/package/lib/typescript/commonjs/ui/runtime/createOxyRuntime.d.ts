import type { DeviceDirectory, DeviceSessionState } from '@oxy.so/contracts';
import type { ClientSession, User } from '@oxy.so/core';
import type { IdentitySessionBinding } from '../session/identityBinding';
import type { OxyRuntimeSnapshot } from './types';
/**
 * A change of SUBJECT — the account the session acts as.
 *
 * `previous === null` is an initial sign-in (nothing account-scoped is cached
 * yet); `next === null` is a sign-out; both non-null and different is a switch,
 * the only case that must invalidate a warm cache.
 */
export interface SubjectTransition {
    previous: string | null;
    next: string | null;
}
/**
 * The three seams the runtime reads, declared STRUCTURALLY rather than as the
 * concrete `OxyServices` / `SessionClient` / `SessionClientHost` types.
 *
 * The real classes satisfy them, so nothing changes at the call site — but a
 * test can hand the runtime three plain objects instead of casting a stub
 * through `unknown`, which is how a stub silently drifts from the interface it
 * pretends to implement.
 */
export interface RuntimeClient {
    session: {
        readonly accessToken: string | null;
    };
    users: {
        getMany(ids: string[]): Promise<User[]>;
    };
}
export interface RuntimeSessionClient {
    getState(): DeviceSessionState | null;
    getDirectory(): DeviceDirectory | null;
    subscribe(listener: (state: DeviceSessionState | null) => void): () => void;
    refreshDirectory(): Promise<void>;
    activateContext(contextId: string): Promise<void>;
    signOutContext(contextId: string): Promise<void>;
    signOutPrincipal(principalId: string): Promise<void>;
}
export interface RuntimeSessionHost {
    setCurrentAccountId(accountId: string | null): void;
}
export interface OxyRuntimeConfig {
    oxyServices: RuntimeClient;
    sessionClient: RuntimeSessionClient;
    sessionClientHost: RuntimeSessionHost;
    /** `null` for every account-mode runtime; the pin binding in identity mode. */
    identity: IdentitySessionBinding | null;
    /**
     * Reset account-scoped caches. Called BETWEEN the bearer commit and the
     * snapshot publish, which is the whole point of routing every fact change
     * through one transition (ADR 0002's ordering invariant): a consumer woken by
     * a switch must never read a cache entry belonging to the previous subject.
     */
    onSubjectChange?: (transition: SubjectTransition) => void;
    /**
     * The device reports zero accounts. Local UI teardown only — the durable
     * device credential is the caller's decision, gated on a `request`-origin
     * verdict.
     */
    onDeviceEmpty: () => Promise<void>;
    /** Persist the projected session-id list (display/bookkeeping storage). */
    onSessionsProjected?: (sessionIds: string[]) => void;
    /**
     * Identity mode only: the pinned account is unknown or has left this device's
     * session set, so the session must be re-derived from the local identity key.
     * Projecting anything here would mean projecting somebody else's account.
     */
    onIdentityUnbound?: (binding: IdentitySessionBinding, revision: number) => void;
    logger: (message: string, error?: unknown) => void;
}
/**
 * The headless session runtime (ADR 0004).
 *
 * It owns the session facts and the ORDER in which they become visible. React
 * is an adapter: the provider hands components this object and they subscribe
 * with selectors, so an unrelated change (a locale, a dialog opening) cannot
 * rebuild an auth consumer's view.
 */
export interface OxyRuntime {
    getSnapshot(): OxyRuntimeSnapshot;
    subscribe(listener: () => void): () => void;
    /** Begin projecting `SessionClient` transitions. Returns the disposer. */
    start(): () => void;
    /**
     * Project the client's current device state onto the snapshot. Idempotent and
     * revision-guarded: a projection whose profile fetch was overtaken by a
     * fresher state discards itself rather than publishing a stale subject. It is
     * also teardown-guarded: one started before {@link clearSession} publishes
     * nothing, whatever `SessionClient` still holds.
     */
    reconcileFromClient(): Promise<void>;
    /** Read the device directory and publish it (opts this runtime into ADR 0002). */
    refreshDirectory(): Promise<void>;
    /**
     * Make one `principal acting as account` context active (ADR 0002).
     *
     * `contextId`, never an account id: on a device holding two people the same
     * organization is reachable through both, and an account id cannot name which
     * route to take.
     */
    activateContext(contextId: string): Promise<void>;
    /**
     * Remove ONE `principal → account` pair. The same account reached through a
     * second person is a different session with a different audit actor, and it
     * stays.
     *
     * Context ids are NOT stable across a removal: the server offers the pair
     * again under a NEW id on the next directory read, so nothing may cache one
     * across this call.
     */
    signOutContext(contextId: string): Promise<void>;
    /** Remove ONE PERSON and every context they reach, and nobody else's. */
    signOutPrincipal(principalId: string): Promise<void>;
    /**
     * Run several fact changes as ONE transition.
     *
     * A session commit sets the optimistic session mirror, the active session id
     * and the account. Left as three transitions those are three publishes, and
     * — worse — the account is compared against a different baseline each time,
     * so an account-scoped cache reset could run against a half-applied session.
     * Batched, subscribers are woken once, after all of it, with the reset having
     * run exactly once in between.
     */
    batch(mutate: () => void): void;
    setAccount(user: User): void;
    setLoading(loading: boolean): void;
    setError(error: string | null): void;
    setStorageReady(ready: boolean): void;
    setTokenReady(ready: boolean): void;
    setHasAccessToken(has: boolean): void;
    setSwitching(switching: boolean): void;
    markAuthResolved(): void;
    /**
     * Merge an optimistic local session mirror so the UI moves before the server
     * round-trip. The authoritative projection overwrites it a moment later; both
     * write the SAME field, so there is still exactly one owner.
     */
    mergeSessions(incoming: ClientSession[], options?: {
        merge?: boolean;
        preserveSessionIds?: string[];
    }): void;
    setActiveSessionId(sessionId: string | null): void;
    /**
     * Local teardown: drop the session projection without touching the server.
     * Every projection already in flight is abandoned.
     */
    clearSession(): void;
}
export declare function createOxyRuntime(config: OxyRuntimeConfig): OxyRuntime;
//# sourceMappingURL=createOxyRuntime.d.ts.map