import type React from 'react';
import { type DialogControlProps } from '@oxy.so/bloom/dialog';
import type { PendingUploadFile } from '../../screens/fileManagement/shared';
interface UploadPreviewProps {
    control?: DialogControlProps;
    pendingFiles: PendingUploadFile[];
    onConfirm: () => void;
    onCancel: () => void;
    onRemoveFile: (id: string) => void;
    inline?: boolean;
}
export declare const UploadPreview: React.FC<UploadPreviewProps>;
export {};
//# sourceMappingURL=UploadPreview.d.ts.map