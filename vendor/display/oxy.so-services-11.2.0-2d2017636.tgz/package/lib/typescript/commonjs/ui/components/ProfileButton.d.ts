import type React from 'react';
import type { StyleProp, ViewStyle } from 'react-native';
import type { AccountDialogMenuItem } from '../navigation/accountDialogManager';
export interface ProfileButtonProps {
    /**
     * Expanded row (avatar + name + handle + chevron) when `true` (default), or a
     * bare avatar-only trigger when `false` (collapsed sidebar).
     */
    expanded?: boolean;
    /**
     * Avatar diameter in px. Defaults to 40 when expanded, 32 when collapsed.
     */
    avatarSize?: number;
    /** Navigate to the "Manage account" surface (settings). */
    onNavigateManage?: () => void;
    /** Start the add-account / sign-in flow for an additional account. */
    onAddAccount?: () => void;
    /** Optional: navigate to the signed-in user's own profile. */
    onNavigateProfile?: () => void;
    /** App-owned actions rendered in the shared account menu. */
    menuItems?: readonly AccountDialogMenuItem[];
    /**
     * Retained for source compatibility. The trigger now opens the unified
     * `OxyAccountDialogScreen` (a centered / bottom-sheet modal) rather than an
     * anchored popover, so popover placement no longer applies.
     */
    placement?: 'up' | 'down' | 'auto';
    /**
     * Extra className applied to the outer trigger. Kept for NativeWind consumers
     * that layer utility classes on top; the component's own layout is driven by
     * `StyleSheet` so it renders correctly with or without NativeWind.
     */
    className?: string;
    /** Extra style applied to the outer trigger. */
    style?: StyleProp<ViewStyle>;
}
/** Account business binding over Bloom's shared Button and Avatar. */
declare const ProfileButton: React.FC<ProfileButtonProps>;
export default ProfileButton;
//# sourceMappingURL=ProfileButton.d.ts.map