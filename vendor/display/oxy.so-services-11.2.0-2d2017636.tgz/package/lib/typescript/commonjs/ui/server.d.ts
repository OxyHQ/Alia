/**
 * Server-safe UI exports (noops)
 *
 * Import from this module for SSR environments where React components
 * shouldn't be rendered on the server.
 *
 * @example
 * import { OxyProvider, useOxy } from '@oxy.so/services/ui/server';
 */
export declare const OxyProvider: () => null;
export declare const OxySignInButton: () => null;
export declare const LogoIcon: () => null;
export declare const LogoText: () => null;
export declare const FollowButton: () => null;
export declare const PeableButton: () => null;
/** @deprecated Use `PeableButton` instead. */
export declare const OxyPayButton: () => null;
export declare const useOxy: () => {};
export declare const useAuth: () => {};
export declare const useFollow: () => {};
export declare const useStorage: () => {
    storage: null;
    isReady: boolean;
};
export declare const ProfileScreen: () => null;
export declare const useAuthStore: () => {};
export declare const toast: (() => void) & {
    success: () => void;
    error: () => void;
    info: () => void;
    warning: () => void;
    loading: () => void;
    dismiss: () => void;
};
export { handleAuthError, isInvalidSessionError, isTimeoutOrNetworkError, extractErrorMessage, } from './utils/errorHandlers';
export type { HandleAuthErrorOptions } from './utils/errorHandlers';
//# sourceMappingURL=server.d.ts.map