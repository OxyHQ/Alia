import type React from 'react';
import type { CardDetails, PaymentColors, PaymentStepAnimations } from './types';
interface PaymentDetailsStepProps {
    paymentMethod: string;
    cardDetails: CardDetails;
    onCardDetailsChange: (details: CardDetails) => void;
    colors: PaymentColors;
    animations: PaymentStepAnimations;
    faircoinAddress: string;
    isMobile: boolean;
    qrSize: number;
    onBack: () => void;
    onNext: () => void;
    QRCodeComponent?: React.ComponentType<{
        value?: string;
        size?: number;
    }>;
}
declare const PaymentDetailsStep: React.FC<PaymentDetailsStepProps>;
export default PaymentDetailsStep;
//# sourceMappingURL=PaymentDetailsStep.d.ts.map