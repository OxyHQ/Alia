/**
 * Switch active session
 */
export declare const useSwitchSession: () => import("@tanstack/react-query").UseMutationResult<import("@oxy.so/core").User, Error, string, unknown>;
/**
 * Logout from a session
 */
export declare const useLogoutSession: () => import("@tanstack/react-query").UseMutationResult<string, Error, string | undefined, {
    previousSessions: unknown;
}>;
/**
 * Logout from all sessions
 */
export declare const useLogoutAll: () => import("@tanstack/react-query").UseMutationResult<void, Error, void, unknown>;
/**
 * Update device name
 */
export declare const useUpdateDeviceName: () => import("@tanstack/react-query").UseMutationResult<{
    success: boolean;
    message: string;
    deviceName: string;
}, Error, string, unknown>;
/**
 * Remove a device
 */
export declare const useRemoveDevice: () => import("@tanstack/react-query").UseMutationResult<string, Error, string, unknown>;
//# sourceMappingURL=useServicesMutations.d.ts.map