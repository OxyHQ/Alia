/**
 * Creating an Oxy account, in the account dialog of every app (web and native)
 * and on auth.oxy.so's `/login`:
 *
 *   username → email → the code sent to it → signed in
 *
 * The email is confirmed before the account exists, and it is how the account
 * signs in (a code or a link each time). A password and an authenticator app
 * are added later, in the account's security settings. Commons stays the way to
 * hold your own key: "Create it in Commons instead" — and linking Commons later
 * makes the account self-custodied and deletes the email.
 */
import type React from 'react';
export interface OxySignUpPanelProps {
    /** The account exists and this origin is signed in as it. */
    onSignedIn: () => void;
    /** "Already have an account? Sign in". */
    onSignIn: () => void;
    /**
     * `dialog` — inside the account dialog, where the step outlives a remount of
     * this screen (`signInFlowStore`). `page` — a page of its own.
     */
    host?: 'dialog' | 'page';
}
export declare const OxySignUpPanel: React.FC<OxySignUpPanelProps>;
//# sourceMappingURL=OxySignUpPanel.d.ts.map