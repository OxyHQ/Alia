/**
 * Per-surface system-back handlers (Android hardware back + web Escape).
 *
 * Bloom's `SurfaceHost` dismisses the whole top surface on back/Escape. The SDK
 * needs the old `BottomSheetRouter` semantics first: pop nav history, step a
 * wizard back, then dismiss. A single global listener delegates to the topmost
 * registered handler so stacked surfaces route correctly.
 */
export type SurfaceBackHandler = () => boolean;
/** Push a handler for one live surface; returns unregister. */
export declare function pushSurfaceBackHandler(handler: SurfaceBackHandler): () => void;
/** Test-only: invoke the top handler. */
export declare function __invokeTopSurfaceBackForTests(): boolean;
/** Test-only reset. */
export declare function __resetSurfaceBackBridgeForTests(): void;
//# sourceMappingURL=surfaceBackBridge.d.ts.map