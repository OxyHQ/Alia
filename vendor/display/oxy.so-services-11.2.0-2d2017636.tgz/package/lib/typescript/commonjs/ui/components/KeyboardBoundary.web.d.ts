import type { FC, ReactNode } from 'react';
/** Web has no native keyboard-controller lifecycle. */
export declare const KeyboardBoundary: FC<{
    children: ReactNode;
}>;
//# sourceMappingURL=KeyboardBoundary.web.d.ts.map