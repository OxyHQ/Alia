/**
 * The storage format and restore rules shared by the SDK's two query caches:
 * the account-agnostic one (`attachQueryPersistence`) and the per-account one
 * (`createAccountQueryPersistence`).
 *
 * A blob is `{ buster, timestamp, clientState }`, TanStack's persisted-client
 * shape. Restoring it treats its two halves differently:
 *
 * - Queries are served before any refetch, so a query written by another
 *   build, in whatever shape that build used, is dropped (`getOxyBuildId`).
 * - Paused mutations are the user's queued actions (a star, a send made
 *   offline). A deploy must not lose them, so they are restored whatever build
 *   wrote them; the current build's `setMutationDefaults` replays them.
 */
import { type Mutation, type Query, type QueryClient } from '@tanstack/react-query';
/** The SDK's own account-agnostic query roots, persisted by `attachQueryPersistence`. */
export declare const PERSISTED_QUERY_PREFIXES: ReadonlyArray<string>;
/**
 * SDK queries whose data (or key) carries a signed, expiring URL. Never
 * written to disk: a restored one would serve an expired URL.
 */
export declare const SDK_MEMORY_ONLY_ROOTS: ReadonlyArray<string>;
export interface PersistFilters {
    shouldDehydrateQuery: (query: Query) => boolean;
    shouldDehydrateMutation: (mutation: Mutation) => boolean;
}
export declare function rootOf(query: Query): string | null;
/** Serialize what the filters select, stamped with this build. */
export declare function snapshot(queryClient: QueryClient, filters: PersistFilters): string;
/**
 * Hydrate a stored blob into the client, synchronously, so a caller can check
 * it is still wanted immediately before. Returns false when there was nothing
 * usable (absent, unreadable or expired), in which case the caller removes it.
 */
export declare function hydrateSnapshot(queryClient: QueryClient, raw: string | null, maxAge: number): boolean;
/**
 * Write the filtered cache on every change, at most once per `throttleMs`.
 * `write` receives the serialized snapshot; `flush()` writes now.
 */
export declare function subscribeSnapshots(queryClient: QueryClient, filters: PersistFilters, throttleMs: number, write: (serialized: string) => void): {
    flush: () => void;
    unsubscribe: () => void;
};
//# sourceMappingURL=persistedQueryCache.d.ts.map