import type React from 'react';
import type { BaseScreenProps } from '../types/navigation';
/** `LinkCommons`: make the account self-custodied with the key Commons holds. */
declare const LinkCommonsScreen: React.FC<BaseScreenProps>;
export default LinkCommonsScreen;
//# sourceMappingURL=LinkCommonsScreen.d.ts.map