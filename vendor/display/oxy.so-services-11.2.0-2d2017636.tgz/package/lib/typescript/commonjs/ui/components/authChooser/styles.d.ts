/**
 * Shared styles for `OxyAuthChooser`'s views. Extracted from `OxyAccountDialogScreen`
 * so both the Dialog-wrapped host and any bare host (e.g. a future
 * auth.oxy.so hub page) render identically without duplicating a StyleSheet.
 *
 * Only what NativeWind cannot express lives here: the animated collapse, the
 * fixed-contrast QR plate, per-account accent rings, and the small subordinate
 * text-link rhythm every view's fallback affordances share.
 */
export declare const authChooserStyles: {
    /**
     * Animated-collapse container for the account switch list — the outer clip and
     * the inner measuring wrapper. Style-based (NOT NativeWind): the container
     * carries the animated `height`/`opacity` off a reanimated style, and the
     * measuring wrapper must stay className-free so its `onLayout` fires on RN-Web.
     */
    collapse: {
        overflow: "hidden";
    };
    collapseMeasure: {
        width: "100%";
    };
    /**
     * The HERO block that opens the account menu: the current account's large
     * avatar, a greeting, and the "Manage your Oxy account" pill — centred and
     * deliberately chrome-free (no card, no grouped-section surface) so the
     * grouped cards below read as the menu proper. The account's email sits above
     * it in the Dialog's own nav bar, not here.
     */
    hero: {
        alignItems: "center";
        paddingTop: number;
        paddingBottom: number;
        gap: number;
    };
    /**
     * The current account's accent ring in the switch list, drawn OUTSIDE its
     * avatar as an overlay so it adds no width to the row — every avatar in the
     * list keeps the same footprint and the same content line. The 3px offset is
     * the ring's 2px stroke plus a 1px gap.
     */
    currentAvatarRing: {
        position: "absolute";
        top: number;
        left: number;
        right: number;
        bottom: number;
        borderWidth: number;
        borderRadius: number;
    };
    /**
     * The hero avatar's pressable wrapper — the "change your photo" entry point.
     * `relative` so the accent ring + camera badge (both absolutely positioned)
     * anchor to the avatar box.
     */
    heroAvatarPressable: {
        position: "relative";
    };
    /** The hero avatar's accent ring — an overlay, like the row-level one. */
    heroAvatarRing: {
        position: "absolute";
        top: number;
        left: number;
        right: number;
        bottom: number;
        borderWidth: number;
        borderRadius: number;
    };
    /** Greeting + address stacked tight, centred (the hero's own 12px gap sits
     *  between this block and the avatar / manage pill, not between these lines). */
    heroNameBlock: {
        alignItems: "center";
        gap: number;
    };
    heroGreeting: {
        fontSize: number;
        fontWeight: "600";
        textAlign: "center";
    };
    /** The account address (`username@oxy.so` / `@handle`) under the greeting. */
    heroAddress: {
        fontSize: number;
        textAlign: "center";
    };
    /**
     * The switch row's disclosure affordance — a filled circle around the chevron,
     * right-aligned to the same 12px row inset every other trailing element uses.
     */
    chevronCircle: {
        width: number;
        height: number;
        borderRadius: number;
        alignItems: "center";
        justifyContent: "center";
    };
    footerLink: {
        alignSelf: "center";
        paddingTop: number;
        paddingBottom: number;
        marginTop: number;
    };
    linkText: {
        fontSize: number;
        fontWeight: "600";
    };
    primaryButton: {
        width: "100%";
        borderRadius: number;
        marginTop: number;
    };
    centeredBlock: {
        alignItems: "center";
        justifyContent: "center";
        gap: number;
        paddingVertical: number;
    };
    mutedText: {
        fontSize: number;
        textAlign: "center";
    };
    qrHeadline: {
        fontSize: number;
        fontWeight: "700";
        textAlign: "center";
    };
    qrPlate: {
        padding: number;
        borderRadius: number;
        backgroundColor: string;
    };
    /**
     * The revealed "Having trouble?" alternatives — a tight stack of subordinate
     * text links. They share `footerLink`'s rhythm, so the stack itself only has
     * to stop them drifting apart.
     */
    troubleActions: {
        width: "100%";
        alignItems: "center";
    };
    /**
     * The disclosure spans the content width, so the alternatives it reveals are
     * centred across the sheet rather than inside the trigger's own width. It
     * used to be `alignSelf: 'center'` — shrink-wrapped — and on Android that
     * both wrapped the trigger to "Having / trouble?" and squeezed the revealed
     * links into the same narrow column (OxyHQ/oxy#1375).
     */
    troubleDisclosure: {
        width: "100%";
        marginTop: number;
    };
    /** The trigger itself stays a compact, centred affordance like the links. */
    troubleTrigger: {
        alignSelf: "center";
    };
};
//# sourceMappingURL=styles.d.ts.map