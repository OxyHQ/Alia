import type React from 'react';
import type { BaseScreenProps } from '../types/navigation';
/**
 * Unified "Manage your Oxy Account" screen.
 *
 * Replaces AccountOverview + AccountSettings + the per-account half of
 * SessionManagement. Lists ONLY the active user's profile, sessions on this
 * device, and security/destructive actions for THIS account. Multi-account
 * surface lives in the unified `OxyAccountDialogScreen` — keep these concerns separate.
 */
declare const ManageAccountScreen: React.FC<BaseScreenProps>;
export default ManageAccountScreen;
//# sourceMappingURL=ManageAccountScreen.d.ts.map