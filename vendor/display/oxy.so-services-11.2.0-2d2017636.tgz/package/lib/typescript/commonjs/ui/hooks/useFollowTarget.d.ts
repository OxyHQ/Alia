/**
 * `useFollowTarget` — the one hook every application uses to follow anything.
 *
 * Wraps the `/v2/follows` SDK methods with the store above, an optimistic
 * update, and a rollback. Nothing in here knows what kind of thing it is
 * following, which is the property that lets an application the SDK has never
 * heard of use it without a release of this package.
 *
 * ## Optimism, and its one limit
 *
 * A follow flips the button immediately and rolls back if the server refuses,
 * because the round trip is long enough to feel like a bug otherwise. But an
 * optimistic follow has no relationship id until the server answers, and every
 * other operation addresses the relationship — so those stay disabled for the
 * width of one request rather than being sent with a guessed id.
 */
import type { FollowStatus } from '@oxy.so/contracts';
export interface UseFollowTargetResult {
    status: FollowStatus;
    /**
     * Whether the user follows this at all — NOT `effectiveState`, which reports
     * `not_following` for a follow merely switched off in this application.
     */
    isFollowing: boolean;
    /** True until the first read settles. Distinct from "not following". */
    isUnknown: boolean;
    isPending: boolean;
    error: string | undefined;
    /**
     * Every mutation resolves to whether the server ACCEPTED it.
     *
     * They never reject — a refusal becomes `error` in the store, so the button
     * can render it — which means a caller that only awaits them cannot tell a
     * write that happened from one that did not. Returning the outcome is what
     * lets a caller mirror the change somewhere else without mirroring failures
     * too.
     */
    follow: (options?: {
        expiresIn?: number;
    }) => Promise<boolean>;
    unfollow: () => Promise<boolean>;
    /** Stop acting on this follow HERE, without giving it up everywhere. */
    disableHere: () => Promise<boolean>;
    enableHere: () => Promise<boolean>;
    refresh: () => Promise<void>;
}
export declare function useFollowTarget(targetId: string | undefined, options?: {
    initialStatus?: FollowStatus;
}): UseFollowTargetResult;
//# sourceMappingURL=useFollowTarget.d.ts.map