import type React from 'react';
import type { FileMetadata } from '@oxy.so/core';
interface FileViewerProps {
    file: FileMetadata;
    fileContent: string | null;
    loadingFileContent: boolean;
    showFileDetailsInViewer: boolean;
    onToggleDetails: () => void;
    onClose: () => void;
    onDownload: (fileId: string, filename: string) => void;
    onDelete: (fileId: string, filename: string) => void;
    isOwner: boolean;
}
export declare const FileViewer: React.FC<FileViewerProps>;
export {};
//# sourceMappingURL=FileViewer.d.ts.map