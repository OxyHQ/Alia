/**
 * User file-library queries + cache helpers.
 *
 * The file list is owned by React Query (`useInfiniteQuery`), NOT a zustand
 * store: server pages live in the query cache, and every optimistic mutation
 * (upload / delete / visibility) edits that cache via the pure `*InCache`
 * helpers below. The `queryFn` is side-effect-free — it only fetches and maps a
 * page. This is what lets the file manager stay effect-free while preserving
 * infinite scroll, pull-to-refresh, and optimistic upload reconciliation.
 */
import { type InfiniteData, type QueryClient } from '@tanstack/react-query';
import type { FileMetadata } from '@oxy.so/core';
/** Files fetched per page. */
export declare const FILES_PAGE_SIZE = 40;
/** Raw file record as returned by `oxyServices.assets.list` / `assetUpload`. */
export interface RawUserFile {
    id: string;
    originalName?: string;
    sha256?: string;
    mime?: string;
    size?: number;
    createdAt?: string;
    metadata?: Record<string, unknown>;
    variants?: unknown[];
}
/** One page of the infinite file list. */
export interface UserFilesPage {
    files: FileMetadata[];
    total: number;
    hasMore: boolean;
    nextOffset: number;
}
export type UserFilesInfinite = InfiniteData<UserFilesPage>;
/** Normalize a raw API file record into the client `FileMetadata` shape. */
export declare function mapRawFileToMetadata(raw: RawUserFile): FileMetadata;
/**
 * Infinite-paginated list of the owner's files. Fires on mount and whenever
 * `ownerId` changes (a new key); `staleTime: 0` reloads on every open. The
 * rendered list is `data.pages.flatMap(p => p.files)`.
 */
export declare const useUserFilesInfinite: (ownerId?: string) => import("@tanstack/react-query").UseInfiniteQueryResult<InfiniteData<UserFilesPage, unknown>, Error>;
/** Prepend an (optimistic) file to the first page. */
export declare function prependFileToCache(queryClient: QueryClient, ownerId: string | undefined, file: FileMetadata): void;
/** Remove a file (by id) from every page. */
export declare function removeFileFromCache(queryClient: QueryClient, ownerId: string | undefined, fileId: string): void;
/** Swap an optimistic file (by id) for its persisted counterpart. */
export declare function replaceFileInCache(queryClient: QueryClient, ownerId: string | undefined, oldId: string, newFile: FileMetadata): void;
/** Shallow-merge a metadata patch into a cached file (e.g. visibility change). */
export declare function patchFileMetadataInCache(queryClient: QueryClient, ownerId: string | undefined, fileId: string, metadataPatch: Record<string, unknown>): void;
//# sourceMappingURL=useFileQueries.d.ts.map