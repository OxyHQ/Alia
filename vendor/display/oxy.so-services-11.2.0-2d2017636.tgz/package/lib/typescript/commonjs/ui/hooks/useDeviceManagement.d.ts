import type { ApiError } from '@oxy.so/core';
import type { OxyServices } from '@oxy.so/core';
export interface UseDeviceManagementOptions {
    oxyServices: OxyServices;
    activeSessionId: string | null;
    onError?: (error: ApiError) => void;
    clearSessionState: () => Promise<void>;
    logger?: (message: string, error?: unknown) => void;
}
export interface UseDeviceManagementResult {
    getDeviceSessions: () => Promise<Array<{
        sessionId: string;
        deviceId: string;
        deviceName?: string;
        lastActive?: string;
        expiresAt?: string;
    }>>;
    logoutAllDeviceSessions: () => Promise<void>;
    updateDeviceName: (deviceName: string) => Promise<void>;
}
/**
 * Provide device session management helpers tied to the current active session.
 *
 * @param options - Device management configuration
 */
export declare const useDeviceManagement: ({ oxyServices, activeSessionId, onError, clearSessionState, logger, }: UseDeviceManagementOptions) => UseDeviceManagementResult;
//# sourceMappingURL=useDeviceManagement.d.ts.map