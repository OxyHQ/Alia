import type Ionicons from '../icons/Ionicons';
import type { RNFileDescriptor } from '@oxy.so/core';
import type { ComponentProps } from 'react';
/**
 * Extended File interface that includes a `uri` property for mobile preview support.
 * React Native file pickers return URI-based references that need to be preserved
 * on the File object for preview rendering.
 */
interface FileWithUri extends File {
    uri?: string;
}
/**
 * Picker descriptor as returned by expo-document-picker / expo-image-picker.
 * Carries enough info to either build a web `File` from the URI or pass the
 * descriptor straight to FormData on React Native.
 */
export interface PickerAsset {
    file?: File | Blob;
    uri?: string;
    name?: string | null;
    mimeType?: string | null;
    size?: number | null;
}
/**
 * Type guard — returns true if the input is a React Native file descriptor
 * (carries a URI but is not a real DOM `File` / `Blob` instance).
 */
export declare function isRNFileDescriptor(input: unknown): input is RNFileDescriptor;
/**
 * Format file size in bytes to human-readable string
 */
export declare function formatFileSize(bytes: number): string;
/**
 * Get icon name for file based on content type
 */
export declare function getFileIcon(contentType: string): ComponentProps<typeof Ionicons>['name'];
/**
 * Convert a document/image picker asset into a value that
 * `OxyServices.assetUpload` can accept.
 *
 * - On the web, builds a real `File` (with the `uri` field preserved for
 *   preview rendering) by fetching the asset as a Blob.
 * - On React Native (iOS/Android), returns the picker descriptor directly
 *   ({ uri, type, name, size }). RN's `FormData` reads the file from disk
 *   during the multipart upload — no in-JS Blob conversion needed. Attempting
 *   to wrap an ArrayBuffer in a Blob fails on Hermes ("Creating blobs from
 *   'ArrayBuffer' and 'ArrayBufferView' are not supported").
 */
export declare function convertDocumentPickerAssetToFile(doc: PickerAsset, index: number): Promise<FileWithUri | RNFileDescriptor | null>;
export {};
//# sourceMappingURL=fileManagement.d.ts.map