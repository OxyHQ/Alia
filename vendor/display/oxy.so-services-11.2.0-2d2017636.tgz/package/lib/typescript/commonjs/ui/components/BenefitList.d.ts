import type React from 'react';
import { type StyleProp, type TextStyle, type ViewStyle } from 'react-native';
export interface BenefitRowProps {
    /** Leading icon element, rendered inside a rounded tertiary-fill square. */
    icon: React.ReactNode;
    /** Caption text. Provide either `label` or `children`. */
    label?: string;
    /** Caption content as children (alternative to `label`). */
    children?: React.ReactNode;
    /** Accessibility label for the row (defaults to string content). */
    accessibilityLabel?: string;
    className?: string;
    style?: StyleProp<ViewStyle>;
    textStyle?: StyleProp<TextStyle>;
}
export declare const BenefitRow: React.FC<BenefitRowProps>;
export interface BenefitListProps {
    /** `BenefitRow`s (or any nodes) stacked with consistent spacing. */
    children: React.ReactNode;
    accessibilityLabel?: string;
    className?: string;
    style?: StyleProp<ViewStyle>;
}
export declare const BenefitList: React.FC<BenefitListProps>;
//# sourceMappingURL=BenefitList.d.ts.map