import type { OxyServices } from '@oxy.so/core';
export interface UseBackgroundSessionSyncInput {
    /** `OxyProviderProps.backgroundSession`. */
    enabled: boolean;
    oxyServices: OxyServices;
    /** The signed-in account, or `null` when signed out. */
    userId: string | null;
    /** Whether a bearer is available yet — provisioning needs one. */
    canUsePrivateApi: boolean;
}
/**
 * An effect is the right shape here, unusually for this codebase: the work is a
 * side effect on native storage, and it has to react both to an identity change
 * (a value) and to the app being foregrounded (a subscription). There is no
 * derived-state or React Query formulation of "write a credential to the
 * keystore when the user changes or the app comes back".
 *
 * Re-runs on identity change, which is what makes sign-out and account switching
 * work: `syncBackgroundSession` clears a credential belonging to anyone other
 * than `userId` before it does any network work.
 */
export declare function useBackgroundSessionSync({ enabled, oxyServices, userId, canUsePrivateApi, }: UseBackgroundSessionSyncInput): void;
//# sourceMappingURL=useBackgroundSessionSync.d.ts.map