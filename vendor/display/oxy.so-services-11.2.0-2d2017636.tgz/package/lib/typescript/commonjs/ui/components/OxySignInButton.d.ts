import type React from 'react';
import { type ViewStyle, type TextStyle, type StyleProp } from 'react-native';
import { type SocialButtonAction, type SocialButtonAppearance, type SocialButtonSize } from '@oxy.so/bloom/social-button';
/**
 * The OAuth handshake surfaced to a NATIVE third-party RP via
 * {@link OxySignInButtonProps.onOAuthResult} so it can finish the code exchange
 * (`POST /auth/oauth/token`). Web sign-in is handled entirely by the SDK's web
 * transport (`useOxy().startWebOAuthSignIn`) and never uses this callback.
 */
export interface OxyOAuthResult {
    /** Deep-link URL the native auth session returned to (`?code=…&state=…`), or `null` if unobserved. */
    redirectUrl: string | null;
    /** The CSRF `state` sent on the authorize request; the RP must match it on return. */
    state: string;
    /** The PKCE `code_verifier` to replay on the token exchange. */
    codeVerifier: string;
}
/** The label's verb: "Sign in with Oxy", "Continue with Oxy" or "Sign up with Oxy". */
export type OxySignInButtonAction = SocialButtonAction;
export interface OxySignInButtonProps {
    /**
     * Shorthand for {@link OxySignInButtonProps.appearance}: `contained` is the
     * filled button in the theme accent (`colorful`); `default` and `outline`
     * are the outlined button with the Oxy mark (`white`).
     * @default 'default'
     */
    variant?: 'default' | 'outline' | 'contained';
    /**
     * Bloom `SocialButton` appearance — `colorful`, `white` or `black`. Wins
     * over `variant` when both are given.
     */
    appearance?: SocialButtonAppearance;
    /**
     * The label's verb, localized: `signIn` — "Sign in with Oxy", `continue` —
     * "Continue with Oxy", `signUp` — "Sign up with Oxy".
     * @default 'signIn'
     */
    action?: OxySignInButtonAction;
    /** `md` (36 tall, 300 wide) or `sm` (32 × 250). @default 'md' */
    size?: SocialButtonSize;
    /** Fill the container's width instead of the fixed 300 / 250. */
    fullWidth?: boolean;
    /** A circular button showing only the Oxy mark; the label becomes its accessible name. */
    iconOnly?: boolean;
    /**
     * Optional function to handle button press
     * If not provided, the button will use the showBottomSheet method from OxyContext
     */
    onPress?: () => void;
    /**
     * Additional styles for the button container
     */
    style?: StyleProp<ViewStyle>;
    /**
     * Additional styles for the button text
     */
    textStyle?: StyleProp<TextStyle>;
    /**
     * Overrides the button label. When omitted the label is the localized
     * {@link OxySignInButtonProps.action} phrase.
     *
     * @default localized "Sign in with Oxy"
     */
    text?: string;
    /**
     * Whether to disable the button
     * @default false
     */
    disabled?: boolean;
    /**
     * Whether to show the button even if user is already authenticated
     * @default false
     */
    showWhenAuthenticated?: boolean;
    /**
     * Exact registered redirect URI the OAuth authorization code is returned to.
     * REQUIRED only for third-party (`type: 'third_party'`) applications, which
     * sign in via OAuth + PKCE against `auth.oxy.so`. First-party / official apps
     * open the in-app dialog and ignore this prop. If a third-party app resolves
     * without it, the button logs an error and does nothing (it will not invent a
     * redirect URI).
     */
    oauthRedirectUri?: string;
    /**
     * Native only: receives the OAuth handshake after a third-party auth session
     * so the RP can finish the token exchange. On web the SDK completes the flow
     * itself — the popup transport keeps the handshake in memory, and the
     * redirect transport reads it back from `sessionStorage` — so this is never
     * called there. A native third-party sign-in with NO `onOAuthResult` handler
     * cannot complete (the `state` + `code_verifier` are lost) and logs a warning.
     *
     * @example
     * ```tsx
     * <OxySignInButton
     *   oauthRedirectUri="myapp://oauth/callback"
     *   onOAuthResult={({ redirectUrl, state, codeVerifier }) => {
     *     if (!redirectUrl) return;
     *     const code = new URL(redirectUrl).searchParams.get('code');
     *     // → POST /auth/oauth/token, form-urlencoded:
     *     //   grant_type=authorization_code&code=…&redirect_uri=…&client_id=…&code_verifier=…
     *   }}
     * />
     * ```
     */
    onOAuthResult?: (result: OxyOAuthResult) => void;
    /** Opt in to the shared SDK native finalizer. Mutually exclusive with onOAuthResult. */
    nativeOAuthCompletion?: 'sdk';
}
/**
 * A pre-styled button component for signing in with Oxy identity
 *
 * This component opens the Oxy Auth flow which allows users to authenticate
 * using their Oxy Accounts identity (via QR code or deep link).
 *
 * @example
 * ```tsx
 * // Basic usage
 * <OxySignInButton />
 *
 * // The filled button, full width
 * <OxySignInButton variant="contained" fullWidth />
 *
 * // "Sign up with Oxy" on a registration screen
 * <OxySignInButton action="signUp" />
 *
 * // Custom handler
 * <OxySignInButton onPress={() => {
 *   // Custom authentication flow
 * }} />
 * ```
 */
export declare const OxySignInButton: React.FC<OxySignInButtonProps>;
export default OxySignInButton;
//# sourceMappingURL=OxySignInButton.d.ts.map