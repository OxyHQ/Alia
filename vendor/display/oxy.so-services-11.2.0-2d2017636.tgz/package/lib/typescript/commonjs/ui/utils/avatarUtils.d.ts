import type { OxyServices, User } from '@oxy.so/core';
import type { UserProfileUpdate } from '@oxy.so/contracts';
import type { QueryClient } from '@tanstack/react-query';
/**
 * Updates user profile with avatar and handles all side effects (cache writes,
 * query invalidation). Usable from inside the provider without `useOxy`.
 *
 * @param updates - Profile updates including avatar
 * @param oxyServices - OxyServices instance
 * @param activeSessionId - Active session ID
 * @param queryClient - TanStack Query client
 * @param syncSession - Optional function to sync session/refresh token when auth errors occur
 * @returns Promise that resolves with updated user data
 */
export declare function updateProfileWithAvatar(updates: UserProfileUpdate, oxyServices: OxyServices, activeSessionId: string | null, queryClient: QueryClient, syncSession?: () => Promise<User>): Promise<User>;
//# sourceMappingURL=avatarUtils.d.ts.map