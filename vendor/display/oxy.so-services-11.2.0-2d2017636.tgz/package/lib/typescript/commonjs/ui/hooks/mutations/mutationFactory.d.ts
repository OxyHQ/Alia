/**
 * Mutation Factory - Creates standardized mutations with optimistic updates
 *
 * This factory reduces boilerplate code for mutations that follow the common pattern:
 * 1. Cancel outgoing queries
 * 2. Snapshot previous data
 * 3. Apply optimistic update
 * 4. On error: rollback and show toast
 * 5. On success: update cache, stores, and invalidate queries
 */
import type { QueryClient, UseMutationOptions } from '@tanstack/react-query';
import type { User } from '@oxy.so/core';
/**
 * Configuration for creating a standard profile mutation
 */
export interface ProfileMutationConfig<TData, TVariables> {
    /** The mutation function that makes the API call */
    mutationFn: (variables: TVariables) => Promise<TData>;
    /**
     * Stable mutation key for the offline queue. Required so TanStack Query
     * can correlate paused mutations across refetches/resume cycles.
     */
    mutationKey: readonly unknown[];
    /** Query keys to cancel before mutation */
    cancelQueryKeys?: unknown[][];
    /** Function to apply optimistic update to the user data */
    optimisticUpdate?: (previousUser: User, variables: TVariables) => Partial<User>;
    /** Error message to show on failure */
    errorMessage?: string | ((error: Error) => string);
    /** Success message to show (optional) */
    successMessage?: string;
    /** Whether to update authStore on success (default: true) */
    updateAuthStore?: boolean;
    /** Whether to invalidate user queries on success (default: true) */
    invalidateUserQueries?: boolean;
    /** Whether to invalidate account queries on success (default: true) */
    invalidateAccountQueries?: boolean;
    /** Custom onSuccess handler */
    onSuccess?: (data: TData, variables: TVariables, queryClient: QueryClient) => void;
}
/**
 * Creates a standard profile mutation with optimistic updates
 *
 * @example
 * ```ts
 * const updateProfile = createProfileMutation({
 *   mutationKey: mutationKeys.account.updateProfile,
 *   mutationFn: (updates) => oxyServices.users.updateMe(updates),
 *   optimisticUpdate: (user, updates) => updates,
 *   errorMessage: 'Failed to update profile',
 * });
 * ```
 */
export declare function createProfileMutation<TVariables>(config: ProfileMutationConfig<User, TVariables>, queryClient: QueryClient, activeSessionId: string | null): UseMutationOptions<User, Error, TVariables, {
    previousUser?: User;
}>;
/**
 * Configuration for creating a generic mutation (non-profile)
 */
export interface GenericMutationConfig<TData, TVariables, TContext> {
    /** The mutation function */
    mutationFn: (variables: TVariables) => Promise<TData>;
    /**
     * Stable mutation key for the offline queue. Required so TanStack Query
     * can correlate paused mutations across refetches/resume cycles.
     */
    mutationKey: readonly unknown[];
    /** Query key for optimistic data */
    queryKey: unknown[];
    /** Function to create optimistic data */
    optimisticData?: (previous: TData | undefined, variables: TVariables) => TData;
    /** Error message */
    errorMessage?: string;
    /** Success message */
    successMessage?: string;
    /** Additional queries to invalidate on success */
    invalidateQueries?: unknown[][];
}
/**
 * Creates a generic mutation with optimistic updates
 */
export declare function createGenericMutation<TData, TVariables>(config: GenericMutationConfig<TData, TVariables, {
    previous?: TData;
}>, queryClient: QueryClient): UseMutationOptions<TData, Error, TVariables, {
    previous?: TData;
}>;
//# sourceMappingURL=mutationFactory.d.ts.map