import type { FC, ReactNode } from 'react';
/** Non-native fallback used by TypeScript, SSR and resolvers without platforms. */
export declare const KeyboardBoundary: FC<{
    children: ReactNode;
}>;
//# sourceMappingURL=KeyboardBoundary.d.ts.map