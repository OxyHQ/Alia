/**
 * The sign-in entry's embedded QR, over the split card's photo carousel: scan
 * it with Commons on a phone and this screen is signed in.
 *
 * It owns one QR-only request (`controller.startInlineQr()`): started the
 * first time the block is actually laid out on screen — never while its column
 * is hidden below `md` — renewed when it expires, and withdrawn when the block
 * goes away while it is still approvable. It never pushes to a phone or opens Commons —
 * the person did not ask for either by opening the screen. Any other sign-in
 * they choose supersedes it like any new attempt.
 *
 * Anti-phishing: the plate encodes `signIn.qrPayload` and renders nothing
 * derived from it; the approver resolves the app server-side.
 */
import type React from 'react';
import type { AccountDialogController } from '@oxy.so/core/session';
export declare const InlineCommonsQr: React.FC<{
    controller: AccountDialogController | null;
}>;
//# sourceMappingURL=InlineCommonsQr.d.ts.map