import type { FileMetadata } from '@oxy.so/core';
export type ViewMode = 'all' | 'photos' | 'videos' | 'documents' | 'audio';
export type SortBy = 'date' | 'size' | 'name' | 'type';
export type SortOrder = 'asc' | 'desc';
interface UseFileFilteringOptions {
    files: FileMetadata[];
    initialViewMode?: ViewMode;
    initialSortBy?: SortBy;
    initialSortOrder?: SortOrder;
}
interface UseFileFilteringReturn {
    filteredFiles: FileMetadata[];
    viewMode: ViewMode;
    setViewMode: (mode: ViewMode) => void;
    searchQuery: string;
    setSearchQuery: (query: string) => void;
    sortBy: SortBy;
    setSortBy: (sort: SortBy) => void;
    sortOrder: SortOrder;
    setSortOrder: (order: SortOrder) => void;
    toggleSortOrder: () => void;
}
/**
 * Hook for file filtering, sorting, and search functionality
 * Extracts common file management logic for reuse across components
 */
export declare function useFileFiltering({ files, initialViewMode, initialSortBy, initialSortOrder, }: UseFileFilteringOptions): UseFileFilteringReturn;
export {};
//# sourceMappingURL=useFileFiltering.d.ts.map