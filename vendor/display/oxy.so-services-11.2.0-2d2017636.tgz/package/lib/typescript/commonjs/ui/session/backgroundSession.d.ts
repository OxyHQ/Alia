import type { OxyServices } from '@oxy.so/core';
/** Whether this platform/app can hold a background credential at all. */
export declare function isBackgroundSessionSupported(): boolean;
/**
 * Drop the stored credential. No-op where unsupported, and never throws.
 *
 * Called on sign-out and BEFORE an account switch's network work, so the window
 * in which background code could still serve the previous account is as short as
 * one local write.
 */
export declare function clearBackgroundSession(): Promise<void>;
export interface BackgroundSessionSyncInput {
    oxyServices: OxyServices;
    /** The signed-in account, or `null` when signed out. */
    userId: string | null;
    /** Whether a bearer is available yet — provisioning requires one. */
    canUsePrivateApi: boolean;
    /**
     * Whether this run is still the current one. A run that loses its relevance
     * mid-flight (unmount, or another identity change) must not write the
     * credential it was about to write.
     */
    isCurrent: () => boolean;
}
/**
 * Bring the native credential in line with the session JS currently holds.
 *
 * Ordering is the load-bearing part: a credential belonging to a DIFFERENT
 * account is cleared before any network call, so a crash mid-provision leaves
 * background code signed out rather than serving the previous account's data
 * under the new account's name. The server enforces the same rule independently
 * (a mint is re-authorized against the live device session, and against its ACTIVE
 * account), so this is the fast local half of a belt-and-braces pair, not the only
 * guard.
 *
 * Every failure is caught and logged: a background credential is an
 * enhancement, and failing to provision one must not disturb the session that
 * is working.
 */
export declare function syncBackgroundSession(input: BackgroundSessionSyncInput): Promise<void>;
//# sourceMappingURL=backgroundSession.d.ts.map