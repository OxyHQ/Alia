import type React from 'react';
export interface UploadBarProps {
    uploadProgress: {
        current: number;
        total: number;
    } | null;
    t: (key: string, vars?: Record<string, string | number>) => string;
}
/** Upload state is app-owned; surface, spinner and determinate meter are Bloom. */
declare const UploadBar: React.FC<UploadBarProps>;
export default UploadBar;
//# sourceMappingURL=UploadBar.d.ts.map