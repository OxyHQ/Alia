/**
 * The signed-in Oxy account MENU (`accounts` view) — a Google-account-menu-style
 * full menu built entirely with NativeWind `className` (the dynamic per-account
 * accent hex is the one inline style NativeWind cannot express). Structure:
 *
 *  - HERO on its own chrome-free block: the current account's large pressable
 *    avatar (with a camera badge to change the photo), the greeting, the account
 *    address, and a "Manage your Oxy account" pill.
 *  - SWITCH ACCOUNT: a disclosure row whose corner animates from pill to card as
 *    the device's people + "Add another account" + "Manage accounts on this
 *    device" reveal beneath it. The list is grouped BY PERSON (ADR 0002): an
 *    account sits under the human who can operate it, and the same organization
 *    reachable through two people is two rows under two names — the thing a list
 *    keyed by account id structurally cannot say.
 *  - OXY STORAGE: cloud + used/total + a composition meter + Upgrade / Manage chips.
 *  - MENU rows: Your data in Oxy · Oxy settings · Help & feedback · Sign out —
 *    Bloom's grouped section, the same component every other SDK settings surface
 *    uses, not a local row copy.
 *  - FOOTER: Privacy Policy · Terms of Service.
 *
 * All three blocks share ONE rhythm taken from that grouped section: a 12px
 * content inset, a 12px gap after the leading element, 16px between blocks, and
 * a 16px trailing chevron column.
 *
 * Collapse state is a plain `useState` toggled in the row's press handler — no
 * effect hook, no derived-from-props sync.
 */
import type React from 'react';
import { type AccountDialogSnapshot, type SwitcherPrincipalRow } from '@oxy.so/core/session';
import { type AccountHeroModel, type AccountStorageModel, type AccountsMenuActions, type OxyAuthChooserHandlers, type Theme, type Translate } from './types';
interface AccountsMenuViewProps {
    snapshot: AccountDialogSnapshot;
    /** The device's people, each with the accounts they may act as. */
    principals: SwitcherPrincipalRow[];
    /** The current account, rendered large. `null` before the session resolves. */
    hero: AccountHeroModel | null;
    theme: Theme;
    t: Translate;
    handlers: OxyAuthChooserHandlers;
    storage: AccountStorageModel | null;
    menu: AccountsMenuActions;
}
declare const AccountsMenuView: React.FC<AccountsMenuViewProps>;
export default AccountsMenuView;
//# sourceMappingURL=AccountsMenuView.d.ts.map