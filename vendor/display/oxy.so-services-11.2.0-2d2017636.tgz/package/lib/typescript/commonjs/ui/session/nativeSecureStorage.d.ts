/**
 * The native secure key/value seam every durable `@oxy.so/core` store in this
 * package is built on.
 *
 * `@oxy.so/core` owns the store LOGIC (`createNativeAuthStateStore` for the
 * zero-cookie device credential, `createNativeIdentityPinStore` for the identity
 * pin) and takes its persistence as an injected `NativeKeyValueStorage`. This
 * module supplies that injection ONCE, so those stores can never drift onto
 * different backings — a device credential in SecureStore and a pin in
 * AsyncStorage would resolve differently after a keystore reset.
 *
 * `expo-secure-store` is loaded via a runtime-computed dynamic import (the same
 * optional-native-module pattern `OxyProvider` uses for netinfo / keyboard
 * controller), so the web bundle never pulls it and a device without it falls
 * back to AsyncStorage rather than crashing.
 */
import type { NativeKeyValueStorage } from '@oxy.so/core/session';
/**
 * A native `NativeKeyValueStorage` that prefers `expo-secure-store` (encrypted
 * at rest) and falls back to AsyncStorage when SecureStore is not installed.
 * The SecureStore module is resolved lazily on first access so construction
 * stays synchronous.
 */
export declare function createNativeSecureKeyValueStorage(): NativeKeyValueStorage;
//# sourceMappingURL=nativeSecureStorage.d.ts.map