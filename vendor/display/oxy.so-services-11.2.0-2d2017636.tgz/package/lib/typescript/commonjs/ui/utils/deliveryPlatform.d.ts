/**
 * Classify the surface a "Sign in with Oxy" request is initiated from, for
 * `AccountDialogController`'s `platform` option (issue #691, Phase 4/5).
 *
 * `@oxy.so/core` deliberately refuses to do this itself — it never touches a
 * platform global — so the consumer that OWNS the environment classifies it and
 * hands the verdict in. The verdict feeds `selectCommonsDelivery`, where it
 * decides one thing only: whether this device may take the `'open-commons'`
 * deep-link route. Getting it wrong in the "mobile" direction is the costly
 * error (a custom-scheme navigation that does not resolve is a dead end with no
 * automatic way back), so every ambiguous signal resolves AWAY from `'mobile'`.
 *
 * No user-agent string is parsed. The two signals used are declarative and
 * standardized:
 *   1. `navigator.userAgentData.mobile` — the User-Agent Client Hints boolean.
 *      Authoritative where implemented (Chromium), in both directions.
 *   2. The PRIMARY pointer (`(pointer: coarse)`) plus a touch digitizer.
 *      A phone/tablet reports a coarse primary pointer; a touchscreen laptop
 *      still reports its mouse as primary, so it is not misclassified.
 */
import type { CommonsDeliveryPlatform } from '@oxy.so/core';
/**
 * Which surface this app is running on, as `selectCommonsDelivery` models it.
 *
 *  - Native (Expo/RN) is always `'mobile'`: it is an Oxy app installed on a
 *    phone/tablet, exactly the case where a verified Commons link can resolve
 *    on this very device.
 *  - A web browser is classified from the signals above.
 *  - Anything else — a browser-like environment with neither signal — is
 *    `'unknown'`, a first-class value that never opts into the deep link.
 */
export declare function resolveDeliveryPlatform(): CommonsDeliveryPlatform;
//# sourceMappingURL=deliveryPlatform.d.ts.map