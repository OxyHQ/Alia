export interface StorageInterface {
    getItem: (key: string) => Promise<string | null>;
    setItem: (key: string, value: string) => Promise<void>;
    removeItem: (key: string) => Promise<void>;
    clear: () => Promise<void>;
}
export interface SessionStorageKeys {
    activeSessionId: string;
    sessionIds: string;
    language: string;
}
/**
 * Create an in-memory storage implementation used as a safe fallback.
 */
export declare const createMemoryStorage: () => StorageInterface;
/**
 * Detect whether the current runtime is React Native.
 */
export declare const isReactNative: () => boolean;
/**
 * Create a platform-appropriate storage implementation.
 * Defaults to in-memory storage when no platform storage is available.
 */
export declare const createPlatformStorage: () => Promise<StorageInterface>;
export declare const STORAGE_KEY_PREFIX = "oxy_session";
/**
 * Produce strongly typed storage key names for the supplied prefix.
 *
 * @param prefix - Storage key prefix
 */
export declare const getStorageKeys: (prefix?: string) => SessionStorageKeys;
//# sourceMappingURL=storageHelpers.d.ts.map