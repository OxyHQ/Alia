import type { AccountStorageUsageResponse, ClientSession } from '@oxy.so/core';
/**
 * Get all active sessions for the current user
 */
export declare const useSessions: (userId?: string, options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<ClientSession[], Error>;
/**
 * Get specific session by ID
 */
export declare const useSession: (sessionId: string | null, options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<ClientSession, Error>;
/**
 * Get device sessions for the current active session
 */
export declare const useDeviceSessions: (options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<import("@oxy.so/core").DeviceLinkedSession[], Error>;
/**
 * Get user devices
 */
export declare const useUserDevices: (options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<import("@oxy.so/core").UserDevice[], Error>;
/**
 * Get security information
 */
export declare const useSecurityInfo: (options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<import("@oxy.so/core").SecurityInfo, Error>;
/**
 * Get account storage usage (server-aggregated usage across assets, mail,
 * recordings, etc.). Wraps `oxyServices.assets.usage()` in a
 * TanStack query so consumers get caching, background refetch, and a
 * consistent `isLoading` / `refetch` surface instead of hand-rolled
 * `useEffect` fetches.
 */
export declare const useAccountStorageUsage: (options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<AccountStorageUsageResponse, Error>;
//# sourceMappingURL=useServicesQueries.d.ts.map