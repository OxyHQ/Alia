/** Public discovery; deliberately outside persisted customer payment queries. */
export declare function usePersonalPlans(): import("@tanstack/react-query").UseQueryResult<{
    schemaVersion: 1;
    state: "unconfigured" | "configured";
    purchase: "unavailable";
    plans: {
        displayName: string;
        kind: "oxy_one";
        audience: "personal";
        benefits: {
            displayName: string;
            benefit: {
                kind: "capability";
                key: string;
                productId: string;
            } | {
                kind: "quota";
                key: string;
                unit: string;
                included: number;
                productId: string;
                combination: "maximum" | "sum" | "exclusive";
            };
        }[];
        offerId: string;
        offerVersion: number;
        price?: {
            currency: string;
            amountMinorUnits: number;
            interval: "month";
            trial: "none";
            taxTreatment: "inclusive";
            merchantTotal: "final";
        } | undefined;
    }[];
}, Error>;
/** Account and session partitioning plus a server-side expected-subject fence. */
export declare function usePersonalPlanSubscriptions(): import("@tanstack/react-query").UseQueryResult<{
    status: "active" | "incomplete" | "canceled" | "incomplete_expired" | "past_due" | "paused" | "trialing" | "unpaid";
    sourceId: string;
    cancelAtPeriodEnd: boolean;
    period: {
        start: string;
        end: string;
    };
    canCancel: boolean;
    offers: {
        displayName: string;
        period: {
            start: string;
            end: string;
        };
        offerId: string;
        offerVersion: number;
        origin: "bundle" | "individual";
        segmentId: string;
        current: boolean;
        products: {
            displayName: string;
            id: string;
        }[];
    }[];
}[], Error>;
//# sourceMappingURL=usePersonalPlans.d.ts.map