import type { OxyServices } from '@oxy.so/core';
export interface UseFileDownloadUrlOptions {
    variant?: string;
    expiresIn?: number;
}
export interface UseFileDownloadUrlResult {
    url: string | null;
    loading: boolean;
    error: Error | null;
}
/**
 * Hook to resolve a file's download URL asynchronously.
 *
 * Uses `getFileDownloadUrlAsync`, which returns a scoped media-token stream URL
 * for private assets. There is no sync CDN fallback — the synchronous
 * `getFileDownloadUrl` is public-CDN-only and 404s for private uploads.
 */
export declare const useFileDownloadUrl: (oxyServices: OxyServices | null | undefined, fileId: string | null | undefined, options?: UseFileDownloadUrlOptions) => UseFileDownloadUrlResult;
//# sourceMappingURL=useFileDownloadUrl.d.ts.map