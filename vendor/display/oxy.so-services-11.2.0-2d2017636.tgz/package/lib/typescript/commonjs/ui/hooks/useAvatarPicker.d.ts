/**
 * Avatar Picker Hook
 *
 * The ONE write path for a user's profile picture. It owns no UI: the whole
 * choose-and-crop experience is a single surface.
 *
 * Flow (typed promise over the shared surface stack — no callback props):
 *   1. `openWithinOrPresent('ChangeAvatar')` opens the source list (device gallery,
 *      camera, existing Oxy files, remove) — MORPHING into the caller's surface
 *      when one is open, else presenting cold. Whichever source the user picks, it
 *      navigates WITHIN to the crop editor — so there is exactly one cropper and
 *      one entry into it.
 *   2. The surface resolves with the cropped JPEG, with `{ removed: true }` when
 *      the user removed their photo, or `undefined` when they cancelled.
 *   3. A crop is uploaded as a NEW file via `oxyServices.assets.upload` and set as
 *      the avatar; a removal clears the avatar field.
 *
 * `expo-image-manipulator` is required for the crop step and `expo-image-picker`
 * for the device/camera sources (both declared as optional peers in the
 * consuming app) — see AvatarCropScreen / ChangeAvatarScreen.
 */
import type { OxyServices } from '@oxy.so/core';
import type { QueryClient } from '@tanstack/react-query';
interface UseAvatarPickerOptions {
    oxyServices: OxyServices;
    currentLanguage: string | null | undefined;
    activeSessionId: string | null;
    queryClient: QueryClient;
}
export declare function useAvatarPicker({ oxyServices, currentLanguage, activeSessionId, queryClient, }: UseAvatarPickerOptions): {
    openAvatarPicker: () => Promise<void>;
};
export {};
//# sourceMappingURL=useAvatarPicker.d.ts.map