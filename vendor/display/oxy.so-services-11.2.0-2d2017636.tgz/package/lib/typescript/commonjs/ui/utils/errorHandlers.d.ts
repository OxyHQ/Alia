import type { ApiError } from '@oxy.so/core';
export interface HandleAuthErrorOptions {
    defaultMessage: string;
    code: string;
    status?: number;
    onError?: (error: ApiError) => void;
    setAuthError?: (message: string) => void;
    logger?: (message: string, error?: unknown) => void;
}
/**
 * Determine whether the error represents an invalid session condition.
 * This centralizes 401 detection across different fetch clients.
 */
export declare const isInvalidSessionError: (error: unknown) => boolean;
/**
 * Determine whether the error represents a timeout or network error.
 * These are expected when the device is offline or has poor connectivity.
 */
export declare const isTimeoutOrNetworkError: (error: unknown) => boolean;
/**
 * Extract a consistent error message from unknown error shapes.
 *
 * @param error - The unknown error payload
 * @param fallbackMessage - Message to return when no concrete message is available
 */
export declare const extractErrorMessage: (error: unknown, fallbackMessage?: string) => string;
/**
 * Centralized error handler for auth-related operations.
 *
 * @param error - Unknown error object
 * @param options - Error handling configuration
 * @returns Resolved error message
 */
export declare const handleAuthError: (error: unknown, { defaultMessage, code, status, onError, setAuthError, logger }: HandleAuthErrorOptions) => string;
//# sourceMappingURL=errorHandlers.d.ts.map