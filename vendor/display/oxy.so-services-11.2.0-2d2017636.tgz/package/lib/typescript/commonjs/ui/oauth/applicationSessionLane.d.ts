import type { OxyServices } from '@oxy.so/core';
export declare function classifyApplicationSessionLane(metadata: unknown): 'device' | 'oauth';
export declare const APPLICATION_CLASSIFICATION_DEADLINE_MS = 5000;
/** The active registry projection is authoritative; names and origins confer no trust. */
export declare function resolveApplicationSessionLane(oxyServices: OxyServices, clientId: string | null | undefined): Promise<'device' | 'oauth'>;
//# sourceMappingURL=applicationSessionLane.d.ts.map