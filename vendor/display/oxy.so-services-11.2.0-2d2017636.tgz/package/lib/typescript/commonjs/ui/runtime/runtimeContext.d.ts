import type { DeviceDirectory } from '@oxy.so/contracts';
import type { DeviceContext } from '@oxy.so/core/session';
import type { User } from '@oxy.so/core';
import type { OxyRuntime } from './createOxyRuntime';
import type { OxyRuntimeStatus } from './types';
export declare const OxyRuntimeHandleProvider: import("react").Provider<OxyRuntime | null>;
export declare class OxyRuntimeMissingError extends Error {
    readonly code = "oxy_runtime_missing";
    constructor();
}
/** The runtime this provider owns. THROWS when no `<OxyProvider>` is mounted. */
export declare function useOxyRuntime(): OxyRuntime;
export interface ActiveAccount {
    /**
     * The human whose authentication backs the session — the audit actor. Equal
     * to {@link ActiveAccount.account} unless a delegated context is active.
     */
    principal: User | null;
    /** The account the session acts AS — what a profile header renders. */
    account: User | null;
    /** The resolved `principal acting as account` pair, when a directory is held. */
    context: DeviceContext | null;
    /** Whether the actor and the subject are different accounts. */
    isDelegated: boolean;
    status: OxyRuntimeStatus;
}
/**
 * Who this app is running as, with the actor and the subject kept apart.
 *
 * Unlike `useOxy()`, this re-renders only when one of those five facts moves —
 * a locale change, a dialog opening or a session-list refresh does not reach it.
 */
export declare function useActiveAccount(): ActiveAccount;
/**
 * The device directory — every principal on this device and the contexts each
 * may act as (ADR 0002).
 *
 * `null` until something calls `runtime.refreshDirectory()`. A client that
 * never asks for one never pays for the round trip.
 */
export declare function useDeviceDirectory(): DeviceDirectory | null;
/** The whole runtime snapshot. Prefer a narrower hook where one exists. */
export declare function useOxySnapshot(): ReturnType<OxyRuntime['getSnapshot']>;
//# sourceMappingURL=runtimeContext.d.ts.map