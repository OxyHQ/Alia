/**
 * Canonical user-cache UPSERT for the Oxy React Query cache.
 *
 * The problem this solves: many places across an app write a user object into
 * the React Query cache and REPLACE the existing entry — profile fetch, feed /
 * post hydration, search, notifications, lists. Each of those sources carries a
 * DIFFERENT (often sparse) slice of the user: a feed author has no viewer
 * `relationship`, a search hit has no `createdAt`, a notification actor has no
 * `_count`. A plain `setQueryData(key, sparseUser)` therefore STRIPS whatever
 * fields the authoritative single-profile fetch had already stored — the
 * "Follows you tag vanishes when the feed loads" / "counts flash to zero" class
 * of bug.
 *
 * The fix (owned here, in the SDK): ONE canonical upsert that MERGES. It writes
 * under BOTH keys the SDK's user hooks read from:
 *   - by-id:       `queryKeys.users.detail(id)`             (read by `useUserById`)
 *   - by-username: `queryKeys.users.byUsername(username, viewerId)` (viewer-scoped;
 *                  read by `useUserByUsername`, carries the viewer `relationship`)
 *
 * Merge semantics (per key):
 *   - No existing entry  -> seed the (normalized) incoming object and mark it
 *     STALE (`updatedAt: 0`) so react-query refetches the full authoritative
 *     profile (viewer-relative `relationship`, counts, `createdAt`, …). Instant
 *     first paint, then the real fetch.
 *   - Existing entry     -> `{ ...existing, ...pickMeaningful(incoming) }`: only
 *     the DEFINED, non-empty fields of `incoming` win; every other field is kept
 *     from `existing`. A sparse source can never NULL-out or STRIP a field the
 *     authoritative fetch set. The entry's freshness is left untouched (never
 *     marked stale — it is already managed).
 *   - Nested objects (`name`, `_count`, `relationship`) merge field-by-field, so
 *     a partial `name`/`_count`/`relationship` never replaces a fuller one.
 *   - `relationship` is written ONLY under the viewer-scoped by-username key —
 *     the viewer-independent by-id key never stores it (prevents one viewer's
 *     follow state from leaking into every other viewer's identity cache).
 *   - Anti-degradation: a good `username` / `name.displayName` / `avatar` is
 *     never overwritten by a degraded/empty one (empty username, the
 *     `'Unknown user'` ghost-author sentinel, `null` avatar).
 *
 * EXPRESSING A DELIBERATE CLEAR ("remove my picture")
 * ---------------------------------------------------
 * The anti-degradation rule above is right for a sparse source and wrong for a
 * user who just emptied the field — and the two are NOT distinguishable from the
 * payload. Measured against oxy-api's canonical serializer (`formatUserResponse`
 * in `packages/api/src/utils/userTransform.ts`, which passes every field through
 * `typeof value === 'string' ? value : undefined`): an account whose avatar,
 * bio and display name were all just CLEARED serializes to
 * `{"id":…,"publicKey":…,"username":…,"name":{},"languages":[]}` — byte-identical
 * to the same account read as a sparse projection. There is no `null` and no
 * `''` on the wire to key on. The information that a field was deliberately
 * emptied exists ONLY at the call site that performed the write.
 *
 * So the caller declares it: `upsertCachedUser(qc, user, viewerId, { cleared:
 * ['avatar'] })`. For a declared field an incoming EMPTY value means the field
 * IS empty and the stale value is dropped; a MEANINGFUL incoming value still
 * wins as usual (so `{ cleared: ['name.displayName'] }` on a personal account,
 * where clearing the explicit name makes the server return the COMPOSED one,
 * keeps the composed name rather than blanking it).
 *
 * A blanket "this source is authoritative, treat every absent field as cleared"
 * flag was considered and rejected: because the two payloads are byte-identical,
 * such a flag is an unverifiable promise about provenance, and the failure mode
 * of getting it wrong is blanking real identity data in every Oxy app. Naming
 * the fields states something the caller actually observed — which fields the
 * user emptied — and bounds the damage to exactly those.
 *
 * It is a cache write only — zero network, one `setQueryData` per key.
 */
import type { UserNameResponse, UserProfileUpdate } from '@oxy.so/contracts';
import type { UpdateAccountInput } from '@oxy.so/core';
import type { QueryClient } from '@tanstack/react-query';
/**
 * A user-shaped object that can be upserted into the cache. Intentionally
 * permissive: it covers the SDK `User` PLUS the looser actor objects embedded on
 * posts / notifications / lists, where `name` may be a plain string and the id
 * may arrive as a raw `_id`. Every field is optional — a sparse feed author is a
 * valid `CacheableUser`. The index signature lets any additional `User` field
 * pass through untouched (so the upsert never has to know the full DTO shape).
 */
export interface CacheableUser {
    id?: string;
    /** Some sources (post/notification actors) carry the id as a raw `_id`. */
    _id?: string;
    username?: string;
    /**
     * Canonical structured name (`UserNameResponse`) OR a plain display string on
     * the looser actor objects. Normalized to the object shape on write.
     */
    name?: string | UserNameResponse;
    /** Avatar file id. `null`/`''` are treated as "no avatar" (never degrade). */
    avatar?: string | null;
    /** Social counts. A partial `_count` never replaces a fuller one. */
    _count?: {
        followers?: number;
        following?: number;
    } | null;
    /**
     * Viewer-relative follow relationship. Present ONLY on an authenticated
     * single-profile fetch; `null`/absent for anon/self/bulk/feed. Never stripped
     * from an existing entry by a source that lacks it.
     */
    relationship?: {
        isFollowing?: boolean;
        followsYou?: boolean;
    } | null;
    [key: string]: unknown;
}
/**
 * The profile fields a user can genuinely EMPTY through a real Oxy write, and
 * for which "empty" is a state every renderer already handles.
 *
 * Deliberately a closed list rather than "any field": a clear DELETES data from
 * the cache, so the blast radius of a mistaken declaration is bounded here
 * instead of resting on each call site. `username` is absent because an account
 * always has one; `_count` and `relationship` are absent because they are
 * server-derived, never user-emptied — and dropping a viewer `relationship` is
 * the exact "Follows you vanishes" bug this module exists to prevent.
 *
 * Each entry is clearable through a shipped write path: `avatar`, `bio`,
 * `description` and `name.displayName` via `UserProfileUpdate` (`''` clears) and
 * `UpdateAccountInput` (`null` clears avatar/bio; `accountCategories: []`
 * clears the ordered category list), and `color` via its nullable field.
 */
export declare const CLEARABLE_USER_FIELDS: readonly ["avatar", "bio", "description", "color", "accountCategories", "name.displayName"];
/** A field nameable in {@link UpsertCachedUserOptions.cleared}. */
export type ClearableUserField = (typeof CLEARABLE_USER_FIELDS)[number];
/**
 * Fields the caller deliberately emptied in a `PUT /users/me` patch. The wire
 * response omits cleared scalars, so the cache needs this list to drop stale
 * values immediately instead of waiting for a refetch that merges the same
 * sparse payload.
 */
export declare function clearedFieldsFromProfileUpdate(updates: UserProfileUpdate): ClearableUserField[];
/**
 * Same contract as {@link clearedFieldsFromProfileUpdate} for managed-account
 * `PATCH /accounts/:id` writes (`null` clears avatar/bio/category).
 */
export declare function clearedFieldsFromAccountUpdate(input: UpdateAccountInput): ClearableUserField[];
/** Options for {@link upsertCachedUser}. */
export interface UpsertCachedUserOptions {
    /**
     * Fields the write that produced this user DELIBERATELY emptied. For each,
     * an incoming empty value stops meaning "this source does not carry it" and
     * starts meaning "it is empty" — so the stale value is dropped rather than
     * preserved. Everything not named here keeps the anti-degradation guard.
     */
    cleared?: readonly ClearableUserField[];
}
/**
 * Merge-upsert a (possibly partial) user into the SDK's user query cache under
 * both the by-id key and, when a username is present, the viewer-scoped
 * by-username key.
 *
 * @param queryClient The app's React Query client.
 * @param user        A `User`-shaped object (may be sparse).
 * @param viewerId    The active viewer id for the by-username key. Defaults to
 *                    the current auth-store user id.
 * @param options     `cleared` names the fields the write deliberately emptied
 *                    — the ONLY way "remove my picture" can propagate, since a
 *                    cleared field and an uncarried one are byte-identical on
 *                    the wire (see the module docs).
 */
export declare function upsertCachedUser(queryClient: QueryClient, user: CacheableUser, viewerId?: string, options?: UpsertCachedUserOptions): void;
/**
 * Batch merge-upsert many users at once (for a feed / list / search response).
 * Resolves the viewer id once and upserts each user cumulatively — a user that
 * appears twice merges both slices into the single cache entry.
 *
 * Takes NO `cleared`, deliberately: a batch is a multi-user projection, so it is
 * exactly the sparse source the anti-degradation guard exists for, and one
 * declaration could not be true of every user in the array anyway.
 */
export declare function upsertCachedUsers(queryClient: QueryClient, users: readonly CacheableUser[] | null | undefined, viewerId?: string): void;
//# sourceMappingURL=userCache.d.ts.map