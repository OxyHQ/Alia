import type React from 'react';
import type { BaseScreenProps } from '../types/navigation';
/** `SignInAuthenticator`: the account's authenticator app and its backup codes. */
declare const SignInAuthenticatorScreen: React.FC<BaseScreenProps>;
export default SignInAuthenticatorScreen;
//# sourceMappingURL=SignInAuthenticatorScreen.d.ts.map