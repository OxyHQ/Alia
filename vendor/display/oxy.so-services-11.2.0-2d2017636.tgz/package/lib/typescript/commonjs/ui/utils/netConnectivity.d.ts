export interface NetInfoLikeState {
    isConnected: boolean | null;
    isInternetReachable?: boolean | null;
}
/**
 * Mirrors Bloom `ConnectionStatusToasts` reachability semantics: a link that
 * reports connected but explicitly unreachable (captive portal, no route) counts
 * as offline.
 */
export declare function isNetConnectivityOnline(state: NetInfoLikeState): boolean;
/**
 * Conservative offline verdict for boot-path probes. Unknown / probing states
 * (`null`, timed-out fetch) resolve to "not offline" so a flaky probe never
 * skips a real sign-in.
 */
export declare function isNetConnectivityExplicitlyOffline(state: NetInfoLikeState | null | undefined): boolean;
//# sourceMappingURL=netConnectivity.d.ts.map