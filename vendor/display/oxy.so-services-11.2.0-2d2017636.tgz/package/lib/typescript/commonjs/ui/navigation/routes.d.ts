import { type ComponentType } from 'react';
import type { BaseScreenProps } from '../types/navigation';
export type RouteName = 'ManageAccount' | 'AccountVerification' | 'PaymentGateway' | 'Profile' | 'LanguageSelector' | 'PrivacySettings' | 'SearchSettings' | 'FileManagement' | 'HelpSupport' | 'LegalDocuments' | 'AppInfo' | 'WelcomeNewUser' | 'UserLinks' | 'HistoryView' | 'EditProfile' | 'EditProfileField' | 'LearnMoreUsernames' | 'TrustCenter' | 'TrustLeaderboard' | 'TrustRewards' | 'TrustRules' | 'AboutTrust' | 'TrustFAQ' | 'FollowersList' | 'FollowingList' | 'CreateAccount' | 'AccountMembers' | 'AccountSettings' | 'ChangeAvatar' | 'AvatarCrop' | 'Notifications' | 'ConnectedApps' | 'Domains' | 'Preferences' | 'DeleteAccount' | 'LinkCommons' | 'SignInPassword' | 'SignInAuthenticator' | 'AccountDialog';
/**
 * Resolve the component for a route.
 *
 * The map is total over {@link RouteName} — the compiler enforces that at its
 * declaration — so this returns `undefined` only for a caller that reached here
 * with an unchecked string; {@link isValidRoute} is how such a caller narrows.
 *
 * The surface host renders the result with {@link BaseScreenProps} merged with
 * the route's own props bag, so that is the type it is handed back as. This one
 * widening is where the gap documented on {@link screenComponents} lives: the map
 * dispatches on a string key, so a screen's extra prop requirements are met at
 * `present(route, props)` call sites, not provable here. No caching is needed —
 * React memoizes each `lazy()` component's module after its first load.
 */
export declare const getScreenComponent: (routeName: RouteName) => ComponentType<BaseScreenProps> | undefined;
export declare const isValidRoute: (routeName: string) => routeName is RouteName;
//# sourceMappingURL=routes.d.ts.map