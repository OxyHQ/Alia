import type { StartNativeOAuthSignInOptions, NativeOAuthSignInResult } from '../oauth/nativeAuthTransport';
import type { ReactNode } from 'react';
import type { LoginSessionResult } from '@oxy.so/contracts';
import type { OxyServices, User, SessionLoginResponse, AccountNode, CreateAccountInput, ClientSession, ApiError } from '@oxy.so/core';
import type { AccountDialogController, AccountDialogView, SessionClient, SessionMode } from '@oxy.so/core/session';
import type { UseFollowHook } from '../hooks/useFollow.types';
import type { useLanguageManagement } from '../hooks/useLanguageManagement';
import type { RouteName } from '../navigation/routes';
import type { StartWebOAuthSignInOptions } from '../oauth/browserAuthTransport';
import type { OAuthConsentResult, RequestOAuthConsentOptions } from '../oauth/explicitOAuthConsent';
import type { WebAuthMode, WebOAuthSignInResult } from '../oauth/types';
import type { StorageInterface } from '../utils/storageHelpers';
import type { AccountQueriesConfig } from '../hooks/accountQueryPersistence';
/**
 * The outcome of `logout()`. It never rejects: a caller reads this instead.
 *
 *  - `signed-out` — the server confirmed the sign-out, or the session was
 *    already invalid and was cleaned up locally. Either way, this device no
 *    longer holds it.
 *  - `failed` — the revocation did not go through (typically no connection).
 *    The session is still installed on this device, and nothing about the
 *    outcome may be presented as revoked. The error is also reported through
 *    the provider's `onError`, as before.
 */
export type LogoutResult = {
    status: 'signed-out';
} | {
    status: 'failed';
    error: unknown;
};
export interface OxyContextState {
    user: User | null;
    sessions: ClientSession[];
    activeSessionId: string | null;
    isAuthenticated: boolean;
    isLoading: boolean;
    isTokenReady: boolean;
    hasAccessToken: boolean;
    canUsePrivateApi: boolean;
    isPrivateApiPending: boolean;
    /**
     * Whether the initial auth determination has concluded.
     *
     * `false` from mount until the FIRST device-first cold boot resolves —
     * during that window `isAuthenticated: false` is UNDETERMINED, not a
     * definitive "logged out". Flips to `true` exactly once the boot concludes
     * (a session was committed OR none exists) and never reverts. Consumers should
     * defer their first auth-dependent fetch until this is `true` so a cold-boot
     * web reload with an existing session does not fetch anonymous data.
     */
    isAuthResolved: boolean;
    isStorageReady: boolean;
    /**
     * Whether the signed-in account's persisted `accountQueries` cache has been
     * restored. Always `true` signed out or when the app declared none.
     * `RequireOxyAuth` waits on it.
     */
    isAccountCacheReady: boolean;
    /**
     * Who owns this provider's session (see `OxyProviderProps.sessionMode`).
     *
     * `'account'` — the device's active account; any app on the device can switch
     * it and this client follows. `'identity'` — the owner of the local primary
     * identity key, permanently: a sibling app's account switch never changes this
     * client's user or bearer, and every account-graph mutation
     * (`switchToAccount` / `switchSession`) rejects with `IdentityBoundSessionError`
     * while `accounts` stays empty and the account dialog never opens.
     */
    sessionMode: SessionMode;
    /** How web third-party sign-in reaches the IdP (see `OxyProviderProps.webAuthMode`). */
    webAuthMode: WebAuthMode;
    error: string | null;
    /** Active UI locale (`language-REGION`): the account's primary locale when signed in, else the guest/device locale. */
    currentLanguage: string;
    /** Ordered account locales (primary first) when signed in, or the single guest override when signed out. */
    currentLanguages: string[];
    currentLanguageMetadata: ReturnType<typeof useLanguageManagement>['metadata'];
    currentLanguageName: string;
    currentNativeLanguageName: string;
    hasIdentity: () => Promise<boolean>;
    getPublicKey: () => Promise<string | null>;
    signIn: (publicKey: string, deviceName?: string) => Promise<User>;
    revokeSuspiciousSignIn: () => Promise<void>;
    /**
     * Commit a session a first-party sign-in minted on THIS origin — an OAuth
     * code exchange, an email code or link, a password, a sign-up — as the
     * active one.
     */
    handleWebSession: (session: SessionLoginResponse | LoginSessionResult) => Promise<void>;
    /**
     * Run a WEB third-party OAuth sign-in (authorization code + PKCE) end to end
     * using this provider's `webAuthMode`, and commit the resulting session.
     *
     * This is the shared operation `OxySignInButton` delegates to; RPs that ship
     * their own button call it directly and never implement popup listeners, a
     * token exchange, or `state` validation themselves. Returns a typed result —
     * closing the popup and running out of time are values, not exceptions.
     *
     * In popup mode the window MUST be opened during the user's click: either
     * call this synchronously from the press handler (it opens one itself), or
     * call `openOAuthPopup()` there and pass the handle as `popup`.
     *
     * No-op outside a browser and in `sessionMode: 'identity'`, both of which
     * resolve to `{ status: 'unsupported' }`.
     */
    /** Native SDK finalizer; call only from an explicit user gesture. */
    startNativeOAuthSignIn: (options: StartNativeOAuthSignInOptions) => Promise<NativeOAuthSignInResult>;
    startWebOAuthSignIn: (options: StartWebOAuthSignInOptions) => Promise<WebOAuthSignInResult>;
    /**
     * Ask the already-authenticated user for explicit OAuth consent to exact
     * application scopes. Must be called from a user gesture. Works on web and
     * native and commits only a callback bound to the same user, state, PKCE pair
     * and byte-exact redirect URI.
     */
    requestOAuthConsent: (options: RequestOAuthConsentOptions) => Promise<OAuthConsentResult>;
    logout: (targetSessionId?: string) => Promise<LogoutResult>;
    logoutAll: () => Promise<void>;
    switchSession: (sessionId: string) => Promise<User>;
    /** The same operation as `logout(sessionId)`, with the same {@link LogoutResult}. */
    removeSession: (sessionId: string) => Promise<LogoutResult>;
    refreshSessions: () => Promise<void>;
    setLanguage: (languageId: string) => Promise<void>;
    getDeviceSessions: () => Promise<Array<{
        sessionId: string;
        deviceId: string;
        deviceName?: string;
        lastActive?: string;
        expiresAt?: string;
    }>>;
    logoutAllDeviceSessions: () => Promise<void>;
    updateDeviceName: (deviceName: string) => Promise<void>;
    clearSessionState: () => Promise<void>;
    clearAllAccountData: () => Promise<void>;
    storageKeyPrefix: string;
    clientId: string | null;
    oxyServices: OxyServices;
    /** Server-authoritative device session client. `null` before an `OxyProvider` is mounted. */
    sessionClient: SessionClient | null;
    useFollow?: UseFollowHook;
    showBottomSheet?: (screenOrConfig: RouteName | {
        screen: RouteName;
        props?: Record<string, unknown>;
    }) => void;
    openAvatarPicker: () => void;
    accountDialogController: AccountDialogController | null;
    isAccountDialogOpen: boolean;
    openAccountDialog: (view?: AccountDialogView) => void;
    closeAccountDialog: () => void;
    accounts: AccountNode[];
    switchToAccount: (accountId: string) => Promise<void>;
    refreshAccounts: () => Promise<void>;
    createAccount: (data: CreateAccountInput) => Promise<AccountNode>;
}
export interface OxyRuntimeProviderProps {
    children: ReactNode;
    oxyServices?: OxyServices;
    baseURL?: string;
    authWebUrl?: string;
    authRedirectUri?: string;
    /**
     * Authorize endpoint override for web "Sign in with Oxy". Defaults to the
     * production Oxy IdP when unset; a local/staging deployment points it at its
     * own IdP so sign-in never reaches production `auth.oxy.so`.
     */
    authorizeBaseUrl?: string;
    storageKeyPrefix?: string;
    clientId?: string;
    /**
     * Who owns this provider's session. See `OxyProviderProps.sessionMode` for the
     * full contract.
     * @default 'account'
     */
    sessionMode?: SessionMode;
    /**
     * Transport for WEB third-party sign-in. See `OxyProviderProps.webAuthMode`.
     * @default 'popup'
     */
    webAuthMode?: WebAuthMode;
    /**
     * Let NATIVE background code (a home-screen widget's WorkManager worker, a sync
     * job) authenticate while the app process is dead and there is no JS runtime.
     *
     * With this on, the SDK provisions a purpose-built background credential
     * whenever the app runs and stores it where `so.oxy.session.OxyBackgroundSession`
     * can read it; Kotlin then exchanges it for a short access token on demand. The
     * app writes no session code — this prop is the whole integration.
     *
     * OFF by default, because a credential that nobody needs is exposure that
     * nobody needs. Turn it on only in an app that actually has background code to
     * authenticate. Android-only today; inert on web and iOS.
     *
     * The credential cannot create a session (only the running app can provision
     * one), cannot rotate or otherwise disturb the app's own device credential, and
     * is re-authorized server-side on every use so it can never outlive a sign-out.
     * It does NOT reduce authority: the token it mints is a full user access token,
     * exactly like the device credential's.
     *
     * @default false
     */
    backgroundSession?: boolean;
    onAuthStateChange?: (user: User | null) => void;
    onError?: (error: ApiError) => void;
    /** Storage instance owned by the public provider; internal composition seam. */
    platformStorage?: StorageInterface | null;
    /** See `OxyProviderProps.accountQueries`. Read once, at mount. */
    accountQueries?: AccountQueriesConfig;
}
/** Internal commit input — session plus zero-cookie device credential. */
export interface CommitInput {
    sessionId: string;
    accessToken?: string;
    deviceId?: string;
    deviceSecret?: string;
    expiresAt?: string;
    userId?: string;
    user?: {
        id: string;
        username?: string;
        avatar?: string;
    };
    /** State returned with a device-token mint, avoiding an immediate REST reread. */
    deviceState?: import('@oxy.so/contracts').DeviceSessionState;
}
//# sourceMappingURL=oxyContextTypes.d.ts.map