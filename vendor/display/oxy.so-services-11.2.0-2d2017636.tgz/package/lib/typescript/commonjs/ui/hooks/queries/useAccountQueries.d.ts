import type { ConnectedApp, User } from '@oxy.so/core';
/**
 * Get user profile by session ID
 */
export declare const useUserProfile: (sessionId: string | null, options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<User, Error>;
/**
 * Get multiple user profiles by session IDs (batch query)
 */
export declare const useUserProfiles: (sessionIds: string[], options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<User | null, Error>[];
/**
 * Get current authenticated user.
 *
 * Hydrates from `GET /users/me` (the bearer identifies the session) rather than
 * `GET /session/user/:activeSessionId`. Post zero-cookie cutover the bearer is
 * the single source of session truth, so keying the CURRENT user off a session
 * id in the URL was a second, independently-updated source that could disagree
 * with the bearer during an account switch — the request fired under the
 * previous account's token against the new account's session id and 404'd. The
 * query KEY stays scoped to the active account so the cache re-scopes (and
 * refetches) on a switch; only the URL stopped carrying a session id.
 *
 * The store-mirror effect must NOT overwrite the in-memory user while a
 * write mutation is in flight — otherwise a stale background refetch
 * landing between optimistic update and server-confirmed update would
 * revert the optimistic value and flicker the UI.
 *
 * We gate the mirror on the mutation-cache state for any mutation that
 * touches `User` shape (profile, avatar, settings, privacy). When any of
 * those is in flight we skip the mirror entirely; the winning onSuccess
 * handler is responsible for writing the final value to the store.
 */
export declare const useCurrentUser: (options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<User, Error>;
/**
 * Get user by ID (identity-by-id).
 *
 * Keyed on the viewer-INDEPENDENT `queryKeys.users.detail(id)`: this hook is
 * the card-identity workhorse (name, avatar, username, verified) and does NOT
 * read the viewer-relative `relationship` field. Keeping the key
 * viewer-independent lets external by-id identity seeders / precache layers
 * (e.g. Mention's card enrichment) that all write `queryKeys.users.detail(id)`
 * share a single cache entry — a viewer-scoped key would dead-end every seed
 * and cause avatar/name flashes plus N+1 fetches.
 *
 * A viewer-scoped, relationship-aware by-id PROFILE fetch is intentionally NOT
 * this hook — it would be a separate future `useUserProfileById` keyed on
 * `queryKeys.users.detailForViewer(id, viewerId)`. No current consumer reads
 * `relationship` from a by-id fetch (only the username path does).
 */
export declare const useUserById: (userId: string | null, options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<User, Error>;
/**
 * Get user profile by username
 */
export declare const useUserByUsername: (username: string | null, options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<User, Error>;
/**
 * Batch get users by session IDs (optimized single API call)
 */
export declare const useUsersBySessions: (sessionIds: string[], options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<{
    sessionId: string;
    user: User | null;
}[], Error>;
/**
 * List the third-party OAuth applications the current user has connected via
 * the consent flow (`GET /auth/grants`). Drives the "Connected apps" management
 * screen.
 */
export declare const useConnectedApps: (options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<ConnectedApp[], Error>;
/**
 * Get privacy settings for a user
 */
export declare const usePrivacySettings: (userId?: string, options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<import("@oxy.so/core").PrivacySettings, Error>;
//# sourceMappingURL=useAccountQueries.d.ts.map