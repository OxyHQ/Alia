/**
 * useMutationStatus
 *
 * Aggregates counts of in-flight, paused (offline), and errored mutations
 * from the TanStack Query mutation cache. Useful for showing a global
 * "Syncing..." indicator in the app shell.
 */
export interface MutationStatus {
    /** Mutations currently running (status === 'pending', not paused). */
    pending: number;
    /** Mutations paused waiting for the network to come back. */
    paused: number;
    /** Mutations that failed and have not been retried. */
    erroring: number;
    /** Total of `pending + paused + erroring`. */
    total: number;
    /** True if any mutation is paused (i.e. waiting for connectivity). */
    isOffline: boolean;
    /** True if any work is in flight or pending sync. */
    isSyncing: boolean;
}
export declare function useMutationStatus(): MutationStatus;
//# sourceMappingURL=useMutationStatus.d.ts.map