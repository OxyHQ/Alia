import type React from 'react';
import { type StyleProp, type ViewStyle } from 'react-native';
interface FAIRWalletIconProps {
    size?: number;
    style?: StyleProp<ViewStyle>;
}
declare const FAIRWalletIcon: React.FC<FAIRWalletIconProps>;
export default FAIRWalletIcon;
//# sourceMappingURL=FAIRWalletIcon.d.ts.map