import type { ClientSession } from '@oxy.so/core';
interface DeviceSession {
    sessionId: string;
    deviceId?: string;
    deviceName?: string;
    expiresAt?: string;
    lastActive?: string;
    user?: {
        id?: string;
        _id?: {
            toString(): string;
        };
    };
    userId?: string;
    isCurrent?: boolean;
}
/**
 * Service type for session helpers.
 * Uses 'unknown' to work around TypeScript mixin composition type inference issues.
 * The OxyServices class has these methods but TypeScript can't see them due to the mixin pattern.
 * Methods are accessed dynamically, so callers must pass a properly typed instance.
 */
type OxyServicesAny = any;
export interface FetchSessionsWithFallbackOptions {
    fallbackDeviceId?: string;
    fallbackUserId?: string;
    logger?: (message: string, error?: unknown) => void;
}
/**
 * Normalize backend session payloads into `ClientSession` objects.
 *
 * @param sessions - Raw session array returned from the API
 * @param fallbackDeviceId - Device identifier to use when missing from payload
 * @param fallbackUserId - User identifier to use when missing from payload
 */
export declare const mapSessionsToClient: (sessions: DeviceSession[], fallbackDeviceId?: string, fallbackUserId?: string) => ClientSession[];
/**
 * Fetch device sessions, falling back to the per-user session endpoint
 * if the device endpoint is unavailable (older API versions or disabled
 * device-grouping feature flag).
 *
 * @param oxyServices - Oxy service instance
 * @param sessionId - Session identifier to fetch
 * @param options - Optional fallback options
 */
export declare const fetchSessionsWithFallback: (oxyServices: OxyServicesAny, sessionId: string, { fallbackDeviceId, fallbackUserId, logger }?: FetchSessionsWithFallbackOptions) => Promise<ClientSession[]>;
export {};
//# sourceMappingURL=sessionHelpers.d.ts.map