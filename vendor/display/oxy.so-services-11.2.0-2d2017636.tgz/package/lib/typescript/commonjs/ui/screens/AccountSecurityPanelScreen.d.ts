/**
 * The frame the account's own security panels render in when presented as a
 * surface (`showBottomSheet('DeleteAccount' | 'LinkCommons' | 'SignInPassword'
 * | 'SignInAuthenticator')`): the panel draws its own large header, so the bar
 * holds only the way back, and the body keeps the dialog's screen gutter.
 */
import type React from 'react';
export declare const AccountSecurityPanelFrame: React.FC<{
    children: React.ReactNode;
}>;
//# sourceMappingURL=AccountSecurityPanelScreen.d.ts.map