/**
 * Subscribe to a named server-pushed Socket.IO event (e.g. `civic:attested`)
 * for the lifetime of the component. Payloads arrive as `unknown` — callers
 * validate shape. Handler identity may change between renders; the latest one
 * is always invoked.
 */
export declare function useOxyEvent(event: string, handler: (payload: unknown) => void): void;
//# sourceMappingURL=useOxyEvent.d.ts.map