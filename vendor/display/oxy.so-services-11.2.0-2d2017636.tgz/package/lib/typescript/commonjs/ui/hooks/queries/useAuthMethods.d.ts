import type { AuthMethodEntry, AuthMethodsResponse, SignInMethods } from '@oxy.so/contracts';
/**
 * The current account's linked authentication methods (`GET /auth/methods`).
 * Backs the security / account surfaces that let a user see their identity key
 * and social logins.
 */
export declare const useAuthMethods: (options?: {
    enabled?: boolean;
}) => {
    /** Every linked auth method. Empty while loading. */
    methods: readonly AuthMethodEntry[];
    /** The account's DID, or `null` while loading. */
    did: string | null;
    data: AuthMethodsResponse;
    error: Error;
    isError: true;
    isPending: false;
    isLoading: false;
    isLoadingError: false;
    isRefetchError: true;
    isSuccess: false;
    isPlaceholderData: false;
    status: "error";
    dataUpdatedAt: number;
    errorUpdatedAt: number;
    failureCount: number;
    failureReason: Error | null;
    errorUpdateCount: number;
    isFetched: boolean;
    isFetchedAfterMount: boolean;
    isFetching: boolean;
    isInitialLoading: boolean;
    isPaused: boolean;
    isRefetching: boolean;
    isStale: boolean;
    isEnabled: boolean;
    refetch: (options?: import("@tanstack/react-query").RefetchOptions) => Promise<import("@tanstack/react-query").QueryObserverResult<AuthMethodsResponse, Error>>;
    fetchStatus: import("@tanstack/react-query").FetchStatus;
} | {
    /** Every linked auth method. Empty while loading. */
    methods: readonly AuthMethodEntry[];
    /** The account's DID, or `null` while loading. */
    did: string | null;
    data: AuthMethodsResponse;
    error: null;
    isError: false;
    isPending: false;
    isLoading: false;
    isLoadingError: false;
    isRefetchError: false;
    isSuccess: true;
    isPlaceholderData: false;
    status: "success";
    dataUpdatedAt: number;
    errorUpdatedAt: number;
    failureCount: number;
    failureReason: Error | null;
    errorUpdateCount: number;
    isFetched: boolean;
    isFetchedAfterMount: boolean;
    isFetching: boolean;
    isInitialLoading: boolean;
    isPaused: boolean;
    isRefetching: boolean;
    isStale: boolean;
    isEnabled: boolean;
    refetch: (options?: import("@tanstack/react-query").RefetchOptions) => Promise<import("@tanstack/react-query").QueryObserverResult<AuthMethodsResponse, Error>>;
    fetchStatus: import("@tanstack/react-query").FetchStatus;
} | {
    /** Every linked auth method. Empty while loading. */
    methods: readonly AuthMethodEntry[];
    /** The account's DID, or `null` while loading. */
    did: string | null;
    data: undefined;
    error: Error;
    isError: true;
    isPending: false;
    isLoading: false;
    isLoadingError: true;
    isRefetchError: false;
    isSuccess: false;
    isPlaceholderData: false;
    status: "error";
    dataUpdatedAt: number;
    errorUpdatedAt: number;
    failureCount: number;
    failureReason: Error | null;
    errorUpdateCount: number;
    isFetched: boolean;
    isFetchedAfterMount: boolean;
    isFetching: boolean;
    isInitialLoading: boolean;
    isPaused: boolean;
    isRefetching: boolean;
    isStale: boolean;
    isEnabled: boolean;
    refetch: (options?: import("@tanstack/react-query").RefetchOptions) => Promise<import("@tanstack/react-query").QueryObserverResult<AuthMethodsResponse, Error>>;
    fetchStatus: import("@tanstack/react-query").FetchStatus;
} | {
    /** Every linked auth method. Empty while loading. */
    methods: readonly AuthMethodEntry[];
    /** The account's DID, or `null` while loading. */
    did: string | null;
    data: undefined;
    error: null;
    isError: false;
    isPending: true;
    isLoading: true;
    isLoadingError: false;
    isRefetchError: false;
    isSuccess: false;
    isPlaceholderData: false;
    status: "pending";
    dataUpdatedAt: number;
    errorUpdatedAt: number;
    failureCount: number;
    failureReason: Error | null;
    errorUpdateCount: number;
    isFetched: boolean;
    isFetchedAfterMount: boolean;
    isFetching: boolean;
    isInitialLoading: boolean;
    isPaused: boolean;
    isRefetching: boolean;
    isStale: boolean;
    isEnabled: boolean;
    refetch: (options?: import("@tanstack/react-query").RefetchOptions) => Promise<import("@tanstack/react-query").QueryObserverResult<AuthMethodsResponse, Error>>;
    fetchStatus: import("@tanstack/react-query").FetchStatus;
} | {
    /** Every linked auth method. Empty while loading. */
    methods: readonly AuthMethodEntry[];
    /** The account's DID, or `null` while loading. */
    did: string | null;
    data: undefined;
    error: null;
    isError: false;
    isPending: true;
    isLoadingError: false;
    isRefetchError: false;
    isSuccess: false;
    isPlaceholderData: false;
    status: "pending";
    dataUpdatedAt: number;
    errorUpdatedAt: number;
    failureCount: number;
    failureReason: Error | null;
    errorUpdateCount: number;
    isFetched: boolean;
    isFetchedAfterMount: boolean;
    isFetching: boolean;
    isLoading: boolean;
    isInitialLoading: boolean;
    isPaused: boolean;
    isRefetching: boolean;
    isStale: boolean;
    isEnabled: boolean;
    refetch: (options?: import("@tanstack/react-query").RefetchOptions) => Promise<import("@tanstack/react-query").QueryObserverResult<AuthMethodsResponse, Error>>;
    fetchStatus: import("@tanstack/react-query").FetchStatus;
} | {
    /** Every linked auth method. Empty while loading. */
    methods: readonly AuthMethodEntry[];
    /** The account's DID, or `null` while loading. */
    did: string | null;
    data: AuthMethodsResponse;
    isError: false;
    error: null;
    isPending: false;
    isLoading: false;
    isLoadingError: false;
    isRefetchError: false;
    isSuccess: true;
    isPlaceholderData: true;
    status: "success";
    dataUpdatedAt: number;
    errorUpdatedAt: number;
    failureCount: number;
    failureReason: Error | null;
    errorUpdateCount: number;
    isFetched: boolean;
    isFetchedAfterMount: boolean;
    isFetching: boolean;
    isInitialLoading: boolean;
    isPaused: boolean;
    isRefetching: boolean;
    isStale: boolean;
    isEnabled: boolean;
    refetch: (options?: import("@tanstack/react-query").RefetchOptions) => Promise<import("@tanstack/react-query").QueryObserverResult<AuthMethodsResponse, Error>>;
    fetchStatus: import("@tanstack/react-query").FetchStatus;
};
/**
 * How the signed-in account signs in (`GET /users/me/sign-in-methods`): whether
 * it has an email, a password, an authenticator app, and how many backup codes
 * are left. Invalidate `queryKeys.signInMethods.all` after changing any of them
 * (the security panels do).
 */
export declare const useSignInMethods: (options?: {
    enabled?: boolean;
}) => import("@tanstack/react-query").UseQueryResult<SignInMethods, Error>;
//# sourceMappingURL=useAuthMethods.d.ts.map