import type React from 'react';
import type { BaseScreenProps } from '../types/navigation';
declare const LearnMoreUsernamesScreen: React.FC<BaseScreenProps>;
export default LearnMoreUsernamesScreen;
//# sourceMappingURL=LearnMoreUsernamesScreen.d.ts.map