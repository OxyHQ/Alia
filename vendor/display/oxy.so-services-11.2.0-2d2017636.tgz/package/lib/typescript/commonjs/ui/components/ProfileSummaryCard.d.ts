import type React from 'react';
/**
 * ProfileSummaryCard — the shared "who am I" summary block rendered at the top
 * of {@link ManageAccountScreen} and {@link EditProfileScreen}.
 *
 * A Bloom filled {@link Card} containing a centered {@link Avatar}, the display
 * name and any number of secondary lines (handle, email, …). When
 * `onAvatarPress` is supplied the avatar becomes a {@link PressableScale} entry
 * point (used to open the avatar picker) and can render an optional camera
 * badge overlay.
 */
export interface ProfileSummaryCardProps {
    /** Primary display name shown under the avatar. */
    displayName: string;
    /** Resolved avatar thumbnail URL (undefined → initials fallback). */
    avatarUri?: string;
    /** Avatar diameter in px. Defaults to 72. */
    avatarSize?: number;
    /**
     * Secondary lines rendered beneath the name (e.g. `@handle`, email).
     * Falsy entries are skipped so callers can pass conditional values inline.
     */
    lines?: Array<string | null | undefined | false>;
    /** When provided, the avatar is pressable (e.g. opens the avatar picker). */
    onAvatarPress?: () => void;
    /** Render the camera badge overlay. Only meaningful with `onAvatarPress`. */
    showCameraBadge?: boolean;
    /** Accessibility label for the pressable avatar. */
    avatarAccessibilityLabel?: string;
}
declare const ProfileSummaryCard: React.FC<ProfileSummaryCardProps>;
export default ProfileSummaryCard;
//# sourceMappingURL=ProfileSummaryCard.d.ts.map