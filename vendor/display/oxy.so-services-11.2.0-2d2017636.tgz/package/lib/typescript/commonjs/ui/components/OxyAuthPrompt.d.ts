import type React from 'react';
import { type StyleProp, type ViewStyle } from 'react-native';
export interface OxyAuthPromptProps {
    /**
     * Short label describing what the user is trying to access. Rendered as
     * the prompt title (e.g. "Notifications", "Privacy"). Keep it to 1-3
     * words; the subtitle expands on the rationale.
     */
    label: string;
    /**
     * Optional longer description. If omitted, a generic
     * `"Sign in to access your {label.toLowerCase()}."` is shown.
     */
    description?: string;
    /**
     * Variant of the embedded `OxySignInButton`. Defaults to `contained` for
     * primary placement; pass `outline` or `default` for secondary contexts.
     */
    signInButtonVariant?: 'default' | 'outline' | 'contained';
    /**
     * Container style override. Use sparingly - the prompt is designed to fit
     * inside a parent screen / sheet body with its own spacing.
     */
    style?: StyleProp<ViewStyle>;
}
/**
 * Inline empty-state shown when an unauthenticated user reaches a surface
 * that requires sign-in (e.g. a settings subscreen, a deep-linked private
 * route, the body of a tab that requires identity).
 *
 * Renders the Oxy logo, a section label, a rationale line, and an embedded
 * `OxySignInButton` that opens the standard sign-in flow (web modal /
 * native bottom sheet, identical to anywhere else `OxySignInButton` is
 * used).
 *
 * Mounts as a regular flex child - it does NOT cover the screen, take over
 * the navigation, or block the back button. For full-screen modal gating
 * use a Bloom Dialog/BottomSheet at the layout level and place this
 * component inside it.
 *
 * When the user is authenticated this component renders `null`. This makes
 * it safe to drop into a screen body without an `isAuthenticated` guard at
 * the call site.
 *
 * @example
 * ```tsx
 * if (!isAuthenticated) {
 *   return (
 *     <ThemedView className="flex-1">
 *       <Header options={{ title: 'Notifications' }} />
 *       <OxyAuthPrompt label="Notifications" />
 *     </ThemedView>
 *   );
 * }
 * ```
 */
export declare const OxyAuthPrompt: React.FC<OxyAuthPromptProps>;
export default OxyAuthPrompt;
//# sourceMappingURL=OxyAuthPrompt.d.ts.map