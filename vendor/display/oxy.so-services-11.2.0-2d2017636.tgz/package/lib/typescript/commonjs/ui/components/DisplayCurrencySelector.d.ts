import React from 'react';
export declare function DisplayCurrencySelector(): React.JSX.Element;
//# sourceMappingURL=DisplayCurrencySelector.d.ts.map