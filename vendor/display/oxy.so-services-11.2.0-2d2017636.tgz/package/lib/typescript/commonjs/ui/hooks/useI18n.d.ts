/**
 * Display copy for SDK surfaces.
 *
 * This is the ONE hook that reads the runtime optionally. The locale is display
 * metadata, not session state — ADR 0004 lists it among the things that come off
 * the central value entirely — and purely presentational surfaces
 * (`OxyConsentScreen`, `OxySignInRequestSurface`) are rendered outside a
 * provider on purpose: `packages/auth`'s production-bundle probe builds the real
 * Vite bundle and renders the surface standalone to prove every element beneath
 * it links. Throwing there would report a linkage failure that is not one.
 *
 * Anything that reads or mutates session state uses `useOxy()`, which throws.
 */
export declare function useI18n(): {
    t: (key: string, vars?: Record<string, string | number>) => string;
    locale: string;
};
//# sourceMappingURL=useI18n.d.ts.map