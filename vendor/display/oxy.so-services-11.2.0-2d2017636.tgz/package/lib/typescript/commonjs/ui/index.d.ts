/**
 * @oxy.so/services/ui — public subpath
 *
 * Tree-shakeable static re-exports of the most common UI surface. Backend
 * environments (SSR) should import `@oxy.so/services/ui/server` instead;
 * client-only callers can use `@oxy.so/services/ui/client` for a slightly
 * narrower bundle.
 *
 * Static `export ... from` only — no runtime `require()`, no platform
 * conditionals. The previous `if (isFrontend) require(...)` pattern was
 * removed because it (a) violated the dual CJS/ESM build rule (ESM bundles
 * cannot contain `require()` per CLAUDE.md) and (b) defeated tree-shaking.
 */
export { default as OxyProvider } from './components/OxyProvider';
export { default as OxySignInButton } from './components/OxySignInButton';
export { default as OxyAuthPrompt } from './components/OxyAuthPrompt';
export type { OxyAuthPromptProps } from './components/OxyAuthPrompt';
export { LogoIcon } from './components/logo/LogoIcon';
export { LogoText } from './components/logo/LogoText';
export { RequireOxyAuth } from './components/RequireOxyAuth';
export type { RequireOxyAuthProps, RequireOxyAuthPrompt } from './components/RequireOxyAuth';
export type { AccountQueriesConfig } from './hooks/accountQueryPersistence';
export { default as FollowButton } from './components/FollowButton';
export { default as PeableButton } from './components/PeableButton';
export type { PeableButtonProps } from './components/PeableButton';
/** @deprecated Use `PeableButton` instead. */
export { default as OxyPayButton } from './components/OxyPayButton';
/** @deprecated Use `PeableButtonProps` instead. */
export type { OxyPayButtonProps } from './components/OxyPayButton';
export { default as ProfileButton } from './components/ProfileButton';
export { useOxy, useOptionalOxy, OxyProviderMissingError } from './context/OxyContext';
export { useAuth } from './hooks/useAuth';
export type { AuthActions, AuthState, SignInOutcome, UseAuthReturn } from './hooks/useAuth';
export { useFollow, useSeedFollowStatuses } from './hooks/useFollow';
export { useStorage } from './hooks/useStorage';
export type { UseStorageOptions, UseStorageResult } from './hooks/useStorage';
export { useAuthStore } from './stores/authStore';
export { handleAuthError, isInvalidSessionError, isTimeoutOrNetworkError, extractErrorMessage, } from './utils/errorHandlers';
export type { HandleAuthErrorOptions } from './utils/errorHandlers';
//# sourceMappingURL=index.d.ts.map