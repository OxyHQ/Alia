/** Local display hint when a session lacks explicit `expiresAt` (7 days). */
export declare const DEFAULT_SESSION_VALIDITY_MS: number;
export declare function getHttpStatus(error: unknown): number | undefined;
export declare function isUnauthorizedStatus(error: unknown): boolean;
//# sourceMappingURL=oxyContextHelpers.d.ts.map