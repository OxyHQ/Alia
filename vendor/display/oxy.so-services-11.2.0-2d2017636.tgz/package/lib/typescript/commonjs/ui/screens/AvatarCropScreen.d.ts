/**
 * AvatarCropScreen
 *
 * Flagship-grade circular crop editor presented after the user picks an image
 * but before the avatar is uploaded. Inspired by iOS Photos, Google Photos and
 * Instagram crop tools.
 *
 * Reached ONLY by navigating within a `ChangeAvatar` surface, so the panel
 * morphs from the source list into the editor. The surface owns the chrome: this
 * screen declares its title and its "Use photo" action through `useSurfaceHeader`
 * and renders no bar of its own — the nav bar's back arrow is Cancel, and it
 * returns to the source list.
 *
 * Architecture:
 *  - A dark crop stage, independent of theme, so photos always read well, inset
 *    inside the surface's own themed panel.
 *  - Circular viewport with white ring and a 3x3 rule-of-thirds grid that
 *    appears during gestures and fades after 800ms.
 *  - Floating zoom chip during pinch.
 *  - Pan + pinch via Gesture Handler, transform driven by Reanimated.
 *  - Reduced-motion aware entrance animation.
 *  - Haptics on milestones via dynamically imported expo-haptics (optional).
 *
 * `expo-image-manipulator` and `expo-haptics` are optional peer dependencies —
 * loaded with `await import(...)`. A missing manipulator surfaces a clear
 * error; missing haptics simply degrades silently.
 */
import type React from 'react';
import type { BaseScreenProps } from '../types/navigation';
/** Final crop result handed back to the caller. */
export interface AvatarCropResult {
    /** File URI to the cropped 512x512 JPEG on disk. */
    uri: string;
    /** Output width (always 512). */
    width: number;
    /** Output height (always 512). */
    height: number;
    /** MIME type (always `image/jpeg`). */
    mime: 'image/jpeg';
}
export interface AvatarCropScreenProps extends BaseScreenProps {
    /** URI of the source image to crop (device / camera sources pass this). */
    imageUri?: string;
    /**
     * ID of an existing Oxy file to crop (the "My Oxy files" source passes this
     * instead of a URL). Its download URL is usually private, so it is resolved
     * HERE — showing this screen's own loading state on the dark canvas — rather
     * than in the source list, which would otherwise linger for the round-trip.
     */
    imageFileId?: string;
    /** Natural width of the source image (optional — measured if absent). */
    sourceWidth?: number;
    /** Natural height of the source image (optional — measured if absent). */
    sourceHeight?: number;
}
declare const AvatarCropScreen: React.FC<AvatarCropScreenProps>;
export default AvatarCropScreen;
//# sourceMappingURL=AvatarCropScreen.d.ts.map