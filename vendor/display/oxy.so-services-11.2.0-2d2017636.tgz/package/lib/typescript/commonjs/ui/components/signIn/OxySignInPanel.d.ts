/**
 * THE Oxy sign-in screen. The account dialog every Oxy app opens and the
 * auth.oxy.so page render this one component; only where it is mounted
 * differs (`host`). Sign-in happens IN it, on every origin: no window opens.
 *
 *   picker        a returning device: "Choose an account", then "Use another account"
 *   identifier    the header, the Commons way in, and "Email or username" with its
 *                 Continue. On the web, from `md`, the screen is Bloom `AuthCard`'s
 *                 split card and the Commons way in is the embedded QR over its
 *                 photo carousel, in the right column (the account dialog grows to
 *                 that card); below `md` it is "Continue with Oxy" at the top. On
 *                 native it is "Continue with Oxy" ("Get Commons" without Commons).
 *   check-email   one email carries a code and a link. The code is typed here: 6
 *                 digits, or — "Does your code have letters?" — the 10-character
 *                 long code an account past its daily guessing ceiling is sent
 *                 (the start response does not say which, by design); meanwhile
 *                 the screen asks whether the link was opened in this browser,
 *                 and signs in when it was.
 *   password      the alternative for an account that has one.
 *   second-factor the authenticator's code, or a backup code, when the account has one.
 *
 * Every answer is the same whether or not the account exists: the email step
 * says "if an account matches".
 */
import type React from 'react';
/** How often the check-email step asks whether the link was opened in this browser. */
export declare const EMAIL_SIGNIN_POLL_MS = 2000;
/** How long after an email "Send a new email" waits. */
export declare const EMAIL_RESEND_COOLDOWN_SECONDS = 30;
export interface OxySignInPanelProps {
    /** This screen signed the origin in. */
    onSignedIn: () => void;
    /** "Don't have an account? Create account". */
    onCreateAccount: () => void;
    /** An email or username to pre-fill, skipping the picker (a re-authentication). */
    loginHint?: string;
    /** The app being continued to, when there is one. */
    appName?: string | null;
    /**
     * `dialog` — inside the account dialog, which the controller closes itself
     * once a request it runs signs in, and where a request shows in place.
     * `page`   — a page of its own (auth.oxy.so): a request opens the dialog to
     * show it, and its completion is reported through `onSignedIn` too.
     */
    host?: 'dialog' | 'page';
}
export declare const OxySignInPanel: React.FC<OxySignInPanelProps>;
//# sourceMappingURL=OxySignInPanel.d.ts.map