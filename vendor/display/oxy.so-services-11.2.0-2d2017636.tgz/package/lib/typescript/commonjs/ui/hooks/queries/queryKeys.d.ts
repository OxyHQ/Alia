/**
 * Centralized query keys for TanStack Query
 *
 * Following best practices:
 * - Use arrays for hierarchical keys
 * - Include all parameters in the key
 * - Use consistent naming conventions
 */
import type { QueryClient } from '@tanstack/react-query';
export declare const queryKeys: {
    readonly accounts: {
        readonly all: readonly ["accounts"];
        readonly lists: () => readonly ["accounts", "list"];
        readonly list: (sessionIds: string[]) => readonly ["accounts", "list", string[]];
        readonly details: () => readonly ["accounts", "detail"];
        readonly detail: (sessionId: string) => readonly ["accounts", "detail", string];
        readonly current: (sessionId?: string | null) => readonly ["accounts", "current", string] | readonly ["accounts", "current"];
        readonly settings: () => readonly ["accounts", "settings"];
    };
    readonly users: {
        readonly all: readonly ["users"];
        readonly lists: () => readonly ["users", "list"];
        readonly list: (userIds: string[]) => readonly ["users", "list", string[]];
        readonly details: () => readonly ["users", "detail"];
        readonly detail: (userId: string) => readonly ["users", "detail", string];
        /** Viewer-scoped single-profile fetch by user id (`relationship` is viewer-relative). */
        readonly detailForViewer: (userId: string, viewerId: string) => readonly ["users", "detail", string, "viewer", string];
        /**
         * Viewer-scoped single-profile fetch by username (`relationship` is
         * viewer-relative). Username is normalized to `trim().toLowerCase()` here
         * so the hook key and any external seeder (e.g. Mention's precache) agree
         * by construction — normalize once, never at call sites.
         */
        readonly byUsername: (username: string, viewerId: string) => readonly ["users", "detail", "username", string, "viewer", string];
        readonly profile: (sessionId: string) => readonly ["users", "detail", string, "profile"];
    };
    readonly sessions: {
        readonly all: readonly ["sessions"];
        readonly lists: () => readonly ["sessions", "list"];
        readonly list: (userId?: string) => readonly ["sessions", "list", string | undefined];
        readonly details: () => readonly ["sessions", "detail"];
        readonly detail: (sessionId: string) => readonly ["sessions", "detail", string];
        readonly active: () => readonly ["sessions", "active"];
        readonly device: (deviceId: string) => readonly ["sessions", "device", string];
    };
    readonly devices: {
        readonly all: readonly ["devices"];
        readonly lists: () => readonly ["devices", "list"];
        readonly list: (accountScope?: string) => readonly ["devices", "list", string | undefined];
        readonly details: () => readonly ["devices", "detail"];
        readonly detail: (deviceId: string) => readonly ["devices", "detail", string];
    };
    readonly privacy: {
        readonly all: readonly ["privacy"];
        readonly settings: (userId?: string) => readonly ["privacy", "settings", string];
        /** The active account's blocked + restricted lists. */
        readonly lists: (userId?: string) => readonly ["privacy", "lists", string];
    };
    readonly security: {
        readonly all: readonly ["security"];
        readonly activity: (limit?: number, offset?: number, eventType?: string) => readonly ["security", "activity", number | undefined, number | undefined, string | undefined];
        readonly recent: (limit: number) => readonly ["security", "recent", number];
        readonly infinite: (limit: number, eventType?: string) => readonly ["security", "infinite", number, string | undefined];
    };
    /** How the signed-in account signs in: email, password, authenticator (`GET /users/me/sign-in-methods`). */
    readonly signInMethods: {
        readonly all: readonly ["signInMethods"];
        readonly current: (userId?: string) => readonly ["signInMethods", string];
    };
    readonly authMethods: {
        readonly all: readonly ["authMethods"];
        readonly list: (userId?: string) => readonly ["authMethods", "list", string];
    };
    readonly storage: {
        readonly all: readonly ["storage"];
        readonly usage: (accountScope?: string) => readonly ["storage", "usage", string | undefined];
    };
    readonly files: {
        readonly all: readonly ["files"];
        readonly list: (ownerId?: string) => readonly ["files", "list", string];
    };
    readonly connectedApps: {
        readonly all: readonly ["connectedApps"];
        readonly list: () => readonly ["connectedApps", "list"];
    };
    readonly follow: {
        readonly all: readonly ["follow"];
        readonly counts: (userId: string) => readonly ["follow", "counts", string];
    };
    readonly reputation: {
        readonly all: readonly ["reputation"];
        readonly balance: (userId?: string) => readonly ["reputation", "balance", string];
        readonly transactions: (userId: string | undefined, limit: number, offset?: number) => readonly ["reputation", "transactions", string, number, number];
        readonly rules: () => readonly ["reputation", "rules"];
        readonly leaderboard: () => readonly ["reputation", "leaderboard"];
    };
    readonly domains: {
        readonly all: readonly ["domains"];
        readonly list: (userId?: string) => readonly ["domains", "list", string];
    };
    readonly payments: {
        readonly all: readonly ["payments"];
        readonly subscription: (userId?: string) => readonly ["payments", "subscription", string];
        readonly history: (userId?: string) => readonly ["payments", "history", string];
        readonly wallet: (userId?: string) => readonly ["payments", "wallet", string];
        readonly walletTransactions: (limit?: number, offset?: number, userId?: string) => readonly ["payments", "wallet", string, "transactions", number | undefined, number | undefined];
    };
};
/**
 * Helper to invalidate all account-related queries
 */
export declare const invalidateAccountQueries: (queryClient: QueryClient) => void;
/**
 * Helper to invalidate all user-related queries
 */
export declare const invalidateUserQueries: (queryClient: QueryClient) => void;
/**
 * Helper to invalidate all session-related queries
 */
export declare const invalidateSessionQueries: (queryClient: QueryClient) => void;
/**
 * Helper to invalidate all device-related queries
 */
export declare const invalidateDeviceQueries: (queryClient: QueryClient) => void;
/**
 * Helper to invalidate all privacy-settings queries
 */
export declare const invalidatePrivacyQueries: (queryClient: QueryClient) => void;
/**
 * Helper to invalidate all security-activity queries
 */
export declare const invalidateSecurityQueries: (queryClient: QueryClient) => void;
/**
 * Helper to invalidate all storage-usage queries
 */
export declare const invalidateStorageQueries: (queryClient: QueryClient) => void;
/**
 * Helper to invalidate the user's linked auth-methods list (call after linking
 * or rotating the identity key).
 */
export declare const invalidateAuthMethodsQueries: (queryClient: QueryClient) => void;
/**
 * Helper to invalidate all payments / wallet / subscription queries
 */
export declare const invalidatePaymentsQueries: (queryClient: QueryClient) => void;
/**
 * Helper to invalidate the user's connected-apps list
 */
export declare const invalidateConnectedAppsQueries: (queryClient: QueryClient) => void;
/**
 * Helper to invalidate the user's file library (all owners). Pass an ownerId via
 * `queryKeys.files.list(ownerId)` for a scoped invalidation instead.
 */
export declare const invalidateFileQueries: (queryClient: QueryClient) => void;
//# sourceMappingURL=queryKeys.d.ts.map