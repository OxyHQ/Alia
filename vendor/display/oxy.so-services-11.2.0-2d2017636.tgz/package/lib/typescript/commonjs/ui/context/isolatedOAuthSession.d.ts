import type { OxyRuntime } from '../runtime';
import type { LogoutResult } from './oxyContextTypes';
interface IsolatedOAuthSession {
    readonly sessionId: string;
    readonly clientId: string;
}
export declare function setIsolatedOAuthSession(runtime: OxyRuntime, session: IsolatedOAuthSession): void;
export declare function hasIsolatedOAuthSession(runtime: OxyRuntime): boolean;
export declare function clearIsolatedOAuthSession(runtime: OxyRuntime): void;
export declare function readIsolatedOAuthSession(runtime: OxyRuntime): IsolatedOAuthSession | null;
/** Exact self-revocation; never a fallback for an unknown device session. */
export declare function logoutIsolatedOAuthSession(input: {
    session: IsolatedOAuthSession;
    targetSessionId?: string;
    revokeSelf: (sessionId: string) => Promise<void>;
    clearSessionState: () => Promise<void>;
}): Promise<LogoutResult>;
export {};
//# sourceMappingURL=isolatedOAuthSession.d.ts.map