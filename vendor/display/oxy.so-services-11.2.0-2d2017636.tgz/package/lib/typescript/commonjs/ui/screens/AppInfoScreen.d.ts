import type React from 'react';
import type { BaseScreenProps } from '../types/navigation';
declare const AppInfoScreen: React.FC<BaseScreenProps>;
export default AppInfoScreen;
//# sourceMappingURL=AppInfoScreen.d.ts.map