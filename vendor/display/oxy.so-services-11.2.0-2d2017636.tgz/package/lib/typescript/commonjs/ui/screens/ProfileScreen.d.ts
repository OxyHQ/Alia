import type React from 'react';
import type { BaseScreenProps } from '../types/navigation';
interface ProfileScreenProps extends BaseScreenProps {
    userId: string;
    username?: string;
}
declare const ProfileScreen: React.FC<ProfileScreenProps>;
export default ProfileScreen;
//# sourceMappingURL=ProfileScreen.d.ts.map