/**
 * Type-safe icon name utilities
 *
 * Provides centralized, typed icon name mappings to eliminate `as any` casts
 * when using dynamic icon names with @expo/vector-icons.
 */
/**
 * Profile field icons (MaterialCommunityIcons)
 */
export declare const PROFILE_FIELD_ICONS: {
    readonly displayName: "account-outline";
    readonly username: "at";
    readonly email: "email-outline";
    readonly bio: "text-box-outline";
    readonly location: "map-marker-outline";
    readonly links: "link-variant";
    readonly website: "web";
    readonly phone: "phone-outline";
    readonly birthday: "cake-variant-outline";
};
export type ProfileFieldIconKey = keyof typeof PROFILE_FIELD_ICONS;
/**
 * Get icon name for a profile field
 */
export declare function getProfileFieldIcon(field: string): string;
/**
 * Settings section icons (MaterialCommunityIcons)
 */
export declare const SETTINGS_ICONS: {
    readonly account: "account-cog-outline";
    readonly privacy: "shield-account-outline";
    readonly security: "lock-outline";
    readonly notifications: "bell-outline";
    readonly language: "translate";
    readonly appearance: "palette-outline";
    readonly storage: "folder-outline";
    readonly help: "help-circle-outline";
    readonly about: "information-outline";
    readonly logout: "logout";
};
export type SettingsIconKey = keyof typeof SETTINGS_ICONS;
/**
 * Get icon name for a settings section
 */
export declare function getSettingsIcon(section: string): string;
/**
 * File type icons (MaterialCommunityIcons)
 */
export declare const FILE_TYPE_ICONS: {
    readonly image: "image-outline";
    readonly video: "video-outline";
    readonly audio: "music-note-outline";
    readonly document: "file-document-outline";
    readonly pdf: "file-pdf-box";
    readonly archive: "folder-zip-outline";
    readonly code: "code-tags";
    readonly spreadsheet: "file-excel-outline";
    readonly presentation: "file-presentation-outline";
    readonly text: "file-document-edit-outline";
    readonly unknown: "file-outline";
};
export type FileTypeIconKey = keyof typeof FILE_TYPE_ICONS;
/**
 * Get icon name for a file type
 */
export declare function getFileTypeIcon(type: string): string;
/**
 * Action icons (Ionicons)
 */
export declare const ACTION_ICONS: {
    readonly close: "close";
    readonly back: "chevron-back";
    readonly forward: "chevron-forward";
    readonly add: "add";
    readonly remove: "remove";
    readonly delete: "trash-outline";
    readonly edit: "pencil-outline";
    readonly save: "checkmark";
    readonly cancel: "close";
    readonly search: "search-outline";
    readonly filter: "filter-outline";
    readonly sort: "swap-vertical-outline";
    readonly refresh: "refresh-outline";
    readonly share: "share-outline";
    readonly copy: "copy-outline";
    readonly download: "download-outline";
    readonly upload: "cloud-upload-outline";
};
export type ActionIconKey = keyof typeof ACTION_ICONS;
/**
 * Get icon name for an action
 */
export declare function getActionIcon(action: string): string;
/**
 * Status icons (Ionicons)
 */
export declare const STATUS_ICONS: {
    readonly success: "checkmark-circle";
    readonly error: "alert-circle";
    readonly warning: "warning";
    readonly info: "information-circle";
    readonly loading: "hourglass-outline";
    readonly pending: "time-outline";
    readonly online: "ellipse";
    readonly offline: "ellipse-outline";
};
export type StatusIconKey = keyof typeof STATUS_ICONS;
/**
 * Get icon name for a status
 */
export declare function getStatusIcon(status: string): string;
//# sourceMappingURL=iconNames.d.ts.map