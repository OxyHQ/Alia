export interface TokenLossRecoveryDeps {
    /** Re-mint once through the installed refresh handler; the token, or null. */
    remint: () => Promise<string | null>;
    /** Whether the durable auth store still holds `deviceId` + `deviceSecret`. */
    hasDeviceCredential: () => Promise<boolean>;
    /**
     * Whether a key-based lane could still re-establish the session without a
     * device secret. Consulted only once the credential is gone.
     */
    hasKeyedRecovery: () => Promise<boolean>;
    /** Whether the UI still shows a signed-in user. */
    isSignedIn: () => boolean;
    /** Whether a bearer is planted right now. */
    hasToken: () => boolean;
    /** Tear down the local session (the provider's `clearSessionState`). */
    signOutLocally: () => Promise<void>;
    /** Timer seam for tests. */
    sleep?: (ms: number) => Promise<void>;
}
export interface TokenLossRecovery {
    /** Start recovering, unless a recovery is already running. */
    start(): void;
    /** Abandon any running recovery (provider unmount). */
    dispose(): void;
    /** Whether a recovery is running. */
    isRecovering(): boolean;
}
/**
 * Delays between re-mint attempts while the device credential is intact. Starts
 * near the post-failure refresh cooldowns and settles at one attempt a minute,
 * which also respects the mint's own 60s rate-limit cooldown.
 */
export declare const TOKEN_RECOVERY_BACKOFF_MS: readonly number[];
/** Attempts through a key-based lane once the device credential is gone. */
export declare const MAX_KEYED_RECOVERY_ATTEMPTS = 3;
export declare function createTokenLossRecovery(deps: TokenLossRecoveryDeps): TokenLossRecovery;
//# sourceMappingURL=tokenLossRecovery.d.ts.map