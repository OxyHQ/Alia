import type React from 'react';
import { type SurfaceControls } from '@oxy.so/bloom/surfaces';
interface DeleteAccountModalProps {
    /** The presenting surface's controls (from `surfaces.present`). */
    surface: SurfaceControls;
    username: string;
    onDelete: (confirmText: string) => Promise<void>;
    t: (key: string, params?: Record<string, string>) => string | undefined;
}
/**
 * Delete-account confirmation — a rich presented surface (NOT a yes/no confirm):
 * the user must retype their username, then the destructive action runs
 * `onDelete`. On success the surface is dismissed with `true` (the presenter
 * then signs out + closes); cancel dismisses with `false`. Presented via
 * {@link presentDeleteAccount}.
 */
declare const DeleteAccountModal: React.FC<DeleteAccountModalProps>;
/** Options accepted by {@link presentDeleteAccount} (everything but `surface`). */
type PresentDeleteAccountOptions = Omit<DeleteAccountModalProps, 'surface'>;
/**
 * Present the delete-account confirmation on the shared surface stack. Resolves
 * `true` once the account is deleted, `false` if cancelled/dismissed.
 */
export declare function presentDeleteAccount(options: PresentDeleteAccountOptions): Promise<boolean>;
export default DeleteAccountModal;
//# sourceMappingURL=DeleteAccountModal.d.ts.map