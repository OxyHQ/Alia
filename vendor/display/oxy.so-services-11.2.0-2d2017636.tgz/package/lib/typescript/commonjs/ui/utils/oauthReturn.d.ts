import type { OxyServices } from '@oxy.so/core';
import type { OAuthSessionCommitInput } from '../oauth/types';
/**
 * When the RP lands with `?code=` after signing in at auth.oxy.so, exchange the
 * code for a device-first session before cold boot runs.
 *
 * This is the REDIRECT transport's return leg. The SDK never starts a full-page
 * authorize navigation on its own any more (#691 phase 7b), but this lane is
 * still load-bearing: a browser-BLOCKED sign-in popup falls back to a full-page
 * redirect (`startWebOAuthSignIn`), and that redirect comes back here.
 *
 * It owns only what is specific to a full-page round trip — reading the code off
 * the URL, recovering the handshake `sessionStorage` carried across the
 * navigation, and cleaning both up afterwards — and delegates state validation,
 * the PKCE exchange, and the session commit to `completeOAuthCode`, the same
 * function the popup transport runs.
 *
 * It is also the SINGLE cleanup path for an OAuth `error` landing on the URL:
 * any `?error=…` (including an `error=login_required` left over from the
 * now-deleted silent restore) is stripped along with `state` /
 * `error_description`, and the stale PKCE handshake is cleared.
 */
export declare function tryCompleteOAuthReturn(opts: {
    oxyServices: OxyServices;
    clientId?: string | null;
    authRedirectUri?: string;
    commitSession: (input: OAuthSessionCommitInput) => Promise<void>;
}): Promise<boolean>;
/**
 * Rewrite the address bar after an authorize round trip, and tell the router.
 *
 * Prefers the page the visit started on (see `persistOAuthReturnPath`) over the
 * bare origin the IdP redirected to, falling back to `fallbackUrl` when nothing
 * was recorded.
 *
 * The `popstate` dispatch is the load-bearing part. `history.replaceState`
 * fires no event, and cold boot runs *inside* the mounted app — by the time
 * this executes, a history-based router (React Router, Vue Router, …) has
 * already read `location` and rendered the route for `/`. Without a
 * notification the address bar would show the restored deep link while the page
 * still displayed the home page. `popstate` is the event the History API
 * defines for exactly this, and it is what those routers subscribe to.
 *
 * Only dispatched when the URL actually changed, so the common no-op case does
 * not push a spurious event at every listener on the page.
 */
export declare function replaceUrlAfterOAuthReturn(fallbackUrl: string): void;
//# sourceMappingURL=oauthReturn.d.ts.map