import type { OxyServices, BulkFollowResult, BulkUnfollowResult } from '@oxy.so/core';
interface FollowState {
    followingUsers: Record<string, boolean>;
    loadingUsers: Record<string, boolean>;
    fetchingUsers: Record<string, boolean>;
    errors: Record<string, string | null>;
    followerCounts: Record<string, number>;
    followingCounts: Record<string, number>;
    loadingCounts: Record<string, boolean>;
    setFollowingStatus: (userId: string, isFollowing: boolean) => void;
    setFollowStatuses: (map: Record<string, boolean>) => void;
    clearFollowError: (userId: string) => void;
    resetFollowState: () => void;
    resolveFollowStatuses: (userIds: string[], oxyServices: OxyServices) => void;
    toggleFollowUser: (userId: string, oxyServices: OxyServices, isCurrentlyFollowing: boolean) => Promise<boolean>;
    followManyUsers: (userIds: string[], oxyServices: OxyServices) => Promise<BulkFollowResult>;
    unfollowManyUsers: (userIds: string[], oxyServices: OxyServices) => Promise<BulkUnfollowResult>;
    setFollowerCount: (userId: string, count: number) => void;
    setFollowingCount: (userId: string, count: number) => void;
    updateCountsFromFollowAction: (targetUserId: string, action: 'follow' | 'unfollow', counts: {
        followers: number;
        following: number;
    }, currentUserId?: string) => void;
    fetchUserCounts: (userId: string, oxyServices: OxyServices) => Promise<void>;
}
/** Clears module-level micro-batch coordination state (test + sign-out hooks). */
export declare const resetFollowBatchState: () => void;
export declare const useFollowStore: import("zustand").UseBoundStore<import("zustand").StoreApi<FollowState>>;
export {};
//# sourceMappingURL=followStore.d.ts.map