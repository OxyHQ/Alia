import type { FileMetadata } from '@oxy.so/core';
/**
 * The variant-aware batch resolver contract (`@oxy.so/core`).
 *
 * `getFileDownloadUrls` takes a per-file `{ fileId, variant }` list and returns
 * a map keyed by `fileId`; ids that are denied or missing are OMITTED (never an
 * empty string), and PRIVATE assets resolve to a working scoped-media-token
 * stream URL. Typed here rather than `Pick<OxyServices, …>` so this file states
 * the exact contract it depends on.
 */
export interface AssetUrlBatchResolver {
    assets: {
        urls(requests: Array<{
            fileId: string;
            variant?: string;
        }>, options?: {
            expiresIn?: number;
            context?: string;
        }): Promise<Record<string, string>>;
    };
}
/** React Query prefix — scoped media URLs must never leak across accounts. */
export declare const ASSET_DOWNLOAD_URLS_QUERY_KEY: "assetDownloadUrls";
/**
 * True when a file is an optimistic placeholder that has not been persisted by
 * the server yet — either its id is still the client-minted `temp-…` id, or it
 * carries the `uploading` flag. Mirrors the `temp-` id guard precedent in
 * `@oxy.so/core`'s `avatarUtils.updateAvatarVisibility`.
 */
export declare function isOptimisticFile(file: Pick<FileMetadata, 'id' | 'metadata'>): boolean;
/**
 * Resolve the image source for a grid tile.
 *
 * - Optimistic entry → its locally-picked preview uri (never an asset URL).
 * - Persisted entry → the private-safe URL from {@link useResolvedFileUrls},
 *   or `undefined` while it is still resolving / was denied (tile shows a
 *   placeholder instead of a guaranteed-404 CDN URL).
 */
export declare function fileThumbSource(file: FileMetadata, resolved: ReadonlyMap<string, string>): string | undefined;
/**
 * Batch-resolve private-safe thumbnail URLs for the given files.
 *
 * Only image/video, non-optimistic files are resolved (documents render an
 * icon, optimistic entries render their local preview). Returns a stable
 * `Map<fileId, url>`; missing entries mean "not resolved yet or access denied".
 */
export declare function useResolvedFileUrls(oxyServices: AssetUrlBatchResolver, files: FileMetadata[], 
/** Active viewer account id — media tokens are minted per user; must be in the query key. */
viewerId?: string | null): ReadonlyMap<string, string>;
//# sourceMappingURL=useResolvedFileUrls.d.ts.map