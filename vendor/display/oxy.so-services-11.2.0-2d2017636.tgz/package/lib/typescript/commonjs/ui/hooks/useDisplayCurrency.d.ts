import { type UserPreferences } from '@oxy.so/core';
export type DisplayCurrency = NonNullable<UserPreferences['displayCurrency']>;
export declare const DISPLAY_CURRENCIES: readonly DisplayCurrency[];
/** Account-scoped server preference. A late save can never replace another account. */
export declare function useDisplayCurrency(): {
    currency: DisplayCurrency;
    selectCurrency: (next: DisplayCurrency) => void;
    isSaving: boolean;
    error: Error | null;
};
//# sourceMappingURL=useDisplayCurrency.d.ts.map