import type React from 'react';
import type { BaseScreenProps } from '../types/navigation';
/**
 * EditProfileScreen — the profile-editing HUB.
 *
 * Lists every editable profile field as its own row; each row deep-links into
 * {@link EditProfileFieldScreen} with the matching `fieldType`. The avatar row
 * reuses the exact same `openAvatarPicker` entry point that
 * {@link ManageAccountScreen} uses. This is the single entry into per-field
 * editing — reached from ManageAccount's "Edit profile" row.
 */
declare const EditProfileScreen: React.FC<BaseScreenProps>;
export default EditProfileScreen;
//# sourceMappingURL=EditProfileScreen.d.ts.map