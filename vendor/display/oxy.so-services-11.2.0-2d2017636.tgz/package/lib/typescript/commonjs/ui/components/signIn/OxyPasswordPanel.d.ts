/**
 * Setting or changing the account's password, from its settings. A password
 * is optional: the account signs in with a code by email without one. The
 * change is confirmed with the current password (when there is one) or a code
 * sent to the account's email, plus the authenticator's code when it has one.
 */
import type React from 'react';
export interface OxyPasswordPanelProps {
    /** The password is saved. */
    onDone?: () => void;
    /** "Cancel". */
    onCancel?: () => void;
}
export declare const OxyPasswordPanel: React.FC<OxyPasswordPanelProps>;
//# sourceMappingURL=OxyPasswordPanel.d.ts.map