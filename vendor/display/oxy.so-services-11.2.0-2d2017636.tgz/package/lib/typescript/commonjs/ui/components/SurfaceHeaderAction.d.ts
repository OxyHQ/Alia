import type React from 'react';
export interface SurfaceHeaderActionProps {
    /** Button label (e.g. a translated "Save"). */
    label: string;
    onPress: () => void;
    /** Show a spinner instead of the label (also disables the button). */
    loading?: boolean;
    disabled?: boolean;
}
/** Header actions share Bloom's sizing, surface, disabled and loading behavior. */
export declare const SurfaceHeaderAction: React.FC<SurfaceHeaderActionProps>;
//# sourceMappingURL=SurfaceHeaderAction.d.ts.map