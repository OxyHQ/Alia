import type React from 'react';
export interface FileLibraryErrorProps {
    title: string;
    description: string;
    retryLabel: string;
    onRetry: () => void;
    /** Failure icon tint. */
    iconColor: string;
    titleColor: string;
    descriptionColor: string;
}
/**
 * Terminal load-failure surface for the file library — rendered (INSTEAD of the
 * "no files yet" empty state) when the list query errors with nothing cached, so
 * a failed load never masquerades as an empty library. Pure presentational; the
 * Retry action is wired to the query's `refetch()` by the caller. Themed via
 * color props so it fits both the browse chrome and the dark picker backdrop.
 */
declare const FileLibraryError: React.FC<FileLibraryErrorProps>;
export default FileLibraryError;
//# sourceMappingURL=FileLibraryError.d.ts.map