import { type SharedDeviceCredentialStore } from '@oxy.so/core/session';
/**
 * The iOS Keychain Access Group every official Oxy app declares in its
 * entitlements. Shared with the identity slots — the group is the app-group
 * boundary, not the secret's identity.
 */
export declare const IOS_KEYCHAIN_ACCESS_GROUP = "group.so.oxy.shared";
/**
 * The iOS `keychainService` for the DEVICE SESSION credential. Deliberately
 * distinct from every identity and recovery service; do not reuse one of those
 * here, and do not drop it (an item written with no service shares the legacy
 * identity slot's namespace inside the group).
 */
export declare const IOS_DEVICE_SESSION_KEYCHAIN_SERVICE = "oxy_device_session";
/** The single key holding the JSON-encoded `{deviceId, deviceSecret}` pair. */
export declare const SHARED_DEVICE_SESSION_STORAGE_KEY = "oxy_shared_device_session_v1";
/**
 * The shared DeviceSession credential slot for this runtime, or `null` when
 * there is none.
 *
 * The branch is on the PLATFORM, not on which module happens to load, because
 * `expo-secure-store` loads perfectly well on Android — it would just quietly
 * ignore `keychainAccessGroup` and read a package-private item, which looks
 * exactly like an empty shared slot. This is the same iOS-vs-Android split
 * `KeyManager` makes for the shared identity, for the same reason.
 *
 * Any other native platform gets the broker, which answers `unsupported` when
 * the module is not linked — so the lane is simply off, which is the safe
 * direction.
 */
export declare function createPlatformSharedDeviceCredentialStore(): SharedDeviceCredentialStore | null;
//# sourceMappingURL=sharedDeviceCredentialStore.d.ts.map