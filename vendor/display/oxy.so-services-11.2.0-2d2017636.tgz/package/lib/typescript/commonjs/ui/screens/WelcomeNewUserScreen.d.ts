import type React from 'react';
import type { BaseScreenProps } from '../types/navigation';
import { type User } from '@oxy.so/core';
/**
 * Post-signup welcome & onboarding screen.
 * - Greets the newly registered user
 * - Lets them immediately set / change their avatar using existing FileManagement picker
 * - Only when the user presses "Continue" do we invoke onAuthenticated to finish flow & close sheet
 */
declare const WelcomeNewUserScreen: React.FC<BaseScreenProps & {
    newUser?: User;
}>;
export default WelcomeNewUserScreen;
//# sourceMappingURL=WelcomeNewUserScreen.d.ts.map