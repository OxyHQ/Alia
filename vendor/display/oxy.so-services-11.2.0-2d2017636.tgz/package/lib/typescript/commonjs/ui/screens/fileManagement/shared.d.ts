import type { RNFileDescriptor } from '@oxy.so/core';
export declare const loadDocumentPicker: () => Promise<typeof import("expo-document-picker")>;
/**
 * Extract error message from unknown error type.
 * Delegates to the canonical `getErrorMessage` in `@oxy.so/core` and returns
 * `undefined` for empty results (so callers can fall back to a translated
 * message via `||`).
 */
export declare const getErrorMessage: (error: unknown) => string | undefined;
/**
 * A picker-produced file ready to upload. On web this is a real `File`
 * (carrying an optional `uri` for preview). On native, it's an
 * {@link RNFileDescriptor} — passed straight to FormData by `assetUpload`.
 */
export type UploadCandidate = (File & {
    uri?: string;
}) | RNFileDescriptor;
/** Returns the display name for either a web File or an RN descriptor. */
export declare const candidateName: (candidate: UploadCandidate, fallback: string) => string;
/** Returns the byte size for either a web File or an RN descriptor (0 if unknown). */
export declare const candidateSize: (candidate: UploadCandidate) => number;
/** Returns the mime type for either a web File or an RN descriptor. */
export declare const candidateType: (candidate: UploadCandidate) => string;
/** Returns the preview URI for an upload candidate, if available. */
export declare const candidateUri: (candidate: UploadCandidate) => string | undefined;
/** A processed file ready for review in the upload preview modal. */
export interface PendingUploadFile {
    /** Stable row identity for React keys and removal — survives reorder/filter. */
    id: string;
    file: UploadCandidate;
    preview?: string;
    size: number;
    name: string;
    type: string;
}
/** Mint a {@link PendingUploadFile} row from a validated upload candidate. */
export declare const createPendingUploadFile: (file: UploadCandidate, preview: string | undefined, size: number, name: string, type: string) => PendingUploadFile;
//# sourceMappingURL=shared.d.ts.map