import type { Asset, AssetUploadProgress, AssetLink } from '@oxy.so/core';
interface AssetState {
    assets: Record<string, Asset>;
    uploadProgress: Record<string, AssetUploadProgress>;
    loading: {
        uploading: boolean;
        linking: boolean;
        deleting: boolean;
    };
    errors: {
        upload?: string;
        link?: string;
        delete?: string;
    };
    setAsset: (asset: Asset) => void;
    /**
     * Merge what an API call returned about an asset (an upload, a link change,
     * a restore — each returns only part of the record) into what is known.
     */
    mergeAsset: (patch: Partial<Asset> & {
        id: string;
    }) => void;
    setAssets: (assets: Asset[]) => void;
    removeAsset: (assetId: string) => void;
    setUploadProgress: (fileId: string, progress: AssetUploadProgress) => void;
    removeUploadProgress: (fileId: string) => void;
    addLink: (assetId: string, link: AssetLink) => void;
    removeLink: (assetId: string, app: string, entityType: string, entityId: string) => void;
    setUploading: (uploading: boolean) => void;
    setLinking: (linking: boolean) => void;
    setDeleting: (deleting: boolean) => void;
    setUploadError: (error?: string) => void;
    setLinkError: (error?: string) => void;
    setDeleteError: (error?: string) => void;
    clearErrors: () => void;
    getAssetsByApp: (app: string) => Asset[];
    getAssetsByEntity: (app: string, entityType: string, entityId: string) => Asset[];
    getAssetUsageCount: (assetId: string) => number;
    isAssetLinked: (assetId: string, app: string, entityType: string, entityId: string) => boolean;
    reset: () => void;
}
export declare const useAssetStore: import("zustand").UseBoundStore<import("zustand").StoreApi<AssetState>>;
export declare const useAssets: () => Asset[];
export declare const useAsset: (assetId: string) => Asset;
export declare const useUploadProgress: () => Record<string, AssetUploadProgress>;
export declare const useAssetLoading: () => {
    uploading: boolean;
    linking: boolean;
    deleting: boolean;
};
export declare const useAssetErrors: () => {
    upload?: string;
    link?: string;
    delete?: string;
};
export declare const useAssetsByApp: (app: string) => Asset[];
export declare const useAssetsByEntity: (app: string, entityType: string, entityId: string) => Asset[];
export declare const useAssetUsageCount: (assetId: string) => number;
export declare const useIsAssetLinked: (assetId: string, app: string, entityType: string, entityId: string) => boolean;
export {};
//# sourceMappingURL=assetStore.d.ts.map