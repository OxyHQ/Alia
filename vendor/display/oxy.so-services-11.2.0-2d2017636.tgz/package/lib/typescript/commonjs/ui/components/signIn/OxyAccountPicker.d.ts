/**
 * "Choose an account" — every `principal acting as account` pair on this
 * device, then "Use another account".
 *
 * The front screen of sign-in on a returning device, in the account dialog and
 * on every auth.oxy.so page that asks WHO (sign-in, OAuth authorize, device
 * approval, MCP linking). Presentational: the host decides what choosing a row
 * means — a switch, a "Continue as" sign-in, or activating the pair before an
 * OAuth consent — and passes the pair back, never an account id, which cannot
 * say whose route was chosen.
 *
 * One rounded list: each row is the account's name and `@handle` on the left,
 * its avatar and a chevron on the right, with a hairline between rows that
 * steps aside for a hovered row. Layout is NativeWind; hover is driven by
 * `onHoverIn`/`onHoverOut` (web only), because this pipeline does not emit
 * `hover:` variants — the same pattern as the account menu.
 */
import type React from 'react';
import { type SwitcherContextRow, type SwitcherPrincipalRow } from '@oxy.so/core/session';
export interface OxyAccountPickerProps {
    /** The device's people, each with the accounts they may act as (`useDeviceSwitcher`). */
    principals: SwitcherPrincipalRow[];
    /** The app being continued to, when there is one. */
    appName?: string | null;
    onSelectContext: (context: SwitcherContextRow) => void;
    /** "Use another account" — the host reveals its sign-in. */
    onUseAnother: () => void;
    /** The pair being activated, whose row shows it is busy. */
    pendingContextId?: string | null;
    /** Disables every row while a choice is in flight. */
    isLoading?: boolean;
    /**
     * This origin holds no session. A row is then announced as "Continue as
     * @handle" and never marked as the current account: the device can list an
     * identity as active while nobody is signed in HERE.
     */
    signedOut?: boolean;
}
export declare const OxyAccountPicker: React.FC<OxyAccountPickerProps>;
//# sourceMappingURL=OxyAccountPicker.d.ts.map