interface ProfileLocation {
    id: string;
    name: string;
    label?: string;
    coordinates?: {
        lat: number;
        lon: number;
    };
}
interface ProfileLinkMetadata {
    url: string;
    title?: string;
    description?: string;
    image?: string;
    id: string;
}
export interface ProfileUpdateData {
    firstName?: string;
    lastName?: string;
    username?: string;
    email?: string;
    bio?: string;
    locations?: ProfileLocation[];
    links?: string[];
    linksMetadata?: ProfileLinkMetadata[];
    avatar?: string;
    phone?: string;
    address?: string;
    birthday?: string;
    dateOfBirth?: string;
}
type ProfileFieldValue = string | ProfileLocation[] | ProfileLinkMetadata[];
/**
 * Hook for managing profile editing operations
 * Provides functions to update profile fields and handle saving
 */
export declare const useProfileEditing: () => {
    saveProfile: (updates: ProfileUpdateData) => Promise<boolean>;
    updateField: (field: string, value: ProfileFieldValue) => Promise<boolean>;
    isSaving: boolean;
};
export {};
//# sourceMappingURL=useProfileEditing.d.ts.map