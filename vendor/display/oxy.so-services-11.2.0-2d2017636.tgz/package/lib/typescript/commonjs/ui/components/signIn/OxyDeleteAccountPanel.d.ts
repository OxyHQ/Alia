/**
 * Deleting an account that has no key of its own, from the account's settings
 * (the account dialog's "Manage your account", or the Accounts app):
 *
 *   type the username → a code sent to the account's email (+ the
 *   authenticator's code when it has one) → deleted, and signed out
 *
 * An account with a Commons key is deleted with that key — in Commons, or in
 * an app that holds it (`ManageAccountScreen`); this panel says so instead.
 * It must be rendered signed in as the account.
 */
import type React from 'react';
export interface OxyDeleteAccountPanelProps {
    /** The account is gone and this origin signed out of it. */
    onDeleted?: () => void;
    /** "Cancel". */
    onCancel?: () => void;
}
export declare const OxyDeleteAccountPanel: React.FC<OxyDeleteAccountPanelProps>;
//# sourceMappingURL=OxyDeleteAccountPanel.d.ts.map