declare const isFrontend: boolean;
export default isFrontend;
//# sourceMappingURL=isFrontend.d.ts.map