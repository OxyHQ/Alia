import type React from 'react';
import type { CardDetails, PaymentColors, PaymentStepAnimations } from './types';
interface PaymentReviewStepProps {
    amount: string | number;
    currency: string;
    paymentMethod: string;
    cardDetails: CardDetails;
    colors: PaymentColors;
    animations: PaymentStepAnimations;
    isPaying: boolean;
    onBack: () => void;
    onPay: () => void;
}
declare const PaymentReviewStep: React.FC<PaymentReviewStepProps>;
export default PaymentReviewStep;
//# sourceMappingURL=PaymentReviewStep.d.ts.map