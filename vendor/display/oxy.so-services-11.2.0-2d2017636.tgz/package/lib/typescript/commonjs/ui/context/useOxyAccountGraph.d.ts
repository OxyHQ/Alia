import { type RefObject } from 'react';
import type { OxyServices, AccountNode, CreateAccountInput } from '@oxy.so/core';
import type { AccountDialogController, SessionClient } from '@oxy.so/core/session';
import type { CommitInput } from './oxyContextTypes';
interface UseOxyAccountGraphParams {
    isAuthenticated: boolean;
    tokenReady: boolean;
    initialized: boolean;
    /**
     * `sessionMode: 'identity'`. The account graph is a switcher surface, and an
     * identity-bound client authenticates as the owner of the local identity key —
     * permanently. The graph is therefore never fetched and every switch rejects.
     */
    identityBound: boolean;
    isolatedOAuth: boolean;
    oxyServices: OxyServices;
    sessionClient: SessionClient;
    syncFromClient: () => Promise<void>;
    commitSession: (input: CommitInput, options: {
        activate: boolean;
    }) => Promise<void>;
    accountDialogControllerRef: RefObject<AccountDialogController | null>;
    clearSessionStateRef: RefObject<() => Promise<void>>;
}
export declare function useOxyAccountGraph({ isAuthenticated, tokenReady, initialized, identityBound, isolatedOAuth, oxyServices, sessionClient, syncFromClient, commitSession, accountDialogControllerRef, clearSessionStateRef, }: UseOxyAccountGraphParams): {
    accounts: AccountNode[];
    refreshAccounts: () => Promise<void>;
    switchToAccount: (accountId: string) => Promise<void>;
    createAccount: (data: CreateAccountInput) => Promise<AccountNode>;
};
export {};
//# sourceMappingURL=useOxyAccountGraph.d.ts.map