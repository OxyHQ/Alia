import type React from 'react';
import type { PaymentColors, PaymentStepAnimations } from './types.js';
interface PaymentSuccessStepProps {
    colors: PaymentColors;
    animations: PaymentStepAnimations;
    onDone: () => void;
}
declare const PaymentSuccessStep: React.FC<PaymentSuccessStepProps>;
export default PaymentSuccessStep;
//# sourceMappingURL=PaymentSuccessStep.d.ts.map