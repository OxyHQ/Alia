import { type OxyServices } from '@oxy.so/core';
import { type AuthStateStore, type IdentityBinding, type SessionMode } from '@oxy.so/core/session';
import type { SessionClient } from '@oxy.so/core/session';
import type { CommitInput } from '../context/oxyContextTypes.js';
/** How long the cold boot waits for the post-boot SessionClient handoff (ms). */
export declare const SESSION_HANDOFF_DEADLINE_MS = 6000;
/**
 * HARD overall deadline (ms) for the whole `runSessionColdBoot` step chain.
 *
 * Bounds time-to-route: routing gates on `isAuthResolved`, which resolves when
 * the cold boot finishes, so a network step that never settles (a black-hole
 * network that neither connects nor rejects) would otherwise hang routing
 * indefinitely. 12s comfortably exceeds the healthy worst case of the
 * sequential, single-attempt (`retry:false`), 5s-capped network steps, so it is
 * INERT on healthy loads and only trips on a pathological network. Offline
 * devices short-circuit far sooner via the connectivity hint below.
 */
export declare const COLD_BOOT_OVERALL_DEADLINE_MS = 12000;
export interface RunProviderColdBootOptions {
    oxyServices: OxyServices;
    authStore: AuthStateStore;
    clientId?: string;
    authRedirectUri?: string;
    /**
     * Who owns the session this boot resolves. `'account'` (the default) is the
     * device's active account — every ordinary Oxy app. `'identity'` binds the
     * boot to the owner of this device's PRIMARY identity key and REQUIRES
     * {@link identity}; it also disables the web OAuth return leg below, which
     * commits whatever account the IdP hands back.
     */
    sessionMode?: SessionMode;
    /** The identity binding required by `sessionMode: 'identity'`. */
    identity?: IdentityBinding;
    sessionClient: SessionClient;
    /** Provider-owned fresh classifier, also used by explicit action recovery. */
    resolveSessionLane?: () => Promise<'device' | 'oauth'>;
    /** Identity pin work may run only after a fresh device classification. */
    onClassified?: (lane: 'device' | 'oauth') => void | Promise<void>;
    beforeDeviceBoot?: () => Promise<void>;
    afterDeviceBoot?: () => Promise<void>;
    syncDeviceCredentialToHost: () => Promise<void>;
    commitSession: (input: CommitInput, options: {
        activate: boolean;
        oauth?: boolean;
    }) => Promise<void>;
    markAuthResolved: () => void;
    setTokenReady: (ready: boolean) => void;
}
/**
 * Device-first cold boot for `@oxy.so/services` providers.
 *
 * Ordered pipeline:
 * 1. Complete an OAuth authorization-code return already on the URL (web)
 * 2. `runSessionColdBoot` — device-secret mint (+ the native Commons-proof lane,
 *    or the primary-identity-key lane in `sessionMode: 'identity'`)
 *
 * Step 1 is ACCOUNT-MODE ONLY: it commits whichever account the IdP resolves,
 * which for an identity-bound client is somebody else's account by construction.
 * In `'identity'` mode the boot is exactly step 2.
 *
 * The boot NEVER navigates the top-level window. There is no automatic
 * `prompt=none` bounce to the IdP: a web origin with no local device credential
 * resolves SIGNED OUT and waits for the user's next explicit "Continue with
 * Oxy", which opens a popup from a real gesture (#691 phase 7b). Step 1 is not a
 * navigation — it only consumes a code that is already in the address bar.
 */
export declare function runProviderColdBoot(opts: RunProviderColdBootOptions): Promise<void>;
//# sourceMappingURL=runProviderColdBoot.d.ts.map