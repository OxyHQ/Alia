import type React from 'react';
import type { BaseScreenProps } from '../types/navigation.js';
import type { FollowGraphSort } from '@oxy.so/core';
type ListMode = 'followers' | 'following';
interface UserListScreenProps extends BaseScreenProps {
    userId: string;
    mode: ListMode;
    initialCount?: number;
    /**
     * Ordering of the list — `recent` (newest follow first) or `oldest`.
     * Omitted ⇒ the server default (`recent`). Changing it re-fetches from
     * offset 0, since a page boundary is meaningless across two orderings.
     */
    sort?: FollowGraphSort;
}
declare const UserListScreen: React.FC<UserListScreenProps>;
export default UserListScreen;
//# sourceMappingURL=UserListScreen.d.ts.map