import type { OxyRuntime } from './createOxyRuntime.js';
import type { OxyRuntimeSnapshot } from './types.js';
/**
 * Subscribe to the whole runtime snapshot.
 *
 * The runtime publishes a frozen object only when a fact actually changed, so
 * identity comparison is exact: a locale change, a dialog opening or an
 * unrelated query settling does not wake anything subscribed here.
 */
export declare function useRuntimeSnapshot(runtime: OxyRuntime): OxyRuntimeSnapshot;
/**
 * Subscribe to one derived value of the runtime snapshot.
 *
 * The selection is cached against the snapshot it was computed from, which is
 * what makes a selector returning a fresh object (`{user, isAuthenticated}`)
 * safe here: `useSyncExternalStore` calls `getSnapshot` several times per
 * commit and would otherwise see a new object every call and loop.
 *
 * `selector` must be stable — hoist it to module scope or wrap it in
 * `useCallback`. An inline arrow re-subscribes on every render.
 */
export declare function useRuntimeSelector<T>(runtime: OxyRuntime, selector: (snapshot: OxyRuntimeSnapshot) => T, isEqual?: (a: T, b: T) => boolean): T;
//# sourceMappingURL=useRuntimeSnapshot.d.ts.map