/**
 * The pieces every Oxy sign-in and account screen shares: the error vocabulary,
 * one labelled field, one one-time-code field, the one primary action, a note,
 * a notice, and the email-code step.
 * Each screen is built from the same shell as `OxySignInPanel`
 * (`OxyAuthScreen`), so they read as one product in the account dialog, in an
 * app's settings and on auth.oxy.so.
 */
import type React from 'react';
import { type EmailVerificationConfirmResponse } from '@oxy.so/contracts';
import type { Translate } from '../authChooser/types.js';
/** How long a screen waits after a 429 that names no wait of its own. */
export declare const RATE_LIMIT_SECONDS = 60;
/** The API error code a thrown SDK error carries (`error.code`), if any. */
export declare function errorCode(error: unknown): string | undefined;
/** A 429: too many attempts or emails. */
export declare function isRateLimited(error: unknown): boolean;
/** How long to wait after a 429, from the API's `retryAfterSeconds` when it sent one. */
export declare function retryAfterSeconds(error: unknown): number;
/**
 * A failure of a sign-in or account screen, in the person's language. Never
 * says whether an account exists: every "no" is the same sentence.
 */
export declare function describeSignInError(error: unknown, t: Translate): string;
/** Whether the confirmation this flow holds is gone and it must start again. */
export declare function isTicketExpired(error: unknown): boolean;
/**
 * Whether a typed sign-in code is complete: 6 digits, or the 10-character long
 * code (`XXXXX-XXXXX`, any case, with or without its dash) in its own alphabet.
 */
export declare function isCompleteSignInCode(typed: string): boolean;
/** Characters in a backup code (`xxxxx-xxxxx`, its dash not counted). */
export declare const BACKUP_CODE_LENGTH = 10;
/**
 * One labelled input, the way the sign-in screen draws its fields. A
 * `secureTextEntry` field is always revealable: Bloom's eye button shows and
 * hides the password, named in the locale Bloom speaks (`OxyProvider` sets it).
 */
export declare const AccountFlowField: React.FC<{
    label: string;
    value: string;
    onChange: (value: string) => void;
    onSubmit: () => void;
    error: string | null;
    disabled?: boolean;
    placeholder?: string;
    autoComplete?: 'username' | 'email' | 'off' | 'current-password' | 'new-password';
    keyboardType?: 'default' | 'email-address';
    secureTextEntry?: boolean;
    autoFocus?: boolean;
    hint?: string;
    testID: string;
}>;
/**
 * A one-time code: Bloom's `InputOtp`, one box per character, named by the
 * field's label (the boxes are the field's `multiple` case). `numeric` codes
 * are the email's 6 digits and the authenticator's; `alphanumeric` ones are
 * the long sign-in code and a backup code, both `XXXXX-XXXXX` — upper-cased,
 * the dash dropped, so a pasted code fills every box.
 */
export declare const AccountFlowCodeField: React.FC<{
    label: string;
    value: string;
    onChange: (value: string) => void;
    /** Every box is filled. */
    onComplete?: (value: string) => void;
    error: string | null;
    disabled?: boolean;
    length: number;
    type?: 'numeric' | 'alphanumeric';
    groupEvery?: number;
    autoFocus?: boolean;
    hint?: string;
    testID: string;
}>;
/** The screen's one primary action. */
export declare const AccountFlowAction: React.FC<{
    label: string;
    onPress: () => void;
    pending: boolean;
    disabled?: boolean;
    destructive?: boolean;
    testID: string;
}>;
/** A line of body copy under the header. */
export declare const AccountFlowNote: React.FC<{
    children: React.ReactNode;
    testID?: string;
}>;
/**
 * Something the person should know before acting, above the action it is
 * about: a wait before trying again, a code that was just sent, a warning. A
 * Bloom `Admonition`, not a field's error hint — nothing they typed is wrong.
 */
export declare const AccountFlowNotice: React.FC<{
    children: React.ReactNode;
    type?: 'info' | 'warning' | 'error';
    testID?: string;
}>;
/**
 * Where a step sits in a flow of several (sign-up, turning on the
 * authenticator): Bloom's segmented `WizardProgress` and "Step 2 of 3". The
 * screen's own header names the step, so the progress draws no title; the
 * titles still name the bar for assistive technology.
 */
export declare const AccountFlowProgress: React.FC<{
    steps: readonly string[];
    current: number;
    testID?: string;
}>;
/** Why a step failed, where it happened. */
export declare const AccountFlowErrorLine: React.FC<{
    message: string;
}>;
export interface EmailCodeStepProps {
    /** What was sent, and where. */
    description: string;
    verificationId: string;
    /** The code was right. A rejection is reported in place, like a wrong code. */
    onConfirmed: (confirmed: EmailVerificationConfirmResponse) => void | Promise<void>;
    /** Send a new code; resolves once it is on its way. */
    onResend: () => Promise<void>;
    /** "Use another email" / "Back" — the step before. */
    back: {
        label: string;
        onPress: () => void;
    };
    /** Where this step sits in a longer flow (a `WizardProgress`), under the header. */
    progress?: React.ReactNode;
}
/** "Check your email": the 6-digit code an email verification sent. Submits itself once complete. */
export declare const EmailCodeStep: React.FC<EmailCodeStepProps>;
//# sourceMappingURL=accountFlowParts.d.ts.map