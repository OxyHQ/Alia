import type React from 'react';
import type { BaseScreenProps } from '../types/navigation.js';
import type { PaymentItem, PaymentGatewayResult } from '../components/payment/types.js';
export type { PaymentItem, PaymentGatewayResult };
interface PaymentGatewayScreenProps extends BaseScreenProps {
    onPaymentResult?: (result: PaymentGatewayResult) => void;
    amount: string | number;
    currency?: string;
    onClose?: () => void;
    paymentItems?: PaymentItem[];
    description?: string;
}
declare const PaymentGatewayScreen: React.FC<PaymentGatewayScreenProps>;
export default PaymentGatewayScreen;
//# sourceMappingURL=PaymentGatewayScreen.d.ts.map