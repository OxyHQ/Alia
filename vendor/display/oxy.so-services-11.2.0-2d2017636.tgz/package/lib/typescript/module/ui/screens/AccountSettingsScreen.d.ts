import type React from 'react';
import type { BaseScreenProps } from '../types/navigation.js';
/**
 * Per-account settings: edit the account's profile, jump to member management,
 * and archive the account (danger zone). Receives the target `accountId` via
 * navigation props. Self-surface for the caller's own personal account lives in
 * {@link ManageAccountScreen}; this screen manages a non-personal account in the
 * graph.
 */
declare const AccountSettingsScreen: React.FC<BaseScreenProps>;
export default AccountSettingsScreen;
//# sourceMappingURL=AccountSettingsScreen.d.ts.map