import type { PaymentMethod } from './types.js';
export declare const PAYMENT_METHODS: PaymentMethod[];
export declare const CURRENCY_SYMBOLS: Record<string, string>;
export declare const CURRENCY_NAMES: Record<string, string>;
export declare const getCurrencySymbol: (currency: string) => string;
export declare const getCurrencyName: (currency: string) => string;
//# sourceMappingURL=constants.d.ts.map