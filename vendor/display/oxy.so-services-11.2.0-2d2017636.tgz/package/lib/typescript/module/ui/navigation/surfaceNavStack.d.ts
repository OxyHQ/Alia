import { type StoreApi } from 'zustand/vanilla';
import type { RouteName } from './routes.js';
/**
 * Per-surface route history — the NAV-WITHIN axis.
 *
 * Bloom's surface stack owns DEPTH (a surface presented on top of another). This
 * store owns the ORTHOGONAL axis: the route history INSIDE one SDK surface. Each
 * SDK surface holds its own {@link SurfaceNavStack}; `navigate`/`replace`/`goBack`
 * mutate it and the SAME Bloom surface re-renders its content from the new top
 * frame. It is the per-surface reincarnation of the old global
 * `bottomSheetStore`'s `history` + `currentStep`.
 *
 * `closing`/`closeResult` model a pending dismissal: the surface's `SurfaceScreen`
 * watches them and calls the Bloom surface's `dismiss(result)` from an effect —
 * so a dismiss requested BEFORE the surface has mounted still resolves once it
 * does, with no controls-capture race and no render-phase side effect.
 */
/** One frame in a surface's route history. */
export interface NavFrame {
    route: RouteName;
    props: Record<string, unknown>;
    /** Current wizard step for step-based screens (seeded from `props.initialStep`). */
    step: number;
}
export interface NavStackState {
    /** Bottom → top; the last frame is the visible screen. */
    frames: NavFrame[];
    /** Flipped once a dismiss is requested; the host resolves the Bloom surface. */
    closing: boolean;
    /** The value the surface's `present()` promise resolves with on dismissal. */
    closeResult: unknown;
}
export interface SurfaceNavStack {
    store: StoreApi<NavStackState>;
    /** Drill in: push a new frame. */
    navigate(route: RouteName, props?: Record<string, unknown>): void;
    /** Swap the top frame in place (no history entry). */
    replace(route: RouteName, props?: Record<string, unknown>): void;
    /** Pop one frame. Returns `false` when already at the root frame. */
    goBack(): boolean;
    /** Whether a back is possible (a deeper frame OR a prior wizard step). */
    canGoBack(): boolean;
    /** Set the current frame's wizard step. */
    setStep(step: number): void;
    /** Request dismissal of the whole surface, resolving its promise with `result`. */
    requestDismiss(result?: unknown): void;
    /**
     * Begin a result-bearing SUB-FLOW inside this surface: push `route` as a frame
     * and return a promise that settles when the flow finishes — a descendant's
     * `dismiss(result)` resolves it with `result`, backing out of the flow's entry
     * frame resolves it with `undefined` (cancelled) — popping the surface back to
     * the frame that started the flow WITHOUT dismissing it. This is how a screen
     * already living inside a surface (EditProfile, ManageAccount) opens the avatar
     * flow as a MORPH instead of a stacked surface while still awaiting its result.
     * The avatar flow is ONE flow (`ChangeAvatar`) with plain forward frames pushed
     * on top (the "My Oxy files" `FileManagement` picker, then `AvatarCrop`); the
     * cropper's `dismiss(result)` resolves THIS flow. Flows are kept as a STACK so
     * they can nest generically, even though no current caller opens a flow inside
     * another.
     */
    beginFlow(route: RouteName, props?: Record<string, unknown>): Promise<unknown>;
    /**
     * Resolve the INNERMOST active sub-flow with `result` and pop back to its entry
     * (the frame that called {@link beginFlow}), leaving the surface open. With NO
     * active flow this falls back to {@link requestDismiss} — so a screen presented
     * as its OWN surface still dismisses it. Wired to every screen's `dismiss` prop.
     */
    resolveFlowOrDismiss(result?: unknown): void;
    /** Settle EVERY still-pending sub-flow with `undefined` (the surface is going away). */
    abandonActiveFlow(): void;
    /** The current (top) frame. */
    getTop(): NavFrame;
}
export declare function createSurfaceNavStack(route: RouteName, props?: Record<string, unknown>): SurfaceNavStack;
//# sourceMappingURL=surfaceNavStack.d.ts.map