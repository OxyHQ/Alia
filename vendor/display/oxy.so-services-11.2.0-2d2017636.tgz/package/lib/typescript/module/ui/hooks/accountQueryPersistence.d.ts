/**
 * Offline persistence for an app's PRIVATE, per-account queries.
 *
 * The SDK's own persister (`attachQueryPersistence`) keeps account-agnostic
 * data. An app's mail, library or drafts belong to one account, and every app
 * that wanted them to survive a restart had to scope a persister to the session
 * itself. The SDK owns the session, so it owns this too:
 *
 * - Storage is keyed by the account (`oxy_account_queries:<accountId>`), so a
 *   restore can only ever hydrate the account that is signed in.
 * - Queries written by another build are dropped on restore; queued (paused)
 *   mutations are kept (`persistedQueryCache.ts`).
 * - On a subject change the account's queries, memory-only ones included, and
 *   its paused mutations are dropped from memory synchronously, before anyone
 *   is woken. The leaving account's latest state is written first, a sign-out
 *   then deletes it, and only then is the next account's blob read.
 * - `isReady()` is false until the signed-in account's blob is restored, and
 *   `RequireOxyAuth` waits on it, so another account's rows never render.
 *
 * Every storage operation runs through one queue, in order, and a restore
 * checks that its account is still the active one in the same tick it hydrates.
 */
import { type Mutation, type Query, type QueryClient, type QueryKey } from '@tanstack/react-query';
import type { StorageInterface } from '../utils/storageHelpers.js';
/** An app's declaration of which data is private to the signed-in account. */
export interface AccountQueriesConfig {
    /**
     * Query-key roots (`queryKey[0]`) whose data belongs to the signed-in account
     * and survives a restart. `'all'`: every query the app runs, for an app whose
     * every read may depend on who is signed in, so no root can be forgotten.
     *
     * The roots `accounts`, `sessions` and `devices` are reserved for the SDK's
     * device-level data: an app must not use them. `users` and `privacy` are the
     * SDK's too, and with `'all'` they are dropped on a switch like the app's.
     */
    roots: readonly string[] | 'all';
    /**
     * Roots that belong to the account too, but must not be written to disk
     * (signed URLs, AI output, search results): dropped on a switch, never persisted.
     */
    memoryOnlyRoots?: readonly string[];
    /**
     * Mutation keys whose PAUSED (offline) instances replay after a restart for
     * the same account. Register their `mutationFn` with `setMutationDefaults`.
     */
    mutationKeys?: readonly QueryKey[];
}
/** Which queries and mutations an `AccountQueriesConfig` makes the account's. */
export interface AccountQueryOwnership {
    /** Dropped from memory on a subject change. */
    ownsQuery: (query: Query) => boolean;
    /** Written to the account's blob. */
    persistsQuery: (query: Query) => boolean;
    ownsMutation: (mutation: Mutation) => boolean;
}
export declare function accountQueryOwnership(config: AccountQueriesConfig): AccountQueryOwnership;
export declare const ACCOUNT_QUERY_CACHE_KEY = "oxy_account_queries";
export interface AccountQueryPersistence {
    /** Storage became available (it initializes asynchronously). */
    setStorage(storage: StorageInterface): void;
    /** The signed-in account changed. `null` is a sign-out. Synchronous in-memory reset. */
    activate(accountId: string | null): void;
    /** The owning provider mounted: restore and persist the active account. */
    attach(): void;
    /** The owning provider unmounted: stop touching the client and storage. */
    detach(): void;
    /** True once the active account's cache is restored (always true signed out). */
    isReady(): boolean;
    subscribe(listener: () => void): () => void;
}
export declare function createAccountQueryPersistence(queryClient: QueryClient, config: AccountQueriesConfig): AccountQueryPersistence;
//# sourceMappingURL=accountQueryPersistence.d.ts.map