/**
 * The browser bridge, the app half (ADR 0029 D2).
 *
 * Different domains share no storage, so the browser's ONE Oxy session lives on
 * auth.oxy.so. The first time a person presses sign-in in an Oxy web app that
 * holds no device credential, the app opens `auth.oxy.so/bridge` from that press:
 * a page with no UI that proves (or registers) auth.oxy.so's device, posts this
 * app a one-use code bound to its client id, its exact redirect URI and a PKCE
 * challenge, and closes. The app redeems the code with the verifier only it
 * holds (`POST /session/device/join`) and from then on holds its own credential
 * on the shared device — it never opens the bridge again.
 *
 * Three browser realities, the same ones as the OAuth popup (`oauthPopup.ts`):
 * the window must be opened SYNCHRONOUSLY from the press (gesture attribution),
 * so it is opened empty and navigated once the PKCE pair exists; a cross-origin
 * window fires nothing when it closes, so `closed` is polled; and its result
 * arrives only as a `postMessage`, accepted from the auth origin and from that
 * exact window, carrying this attempt's `state`.
 *
 * Nothing here is required for signing in: a blocked window, a timeout or any
 * failure only means this app signs in on a device of its own, as before.
 */
import type { OxyServices } from '@oxy.so/core';
import type { OAuthPopupHandle } from './types.js';
/** `postMessage` discriminator for a join code from the bridge. */
export declare const OXY_BRIDGE_CODE_MESSAGE_TYPE = "oxy:bridge:code";
/** `postMessage` discriminator for a bridge that could not produce a code. */
export declare const OXY_BRIDGE_ERROR_MESSAGE_TYPE = "oxy:bridge:error";
/** Its own name, so it never reuses (and navigates away) the sign-in popup. */
export declare const OXY_BRIDGE_WINDOW_NAME = "oxy-bridge";
/**
 * How long the bridge may take (ms). It normally answers in a few hundred ms; the
 * ceiling only stops a wedged window from holding the attempt open.
 */
export declare const DEFAULT_BRIDGE_TIMEOUT_MS = 15000;
/** The auth origin the bridge lives on: the authorize override's, else auth.oxy.so. */
export declare function resolveBridgeOrigin(authorizeBaseUrl?: string): string | null;
/**
 * Open the bridge window, EMPTY, as small as the browser allows and centred over
 * the app. MUST be called synchronously from the press. Returns `null` when the
 * browser blocked it or there is no DOM — never throws.
 */
export declare function openBridgeWindow(): OAuthPopupHandle | null;
/** The fields of a `message` event the verdict reads. */
interface BridgeMessageEvent {
    origin: string;
    source: unknown;
    data: unknown;
}
/** Verdict for one `message` event. */
export type BridgeMessageVerdict = {
    kind: 'ignore';
} | {
    kind: 'code';
    code: string;
} | {
    kind: 'error';
    error: string;
};
/**
 * Classify one `message` event. Accepted only from the bridge origin AND the
 * exact window this attempt opened, in one of the two shapes, with this
 * attempt's `state`; everything else is page noise and ignored.
 */
export declare function readBridgeMessage(event: BridgeMessageEvent, context: {
    expectedOrigin: string;
    expectedState: string;
    popup: unknown;
}): BridgeMessageVerdict;
export interface RunBrowserBridgeOptions {
    /** The window {@link openBridgeWindow} returned from the press. */
    popup: OAuthPopupHandle;
    /** Where the bridge lives ({@link resolveBridgeOrigin}). */
    bridgeOrigin: string;
    oxyServices: OxyServices;
    /** This app's registered client id. */
    clientId: string;
    /** This app's EXACT registered redirect URI; its origin is where the code is posted. */
    redirectUri: string;
    /** @default DEFAULT_BRIDGE_TIMEOUT_MS */
    timeoutMs?: number;
}
export type BrowserBridgeResult = {
    ok: true;
    deviceId: string;
    deviceSecret: string;
} | {
    ok: false;
    reason: 'closed' | 'timed-out' | 'bridge-error' | 'join-failed' | 'no-browser';
};
/**
 * Drive an opened bridge window to a device credential for this app. Settles
 * exactly once, closes the window whatever the outcome, and never rejects.
 */
export declare function runBrowserBridge(options: RunBrowserBridgeOptions): Promise<BrowserBridgeResult>;
export {};
//# sourceMappingURL=browserBridge.d.ts.map