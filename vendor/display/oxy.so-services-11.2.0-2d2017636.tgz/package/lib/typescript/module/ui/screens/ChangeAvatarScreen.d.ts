/**
 * ChangeAvatarScreen — the single entry into changing a profile picture.
 *
 * Shows the current avatar large, then the four sources the user can pick from:
 * device gallery, camera, their existing Oxy files, and removing the current
 * photo. Every source that yields an image NAVIGATES WITHIN THIS SURFACE to
 * `AvatarCrop` (never presents it on top), so the panel morphs from frame to
 * frame instead of stacking sheets. The device / camera sources navigate straight
 * to the cropper; the "My Oxy files" source first navigates to the `FileManagement`
 * picker frame, which then forward-navigates to the cropper on selection — a real
 * three-frame stack (this list → picker → cropper). So Cancel on the cropper
 * returns to whichever frame opened it (the picker when re-picking from Oxy files,
 * this list otherwise), and Cancel on the picker returns here. The forward morph
 * is flash-free because only the top frame renders and the cropper does all its
 * own async work (URL resolution + measurement), so no frame is left on screen
 * waiting.
 *
 * The surface resolves with an {@link AvatarCropResult} (the crop confirmed) or
 * an {@link AvatarRemovalResult} (the user removed their photo). This screen
 * performs NO writes: `useAvatarPicker` owns the single upload/removal path.
 *
 * `expo-image-picker` is an optional peer dependency — it is loaded with
 * `await import(...)` so an app that never changes avatars need not install it,
 * and a platform without a given source (camera on web) simply doesn't offer it.
 */
import type React from 'react';
import type { BaseScreenProps } from '../types/navigation.js';
/**
 * The surface resolves with this when the user confirms removing their photo.
 * Distinguished from a crop result by the presence of `removed`, so the awaiting
 * caller narrows without a cast.
 */
export interface AvatarRemovalResult {
    removed: true;
}
declare const ChangeAvatarScreen: React.FC<BaseScreenProps>;
export default ChangeAvatarScreen;
//# sourceMappingURL=ChangeAvatarScreen.d.ts.map