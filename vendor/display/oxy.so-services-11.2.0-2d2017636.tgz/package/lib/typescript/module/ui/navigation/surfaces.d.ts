import { type PresentOptions } from '@oxy.so/bloom/surfaces';
import type { RouteName } from './routes.js';
import { type SurfaceProps, type SurfaceResult } from './surfaceRegistry.js';
import { type SurfaceNavStack } from './surfaceNavStack.js';
/**
 * A live handle to a presented SDK surface. Exposes DEPTH controls (`dismiss`,
 * `result`) and NAV-WITHIN controls (`navigate`/`replace`/`goBack`/`setStep`) that
 * drive this surface's own nav stack. Held by the `showBottomSheet` adapter (base
 * surface) and by `OxyContext` (the AccountDialog surface).
 */
export interface SurfaceInstance<K extends RouteName = RouteName> {
    readonly route: RouteName;
    navigate: (route: RouteName, props?: Record<string, unknown>) => void;
    replace: (route: RouteName, props?: Record<string, unknown>) => void;
    goBack: () => boolean;
    canGoBack: () => boolean;
    setStep: (step: number) => void;
    /** Open a result-bearing sub-flow WITHIN this surface (morph). See {@link openWithinOrPresent}. */
    beginFlow: (route: RouteName, props?: Record<string, unknown>) => Promise<unknown>;
    dismiss: (result?: SurfaceResult<K>) => void;
    readonly result: Promise<SurfaceResult<K> | undefined>;
}
/**
 * The type-erased handle the `showBottomSheet` adapter needs from a tracked
 * surface: what it hosts, and how to drive/dismiss it. Kept result-type-free so
 * the (generic) `SurfaceInstance<K>` never has to be widened into a shared array.
 * Exported so `OxyContext` can hold the surface it MORPHS the account dialog into
 * (see {@link topRouteSurface}).
 */
export interface TrackedSurface {
    readonly route: RouteName;
    navigate: (route: RouteName, props?: Record<string, unknown>) => void;
    goBack: () => boolean;
    /** Open a result-bearing sub-flow WITHIN this surface (morph). See {@link openWithinOrPresent}. */
    beginFlow: (route: RouteName, props?: Record<string, unknown>) => Promise<unknown>;
    dismiss: () => void;
}
/**
 * Present a NEW route surface on top of the stack (the DEPTH axis). Resolves with
 * the value the surface is dismissed with. Registered in the route-surface stack.
 */
export declare function present<K extends RouteName>(route: K, props?: SurfaceProps<K>, opts?: PresentOptions): SurfaceInstance<K>;
/**
 * Present a surface that is NOT part of the `showBottomSheet` base-navigation
 * lineage (the AccountDialog modal). Otherwise identical to {@link present}.
 */
export declare function presentDetached<K extends RouteName>(route: K, props?: SurfaceProps<K>, opts?: PresentOptions): SurfaceInstance<K>;
/**
 * Untyped present for the adapter, the nav helpers, and the `SurfaceScreen`
 * binding (where the route is a runtime value and its props are already erased).
 */
export declare function presentRoute(route: RouteName, props?: Record<string, unknown>): SurfaceInstance;
/** The top-most active route surface, or `undefined` when none are open. */
export declare function topRouteSurface(): TrackedSurface | undefined;
/**
 * The frontmost surface a result-bearing flow should morph INTO: the detached
 * AccountDialog if open (it sits on top of everything), else the top tracked
 * route surface. Used by {@link openWithinOrPresent} so the account-menu hero
 * avatar morphs the dialog into `ChangeAvatar` instead of stacking a new surface.
 */
export declare function topMorphableSurface(): TrackedSurface | undefined;
/**
 * Dismiss every active route surface (the whole `showBottomSheet` session). The
 * AccountDialog is untracked, so it is untouched. Iterates a snapshot because
 * `dismiss` mutates `activeRouteSurfaces` asynchronously as surfaces settle.
 */
export declare function closeAllRouteSurfaces(): void;
/**
 * Drill in from a screen. From inside a surface the DEFAULT is to navigate WITHIN
 * it — the panel MORPHS from the current frame's size to the next's. EVERY screen
 * morphs; a NEW surface is stacked on top ONLY when the target route declares
 * `stacks` (reserved for genuine overlays — none today, since action sheets /
 * confirms / prompts are Bloom-raw `surfaces.present` calls outside this
 * registry). A stacked surface gets its own backdrop + entry animation; dismissing
 * it unwinds back to the surface that opened it.
 */
export declare function navigateWithinOrPresent(navStack: SurfaceNavStack, route: RouteName, props?: Record<string, unknown>): void;
/** Replace variant of {@link navigateWithinOrPresent} (swaps the top frame). */
export declare function replaceWithinOrPresent(navStack: SurfaceNavStack, route: RouteName, props?: Record<string, unknown>): void;
/**
 * Open a result-bearing route the SAME way a drill-in navigates (the morph-by-
 * default rule), but returning the route's dismissal RESULT to the caller.
 *
 * When a surface is already open and the target morphs into it (the default —
 * anything not marked `stacks`), it runs as a SUB-FLOW inside that surface: the
 * panel morphs from the current screen into the target, and the promise resolves
 * with the target's `dismiss(result)` (or `undefined` when cancelled), popping
 * back to the caller's frame WITHOUT closing the host. Otherwise (no surface, or a
 * route that stacks) it presents a fresh surface and resolves with its dismissal —
 * identical to the historical `present(route).result`.
 *
 * The entry seam for the avatar picker AND its nested "My Oxy files" media
 * selector: each awaits its result whether it morphed into the caller's surface
 * or opened cold, with no morph-vs-present branch of its own.
 */
export declare function openWithinOrPresent<K extends RouteName>(route: K, props?: SurfaceProps<K>): Promise<SurfaceResult<K> | undefined>;
/**
 * The SDK's imperative surface API (a module singleton). `present` is the typed
 * route presenter; `dismissAll` unwinds the whole session. Not yet exported from
 * the package root — the public `surfaces`/`useSurfaces` API lands in a later
 * phase; for P1 the internal adapters (`showBottomSheet`, `openAccountDialog`)
 * are the only public entry points.
 */
export declare const surfaces: {
    readonly present: <K extends RouteName>(route: K, props?: SurfaceProps<K>, opts?: PresentOptions) => Promise<SurfaceResult<K> | undefined>;
    readonly dismissAll: typeof closeAllRouteSurfaces;
};
/** Hook form of {@link surfaces} (stable singleton). */
export declare function useSurfaces(): typeof surfaces;
//# sourceMappingURL=surfaces.d.ts.map