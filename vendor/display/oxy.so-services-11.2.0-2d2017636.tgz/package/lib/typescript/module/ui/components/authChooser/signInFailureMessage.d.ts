/**
 * The localized toast for a failed sign-in attempt.
 *
 * One responsibility: turn the controller's machine-readable
 * `signIn.failure` into copy. The controller ships no user-facing prose — its
 * raw `signIn.error` is English or a server string, kept for diagnostics only.
 */
import type { SignInFailureReason } from '@oxy.so/core/session';
import type { Translate } from './types.js';
/** The toast for `failure`, or `null` when there is nothing to report. */
export declare function signInFailureMessage(failure: SignInFailureReason | null, t: Translate): string | null;
//# sourceMappingURL=signInFailureMessage.d.ts.map