import { type ApiError, type User } from '@oxy.so/core';
import { getStorageKeys, type StorageInterface } from '../utils/storageHelpers.js';
import type { OxyServices } from '@oxy.so/core';
import type { QueryClient } from '@tanstack/react-query';
import type { OxyRuntime } from '../runtime/index.js';
export interface UseSessionManagementOptions {
    oxyServices: OxyServices;
    /** The one owner of `sessions` / `activeSessionId` / the signed-in account. */
    runtime: OxyRuntime;
    storage: StorageInterface | null;
    storageKeyPrefix?: string;
    onAuthStateChange?: (user: User | null) => void;
    onError?: (error: ApiError) => void;
    setAuthError?: (message: string | null) => void;
    logger?: (message: string, error?: unknown) => void;
    queryClient?: QueryClient | null;
}
export interface UseSessionManagementResult {
    /** Persist the projected session-id list. Handed to the runtime as its projection sink. */
    saveSessionIds: (sessionIds: string[]) => void;
    saveActiveSessionId: (sessionId: string) => Promise<void>;
    /**
     * The legacy `validateSession`-keyed switch. Reachable from exactly ONE
     * caller: `performSignIn`'s same-user duplicate-session dedup. The switch a
     * consumer sees on the context is the `SessionClient` one in `OxyContext`.
     */
    switchSession: (sessionId: string) => Promise<User>;
    /** Tear down the local session: runtime projection, caches, storage, tokens. */
    clearSessionState: () => Promise<void>;
    storageKeys: ReturnType<typeof getStorageKeys>;
}
/**
 * Session persistence and the one legacy switch left, over the runtime.
 *
 * This hook used to hold its OWN `sessions` / `activeSessionId` React state
 * plus six refs mirroring them so its callbacks could avoid widening their
 * dependency arrays. That made it a second owner of facts `SessionClient`
 * already had, reconciled only by whichever `useEffect` ran last. Both are gone:
 * the runtime owns them, this hook writes through it, and the refs mirrored
 * nothing once there was nothing local to mirror.
 *
 * `refreshSessions`, `trackRemovedSession` and `isRefreshInFlight` are deleted
 * outright — every one of them was dropped unread at the single call site.
 */
export declare const useSessionManagement: ({ oxyServices, runtime, storage, storageKeyPrefix, onAuthStateChange, onError, setAuthError, logger, queryClient, }: UseSessionManagementOptions) => UseSessionManagementResult;
//# sourceMappingURL=useSessionManagement.d.ts.map