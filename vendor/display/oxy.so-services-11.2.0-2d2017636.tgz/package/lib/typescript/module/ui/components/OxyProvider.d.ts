import { type FC } from 'react';
import type { OxyProviderProps } from '../types/navigation.js';
/**
 * OxyProvider - Universal provider for Expo apps (native + web)
 *
 * Provides authentication, session management, query client, and UI overlays.
 * Wraps its own overlay stack in SafeAreaProvider and GestureHandlerRootView so
 * the shared Bloom SURFACE STACK (`<SurfaceProvider>` / `<SurfaceHost>`) — which
 * hosts every SDK surface (the ~35 bottom-sheet routes + the AccountDialog) — can
 * safely render even when a consuming app has not mounted those providers yet.
 *
 * Usage:
 * ```tsx
 * import { OxyProvider, useAuth } from '@oxy.so/services';
 *
 * function App() {
 *   return (
 *     <SafeAreaProvider>
 *       <GestureHandlerRootView style={{ flex: 1 }}>
 *         <OxyProvider baseURL="https://api.oxy.so">
 *           <YourApp />
 *         </OxyProvider>
 *       </GestureHandlerRootView>
 *     </SafeAreaProvider>
 *   );
 * }
 *
 * function MyComponent() {
 *   const { isAuthenticated, user, signIn, signOut } = useAuth();
 *
 *   if (!isAuthenticated) {
 *     return <OxySignInButton />;
 *   }
 *   return <Text>Welcome, {user?.username}!</Text>;
 * }
 * ```
 *
 * An app with its own translated UI passes a language config to follow the account's
 * (or, signed out, the device/guest) resolved locale automatically — see ADR
 * 0022 (`docs/adr/0022-app-i18n-follows-oxy-language.md`):
 * ```tsx
 * <OxyProvider
 *   baseURL="https://api.oxy.so"
 *   language={{
 *     supportedLocales: SUPPORTED_LANGUAGES,       // this app's own catalog
 *     fallbackLocale: DEFAULT_LANGUAGE,
 *     onChange: (locale) => i18n.changeLanguage(locale),
 *   }}
 * >
 * ```
 */
declare const OxyProvider: FC<OxyProviderProps>;
export default OxyProvider;
//# sourceMappingURL=OxyProvider.d.ts.map