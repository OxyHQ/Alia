import React from 'react';
import type { SurfaceControls } from '@oxy.so/bloom/surfaces';
import type { SurfaceNavStack } from '../navigation/surfaceNavStack.js';
export interface SurfaceScreenProps {
    /** This surface's route history (the NAV-WITHIN axis). */
    navStack: SurfaceNavStack;
    /** Bloom's per-surface controls (dismiss / present a child) — the DEPTH axis. */
    surface: SurfaceControls;
    /** Whether backdrop / Escape / back may dismiss at the root frame. Defaults to true. */
    dismissOnBackdrop?: boolean;
}
/**
 * Binds one SDK surface to its content: resolves the lazy screen for the current
 * nav-stack frame and renders it inside the error boundary with the per-surface
 * navigation props. Mounted by `surfaces.present` as the Bloom surface's content.
 *
 * Dismissal is driven through the nav stack's `closing` flag (watched in an
 * effect) rather than a captured-controls call, so a dismiss requested before
 * this surface mounted still resolves the Bloom surface exactly once.
 */
declare function SurfaceScreen({ navStack, surface, dismissOnBackdrop }: SurfaceScreenProps): React.JSX.Element | null;
export default SurfaceScreen;
//# sourceMappingURL=SurfaceScreen.d.ts.map