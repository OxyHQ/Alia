/**
 * `FollowTargetButton` — one button for everything an Oxy user can follow.
 *
 * Follows a TARGET of any registered kind: a person, a topic, a channel, a
 * store, an artist. Nothing in this file branches on what the target is, which
 * is the property that lets an application this package has never heard of use
 * it without a release.
 *
 * ## Two controls, not one
 *
 * The main press does the obvious thing. The chevron beside it opens the
 * choices that a single press cannot express — follow for a while, stop showing
 * this here without giving it up everywhere — and those belong behind a
 * disclosure precisely because they are not what most people want most of the
 * time. Bloom's `DropdownMenu` is platform-forked inside Bloom, so this is one
 * component and not a platform fork here.
 *
 * ## Verbs
 *
 * "Follow" is wrong for half the things in the ecosystem: you subscribe to a
 * channel, you join a community, you watch a listing. The verb is a prop with a
 * small vocabulary of defaults and a full override, rather than a lookup keyed
 * on kind — a kind→verb table in this package would need a release every time
 * an application invents a kind, which is exactly the coupling #809 removes.
 *
 * ## Relationship to the legacy `FollowButton`
 *
 * `FollowButton` follows a USER through the user social graph and
 * remains the correct component for that until the user graph is migrated onto
 * `/v2/follows`. When it is, that component is deleted and this one takes the
 * name — not aliased, not deprecated in place.
 */
import type { FollowStatus } from '@oxy.so/contracts';
import type { StyleProp, ViewStyle } from 'react-native';
import { type FollowDuration } from './followRules.js';
/**
 * The small vocabulary of verbs the ecosystem actually uses. An application
 * whose verb is not here passes `labels` instead — the escape hatch exists so
 * this union never has to grow to accommodate one product's wording.
 */
export type FollowVerb = 'follow' | 'subscribe' | 'join' | 'watch';
export interface FollowLabels {
    /** Not following yet. */
    idle: string;
    /** Following, and this application acts on it. */
    active: string;
    /** Asked, waiting for the other side to accept. */
    pending: string;
    /** Following globally, but switched off in this application. */
    disabled: string;
}
export interface FollowTargetButtonProps {
    /** The registered target's id. Registration is separate — see the SDK. */
    targetId: string;
    verb?: FollowVerb;
    /** Full override, for a verb the vocabulary above does not carry. */
    labels?: Partial<FollowLabels>;
    size?: 'sm' | 'md' | 'lg';
    style?: StyleProp<ViewStyle>;
    disabled?: boolean;
    /**
     * Hide the chevron. For a dense list row where the extra target is more
     * likely to be hit by accident than used on purpose.
     */
    showOptions?: boolean;
    /**
     * Offer timed follows. Pass `false` where a temporary follow makes no sense —
     * a store you buy from, an account you know.
     */
    durations?: FollowDuration[] | false;
    /**
     * This application's name, for the menu line that turns the follow off here.
     * "Don't show in Mention" is a sentence the user can act on; "disable in this
     * application" is not.
     */
    applicationName?: string;
    /**
     * Seed status from a list/feed payload. Incomplete rows (e.g. following without
     * `relationshipId`) still trigger an authoritative refresh once private API is ready.
     */
    initialStatus?: FollowStatus;
    /**
     * Fires when the server accepts a change, with whether this application
     * should act on the follow NOW — the effective state, not the global one.
     *
     * That is the question an application mirroring the follow is actually
     * asking: a user who picks "Don't show in Mercaria" still follows the shop
     * everywhere else, but the shop must leave Mercaria's own shelf, which is
     * the entire purpose of that menu item. Reporting the global state instead
     * would leave it there.
     *
     * Never fires for a refused write — the mutations resolve to whether the
     * server accepted, and only an accepted one gets here.
     */
    onChange?: (activeHere: boolean) => void;
}
export declare const FollowTargetButton: import("react").NamedExoticComponent<FollowTargetButtonProps>;
//# sourceMappingURL=FollowTargetButton.d.ts.map