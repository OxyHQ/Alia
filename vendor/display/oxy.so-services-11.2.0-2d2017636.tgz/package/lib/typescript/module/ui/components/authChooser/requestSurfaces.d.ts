/**
 * The PRIMARY visual of an active "Sign in with Oxy" request — one surface per
 * route, chosen by {@link RequestPrimarySurface} from the controller's own facts.
 *
 * Each is a leading visual and nothing else: the status sentence underneath is
 * owned by `signInProgressLabel`, and the alternatives by `TroubleDisclosure`.
 * That separation is what keeps exactly one primary action on screen (issue
 * #691) — a surface here can never grow a competing button.
 *
 * Anti-phishing: the QR plate encodes `signIn.qrPayload` and renders NOTHING
 * derived from it. Application identity, origin, and scopes are resolved
 * server-side by the approver (Commons), never read out of the payload here.
 */
import type React from 'react';
import MaterialCommunityIcons from '../../icons/MaterialCommunityIcons.js';
import type { CommonsDeliveryRoute } from '@oxy.so/core';
import type { SignInProgress } from '@oxy.so/core/session';
import type { Theme, Translate } from './types.js';
/**
 * The indeterminate leading visual: the request exists but has nothing to show
 * yet. Bloom's spinner, named "Loading…" so assistive technology hears a busy
 * progressbar where the QR will appear; the status sentence under it
 * (`signInProgressLabel`) says what is happening.
 */
export declare const PreparingSurface: React.FC;
/** The leading glyph for a route whose surface is elsewhere (the phone, Commons). */
export declare const RouteGlyph: React.FC<{
    name: keyof typeof MaterialCommunityIcons.glyphMap;
    color: string;
}>;
/** The cross-device handoff: a headline over the fixed-contrast QR plate. */
export declare const QrPlate: React.FC<{
    payload: string;
    theme: Theme;
    t: Translate;
}>;
/**
 * The acquisition surface. For someone with no Commons at all this is the
 * GENUINE primary route, not a fallback — a same-device QR they would have to
 * scan with the very screen showing it is a dead end — so it renders as the
 * surface's one primary action.
 */
export declare const GetCommonsPrompt: React.FC<{
    theme: Theme;
    t: Translate;
    onGetCommons: () => void;
}>;
/**
 * The one primary visual for the request's current state.
 *
 * Ordered most-terminal-first, so a late-arriving route can never pull the
 * surface back from "confirming" to a QR the user has already scanned. Every
 * branch reads only the facts it is handed — there is no local timeline, and no
 * dependency on WHICH kind of request produced them (the account dialog's device
 * flow and the IdP's OAuth-bound lane both resolve the same three).
 */
export declare const RequestPrimarySurface: React.FC<{
    route: CommonsDeliveryRoute | null;
    progress: SignInProgress;
    qrPayload: string | null;
    theme: Theme;
    t: Translate;
}>;
//# sourceMappingURL=requestSurfaces.d.ts.map