import type React from 'react';
import type { ViewStyle, TextStyle, StyleProp } from 'react-native';
import type { PaymentItem, PaymentGatewayResult } from '../screens/PaymentGatewayScreen.js';
export interface PeableButtonProps {
    style?: StyleProp<ViewStyle>;
    textStyle?: StyleProp<TextStyle>;
    text?: string;
    disabled?: boolean;
    amount: number | string;
    currency?: string;
    paymentItems?: PaymentItem[];
    description?: string;
    onPaymentResult?: (result: PaymentGatewayResult) => void;
    /**
     * Button background color. If not provided, uses variant ('white' or 'black').
     */
    color?: string;
    /**
     * Button color variant: 'white' (default) or 'black'. Ignored if color is set.
     */
    variant?: 'white' | 'black';
}
/**
 * A pre-styled button for Peable payments that opens the Payment Gateway
 * - Only black or white by default, but can be customized with the color prop.
 */
declare const PeableButton: React.FC<PeableButtonProps>;
export default PeableButton;
//# sourceMappingURL=PeableButton.d.ts.map