import type { PaymentColors } from './types.js';
export declare const createPaymentStyles: (colors: PaymentColors) => {
    container: {
        flex: number;
    };
    content: {
        flex: number;
        padding: number;
    };
    stepContainer: {
        justifyContent: "flex-start";
        alignItems: "flex-start";
        width: "100%";
    };
    section: {
        marginBottom: number;
        width: "100%";
    };
    sectionTitle: {
        fontSize: number;
        fontWeight: "600";
        color: string;
        marginBottom: number;
    };
    errorContainer: {
        flex: number;
        justifyContent: "center";
        alignItems: "center";
        padding: number;
    };
    errorText: {
        fontSize: number;
        color: string;
        marginBottom: number;
    };
    summaryCard: {
        backgroundColor: string;
        borderRadius: number;
        padding: number;
        marginBottom: number;
        alignItems: "center";
        width: "100%";
    };
    summaryCardContent: {
        alignItems: "center";
        width: "100%";
    };
    summaryCardIcon: {
        marginBottom: number;
    };
    summaryCardMainTitle: {
        fontWeight: "bold";
        fontSize: number;
        color: string;
        marginBottom: number;
        textAlign: "center";
        letterSpacing: number;
    };
    summaryCardSubtitle: {
        fontSize: number;
        color: string;
        textAlign: "center";
        marginBottom: number;
        width: "100%";
    };
    summaryCardItems: {
        width: "100%";
        marginBottom: number;
    };
    summaryItemPrice: {
        color: string;
        fontWeight: "600";
        fontSize: number;
    };
    summaryCardAmount: {
        alignItems: "center";
        width: "100%";
        marginBottom: number;
    };
    summaryCardAmountLabel: {
        fontSize: number;
        color: string;
        textAlign: "center";
        marginBottom: number;
    };
    summaryCardAmountValue: {
        fontSize: number;
        fontWeight: "bold";
        color: string;
        textAlign: "center";
        marginBottom: number;
    };
    summaryCardAmountDescription: {
        fontSize: number;
        color: string;
        textAlign: "center";
        lineHeight: number;
    };
    summaryCardDivider: {
        height: number;
        backgroundColor: string;
        marginVertical: number;
        width: "100%";
    };
    summaryCardTotalSection: {
        width: "100%";
        marginBottom: number;
    };
    summaryCardTotalRow: {
        flexDirection: "row";
        justifyContent: "space-between";
        alignItems: "center";
        paddingVertical: number;
    };
    summaryCardTotalLabel: {
        fontSize: number;
        color: string;
        fontWeight: "500";
    };
    summaryCardTotalValue: {
        fontSize: number;
        color: string;
        fontWeight: "600";
    };
    cardPaymentCard: {
        backgroundColor: string;
        borderRadius: number;
        padding: number;
        marginBottom: number;
        alignItems: "center";
        width: "100%";
    };
    cardPaymentContent: {
        alignItems: "center";
        width: "100%";
    };
    cardPaymentIcon: {
        marginBottom: number;
    };
    cardPaymentMainTitle: {
        fontWeight: "bold";
        fontSize: number;
        color: string;
        marginBottom: number;
        textAlign: "center";
        letterSpacing: number;
    };
    cardPaymentSubtitle: {
        fontSize: number;
        color: string;
        textAlign: "center";
        marginBottom: number;
        width: "100%";
    };
    cardPaymentFields: {
        width: "100%";
        marginBottom: number;
    };
    cardPaymentWaiting: {
        fontSize: number;
        color: string;
        textAlign: "center";
        marginBottom: number;
    };
    cardRowInfo: {
        flexDirection: "row";
        alignItems: "center";
        marginBottom: number;
    };
    cardRowIcon: {
        marginRight: number;
    };
    cardRowText: {
        fontSize: number;
        color: string;
    };
    cardFieldContainer: {
        marginBottom: number;
    };
    cardFieldRow: {
        flexDirection: "row";
        gap: number;
    };
    cardFieldHalfLeft: {
        flex: number;
        marginRight: number;
    };
    cardFieldHalfRight: {
        flex: number;
        marginLeft: number;
    };
    peableCard: {
        backgroundColor: string;
        borderRadius: number;
        padding: number;
        marginBottom: number;
        alignItems: "center";
        width: "100%";
    };
    peableContent: {
        alignItems: "center";
        width: "100%";
    };
    peableIcon: {
        marginBottom: number;
    };
    peableMainTitle: {
        fontWeight: "bold";
        fontSize: number;
        color: string;
        marginBottom: number;
        textAlign: "center";
        letterSpacing: number;
    };
    peableSubtitle: {
        fontSize: number;
        color: string;
        textAlign: "center";
        marginBottom: number;
    };
    peableBalanceBox: {
        backgroundColor: string;
        borderRadius: number;
        padding: number;
        marginTop: number;
    };
    peableBalanceText: {
        color: string;
        fontWeight: "600";
    };
    peableWaiting: {
        fontSize: number;
        color: string;
        textAlign: "center";
        marginBottom: number;
    };
    faircoinCard: {
        backgroundColor: string;
        borderRadius: number;
        padding: number;
        marginBottom: number;
        alignItems: "center";
        width: "100%";
    };
    faircoinContent: {
        alignItems: "center";
        width: "100%";
    };
    faircoinIcon: {
        marginBottom: number;
    };
    faircoinMainTitle: {
        fontWeight: "bold";
        fontSize: number;
        color: string;
        marginBottom: number;
        textAlign: "center";
        letterSpacing: number;
    };
    faircoinSubtitle: {
        color: string;
        fontWeight: "700";
        fontSize: number;
        marginBottom: number;
        textAlign: "center";
        letterSpacing: number;
    };
    faircoinScanText: {
        color: string;
        fontWeight: "600";
        fontSize: number;
        marginBottom: number;
    };
    faircoinQRCard: {
        width: number;
        height: number;
        backgroundColor: string;
        borderRadius: number;
        justifyContent: "center";
        alignItems: "center";
        marginBottom: number;
        padding: number;
        borderWidth: number;
        borderColor: string;
        shadowColor: string;
        shadowOffset: {
            width: number;
            height: number;
        };
        shadowOpacity: number;
        shadowRadius: number;
        elevation: number;
        position: "relative";
    };
    faircoinQRBadge: {
        position: "absolute";
        bottom: number;
        right: number;
        backgroundColor: string;
        borderRadius: number;
        padding: number;
        shadowColor: string;
        shadowOffset: {
            width: number;
            height: number;
        };
        shadowOpacity: number;
        shadowRadius: number;
        elevation: number;
    };
    faircoinTitle: {
        fontSize: number;
        marginBottom: number;
        color: string;
        fontWeight: "600";
        textAlign: "center";
    };
    faircoinAddress: {
        color: string;
        fontSize: number;
        textAlign: "center";
        marginTop: number;
        marginBottom: number;
    };
    faircoinButton: {
        flexDirection: "row";
        alignItems: "center";
        alignSelf: "center";
        backgroundColor: string;
        borderRadius: number;
        paddingHorizontal: number;
        paddingVertical: number;
        marginTop: number;
        marginBottom: number;
    };
    faircoinButtonText: {
        color: string;
        fontWeight: "600";
        fontSize: number;
    };
    faircoinWaiting: {
        fontSize: number;
        color: string;
        textAlign: "center";
        marginBottom: number;
    };
    faircoinPlaceholder: {
        fontSize: number;
        color: string;
        textAlign: "center";
    };
    successCard: {
        backgroundColor: string;
        borderRadius: number;
        padding: number;
        marginBottom: number;
        alignItems: "center";
        width: "100%";
    };
    successContent: {
        alignItems: "center";
        width: "100%";
    };
    successIcon: {
        marginBottom: number;
    };
    successMainTitle: {
        fontWeight: "bold";
        fontSize: number;
        color: string;
        marginBottom: number;
        textAlign: "center";
        letterSpacing: number;
    };
    successSubtitle: {
        fontSize: number;
        color: string;
        textAlign: "center";
        marginBottom: number;
        width: "100%";
    };
    successMessage: {
        fontSize: number;
        color: string;
        textAlign: "center";
        marginBottom: number;
    };
};
//# sourceMappingURL=paymentStyles.d.ts.map