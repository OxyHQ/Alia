import type React from 'react';
import type { OxyContextState, OxyRuntimeProviderProps } from './oxyContextTypes.js';
export type { LogoutResult, OxyContextState, OxyRuntimeProviderProps } from './oxyContextTypes.js';
type OxyAuthActionsContextState = Pick<OxyContextState, 'signIn' | 'logout' | 'logoutAll' | 'refreshSessions' | 'oxyServices' | 'switchToAccount' | 'hasIdentity' | 'getPublicKey' | 'showBottomSheet' | 'openAvatarPicker' | 'openAccountDialog'> & {
    ensureDeviceSessionLane: () => void | Promise<void>;
};
/**
 * The SDK's internal runtime provider — the session/account state machine that
 * backs `useOxy()`.
 *
 * This is NOT the component consumers mount. The one public composition root is
 * `OxyProvider` (`../components/OxyProvider`), which mounts this alongside the
 * QueryClient, Bloom's dialog/surface/toast hosts, safe areas, the gesture root
 * and the keyboard provider. Naming both of them `OxyProvider` (as this file
 * used to) made every error message, stack frame and doc reference ambiguous —
 * see ADR 0004.
 */
export declare const OxyRuntimeProvider: React.FC<OxyRuntimeProviderProps>;
export declare class OxyProviderMissingError extends Error {
    readonly code = "oxy_provider_missing";
    constructor();
}
/**
 * The base runtime hook. THROWS when no `<OxyProvider>` is mounted.
 *
 * It used to return a fabricated forever-loading runtime — `isLoading: true`,
 * `isPrivateApiPending: true`, every method a rejecting no-op — which turned a
 * missing provider into a UI that spins forever with nothing in the console.
 * Failing here names the mistake at the exact component that made it (ADR 0004).
 *
 * A component that legitimately renders both inside and outside the provider
 * uses {@link useOptionalOxy} instead.
 */
export declare const useOxy: () => OxyContextState;
/**
 * `useOxy()` for the rare component that renders both inside and outside the
 * provider — returns `null` instead of throwing. Callers must handle `null`;
 * there is no fabricated runtime to fall back on.
 */
export declare const useOptionalOxy: () => OxyContextState | null;
/** Stable auth commands for selector-based hooks; never carries mutable state. */
export declare const useOxyAuthActions: () => OxyAuthActionsContextState;
//# sourceMappingURL=OxyContext.d.ts.map