import type { OxyServices } from '@oxy.so/core';
import type { OAuthSessionCommitInput } from './types.js';
export interface StartNativeOAuthSignInOptions {
    /** Exact registered URI, including any fixed query. Never inferred. */
    redirectUri: string;
}
export type NativeOAuthSignInResult = {
    status: 'signed-in';
} | {
    status: 'cancelled';
} | {
    status: 'unsupported';
    reason: 'unsupported-platform' | 'missing-client-id' | 'identity-bound' | 'not-third-party';
} | {
    status: 'failed';
    reason: 'invalid-redirect-uri' | 'client-resolution-failed' | 'native-callback-invalid' | 'state-mismatch' | 'exchange-failed' | 'already-in-progress';
};
export interface NativeOAuthSignInContext {
    platform: 'native' | 'unsupported';
    oxyServices: OxyServices;
    clientId: string | null;
    authorizeBaseUrl?: string;
    identityBound: boolean;
    commitSession: (input: OAuthSessionCommitInput) => Promise<void>;
}
/** SDK owns the in-memory handshake, observed native callback and session commit. */
export declare function startNativeOAuthSignIn(context: NativeOAuthSignInContext, options: StartNativeOAuthSignInOptions): Promise<NativeOAuthSignInResult>;
//# sourceMappingURL=nativeAuthTransport.d.ts.map