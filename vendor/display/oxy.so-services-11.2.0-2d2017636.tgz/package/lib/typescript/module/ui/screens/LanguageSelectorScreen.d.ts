import React from 'react';
import type { BaseScreenProps } from '../types/navigation.js';
interface LanguageSelectorScreenProps extends BaseScreenProps {
}
declare const _default: React.NamedExoticComponent<LanguageSelectorScreenProps>;
export default _default;
//# sourceMappingURL=LanguageSelectorScreen.d.ts.map