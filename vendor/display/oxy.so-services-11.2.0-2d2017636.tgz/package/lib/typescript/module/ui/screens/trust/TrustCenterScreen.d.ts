import type React from 'react';
import type { BaseScreenProps } from '../../types/navigation.js';
declare const TrustCenterScreen: React.FC<BaseScreenProps>;
export default TrustCenterScreen;
//# sourceMappingURL=TrustCenterScreen.d.ts.map