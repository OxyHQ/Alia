import React from 'react';
import type { BaseScreenProps } from '../types/navigation.js';
/**
 * Field types supported by EditProfileFieldScreen
 */
export type ProfileFieldType = 'displayName' | 'username' | 'bio' | 'phone' | 'address' | 'birthday' | 'location' | 'locations' | 'links';
interface EditProfileFieldScreenProps extends BaseScreenProps {
    /** The field type to edit */
    fieldType?: ProfileFieldType;
}
declare const _default: React.NamedExoticComponent<EditProfileFieldScreenProps>;
export default _default;
//# sourceMappingURL=EditProfileFieldScreen.d.ts.map