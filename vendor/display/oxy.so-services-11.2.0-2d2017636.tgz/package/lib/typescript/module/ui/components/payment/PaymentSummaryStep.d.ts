import type React from 'react';
import type { PaymentItem, PaymentColors, PaymentStepAnimations } from './types.js';
interface PaymentSummaryStepProps {
    paymentItems: PaymentItem[];
    amount: string | number;
    currency: string;
    description?: string;
    colors: PaymentColors;
    animations: PaymentStepAnimations;
    onClose: () => void;
    onNext: () => void;
}
declare const PaymentSummaryStep: React.FC<PaymentSummaryStepProps>;
export default PaymentSummaryStep;
//# sourceMappingURL=PaymentSummaryStep.d.ts.map