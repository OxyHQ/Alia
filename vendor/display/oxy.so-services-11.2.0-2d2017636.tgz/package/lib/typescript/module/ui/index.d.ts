/**
 * @oxy.so/services/ui — public subpath
 *
 * Tree-shakeable static re-exports of the most common UI surface. Backend
 * environments (SSR) should import `@oxy.so/services/ui/server` instead;
 * client-only callers can use `@oxy.so/services/ui/client` for a slightly
 * narrower bundle.
 *
 * Static `export ... from` only — no runtime `require()`, no platform
 * conditionals. The previous `if (isFrontend) require(...)` pattern was
 * removed because it (a) violated the dual CJS/ESM build rule (ESM bundles
 * cannot contain `require()` per CLAUDE.md) and (b) defeated tree-shaking.
 */
export { default as OxyProvider } from './components/OxyProvider.js';
export { default as OxySignInButton } from './components/OxySignInButton.js';
export { default as OxyAuthPrompt } from './components/OxyAuthPrompt.js';
export type { OxyAuthPromptProps } from './components/OxyAuthPrompt.js';
export { LogoIcon } from './components/logo/LogoIcon.js';
export { LogoText } from './components/logo/LogoText.js';
export { RequireOxyAuth } from './components/RequireOxyAuth.js';
export type { RequireOxyAuthProps, RequireOxyAuthPrompt } from './components/RequireOxyAuth.js';
export type { AccountQueriesConfig } from './hooks/accountQueryPersistence.js';
export { default as FollowButton } from './components/FollowButton.js';
export { default as PeableButton } from './components/PeableButton.js';
export type { PeableButtonProps } from './components/PeableButton.js';
/** @deprecated Use `PeableButton` instead. */
export { default as OxyPayButton } from './components/OxyPayButton.js';
/** @deprecated Use `PeableButtonProps` instead. */
export type { OxyPayButtonProps } from './components/OxyPayButton.js';
export { default as ProfileButton } from './components/ProfileButton.js';
export { useOxy, useOptionalOxy, OxyProviderMissingError } from './context/OxyContext.js';
export { useAuth } from './hooks/useAuth.js';
export type { AuthActions, AuthState, SignInOutcome, UseAuthReturn } from './hooks/useAuth.js';
export { useFollow, useSeedFollowStatuses } from './hooks/useFollow.js';
export { useStorage } from './hooks/useStorage.js';
export type { UseStorageOptions, UseStorageResult } from './hooks/useStorage.js';
export { useAuthStore } from './stores/authStore.js';
export { handleAuthError, isInvalidSessionError, isTimeoutOrNetworkError, extractErrorMessage, } from './utils/errorHandlers.js';
export type { HandleAuthErrorOptions } from './utils/errorHandlers.js';
//# sourceMappingURL=index.d.ts.map