/**
 * OxyAccountDialogScreen — the ONE unified account dialog BODY for `@oxy.so/services`.
 *
 * The header (title/subtitle per view + back button) around the headless chooser
 * logic, which lives in `OxyAuthChooser` — the account switcher, sign-in,
 * sign-up, and QR views are ALL there, extracted so the same chooser can be
 * mounted bare by a host with no Dialog chrome (auth.oxy.so's `/login`). This
 * file owns ONLY the header + the scroll body.
 *
 * It is presented as the `AccountDialog` route on the shared Bloom SURFACE STACK
 * (`@oxy.so/bloom/surfaces`) — `OxyContext.openAccountDialog` calls
 * `presentDetached('AccountDialog', …, { placement: { base: 'bottom', md:
 * 'center' }, dismissOnBackdrop: false, maxWidth: 420 })`, so the STACK owns the
 * responsive `<Dialog>` chrome and this component renders only its content. That
 * replaces the previous standalone controlled `<Dialog open={isAccountDialogOpen}>`
 * mount: dismissal now flows through the stack (backdrop/swipe disabled), and the
 * header close button (and `OxyAuthChooser`'s `onComplete`) drive
 * `useOxy().closeAccountDialog`, which dismisses the surface and runs its exit
 * animation. The view-enum (`accounts|signin|qr|add|signup`) stays internal here,
 * driven by the shared `AccountDialogController` in `@oxy.so/core`.
 */
import type React from 'react';
import type { BaseScreenProps } from '../types/navigation.js';
/**
 * The unified account dialog BODY — the header + `OxyAuthChooser` chooser.
 *
 * Presented as the `AccountDialog` surface (route) on the shared Bloom surface
 * stack; the surface owns the `<Dialog>` chrome (responsive `{ base: 'bottom',
 * md: 'center' }` placement, `dismissOnBackdrop={false}`, `maxWidth={420}` — set
 * by `OxyContext` when it presents this surface), so this component renders ONLY
 * the content. Open it via `useOxy().openAccountDialog(view?)` or the imperative
 * `openAccountDialog('signin')`; the view-enum (`accounts|signin|qr|add|signup`)
 * stays internal here, driven by the shared `AccountDialogController` in
 * `@oxy.so/core`. Closing routes through `useOxy().closeAccountDialog`, which
 * dismisses the surface and runs its exit animation.
 */
declare const OxyAccountDialogScreen: React.FC<BaseScreenProps>;
export default OxyAccountDialogScreen;
//# sourceMappingURL=OxyAccountDialogScreen.d.ts.map