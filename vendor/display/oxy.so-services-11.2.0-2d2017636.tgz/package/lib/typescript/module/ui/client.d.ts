/**
 * Client-only UI exports — the lean entry.
 *
 * Import from this module in an app's startup path. The root barrel also
 * re-exports the sign-in panels (`OxySignInPanel`, `OxyLinkCommonsPanel` and
 * its QR code, `OxyConsentScreen`, …) for apps that embed them, and Metro does
 * not tree-shake, so importing ANY symbol from `@oxy.so/services` ships all of
 * them — even though the account dialog that normally shows them is loaded on
 * demand. Nothing exported here reaches those panels; the packaging test
 * `clientEntryIsolation` pins it.
 *
 * @example
 * import { OxyProvider, useOxy, LogoIcon } from '@oxy.so/services/ui/client';
 */
export { default as OxyProvider } from './components/OxyProvider.js';
export { default as OxySignInButton } from './components/OxySignInButton.js';
export { default as OxyAuthPrompt } from './components/OxyAuthPrompt.js';
export type { OxyAuthPromptProps } from './components/OxyAuthPrompt.js';
export { LogoIcon } from './components/logo/LogoIcon.js';
export { LogoText } from './components/logo/LogoText.js';
export { default as FollowButton } from './components/FollowButton.js';
export { default as ProfileButton } from './components/ProfileButton.js';
export type { ProfileButtonProps } from './components/ProfileButton.js';
export { default as PeableButton } from './components/PeableButton.js';
export type { PeableButtonProps } from './components/PeableButton.js';
/** @deprecated Use `PeableButton` instead. */
export { default as OxyPayButton } from './components/OxyPayButton.js';
/** @deprecated Use `PeableButtonProps` instead. */
export type { OxyPayButtonProps } from './components/OxyPayButton.js';
export { useOxy, useOptionalOxy, OxyProviderMissingError } from './context/OxyContext.js';
export { useAuth } from './hooks/useAuth.js';
export type { AuthState, AuthActions, SignInOutcome, UseAuthReturn } from './hooks/useAuth.js';
export { createDeferredProductAnalytics } from './analytics/productAnalytics.js';
export type { OxyProductEvent, ProductAnalytics } from './analytics/productAnalytics.js';
export { useFollow, useFollowerCounts, useSeedFollowStatuses } from './hooks/useFollow.js';
export { useFollowTarget } from './hooks/useFollowTarget.js';
export type { UseFollowTargetResult } from './hooks/useFollowTarget.js';
export { useUserProfile, useUserProfiles, useCurrentUser, useUserById, useUserByUsername, } from './hooks/queries/useAccountQueries.js';
export { useStorage } from './hooks/useStorage.js';
export type { UseStorageOptions, UseStorageResult } from './hooks/useStorage.js';
export { buildFollowMenuItems, resolveFollowPrimaryAction, FOLLOW_ACTION_LEAVES_ACTIVE, } from './components/followRules.js';
export type { FollowDuration, FollowMenuItem } from './components/followRules.js';
export { queryKeys, invalidateAccountQueries, invalidateUserQueries, invalidateSessionQueries, invalidateDeviceQueries, invalidatePrivacyQueries, invalidateSecurityQueries, invalidateStorageQueries, invalidatePaymentsQueries, invalidateConnectedAppsQueries, invalidateAuthMethodsQueries, } from './hooks/queries/queryKeys.js';
export { upsertCachedUser, upsertCachedUsers, CLEARABLE_USER_FIELDS, clearedFieldsFromProfileUpdate, clearedFieldsFromAccountUpdate, } from './hooks/queries/userCache.js';
export type { CacheableUser, ClearableUserField, UpsertCachedUserOptions, } from './hooks/queries/userCache.js';
export { useAuthStore } from './stores/authStore.js';
export { handleAuthError, isInvalidSessionError, isTimeoutOrNetworkError, extractErrorMessage, } from './utils/errorHandlers.js';
export type { HandleAuthErrorOptions } from './utils/errorHandlers.js';
//# sourceMappingURL=client.d.ts.map