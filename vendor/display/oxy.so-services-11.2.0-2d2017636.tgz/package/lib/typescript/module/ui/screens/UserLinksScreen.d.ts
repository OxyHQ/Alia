import type React from 'react';
import type { BaseScreenProps } from '../types/navigation.js';
interface UserLinksScreenProps extends BaseScreenProps {
    userId: string;
    links?: Array<{
        url: string;
        title?: string;
        description?: string;
        image?: string;
        id: string;
    }>;
}
declare const UserLinksScreen: React.FC<UserLinksScreenProps>;
export default UserLinksScreen;
//# sourceMappingURL=UserLinksScreen.d.ts.map