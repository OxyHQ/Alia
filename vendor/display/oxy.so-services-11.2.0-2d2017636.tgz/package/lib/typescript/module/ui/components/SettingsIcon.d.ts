import type React from 'react';
import MaterialCommunityIcons from '../icons/MaterialCommunityIcons.js';
interface SettingsIconProps {
    /** MaterialCommunityIcons icon name */
    name: React.ComponentProps<typeof MaterialCommunityIcons>['name'];
    /** Background color for the circle */
    color: string;
    /** Icon size (default 14, fits bloom's 20x20 container) */
    iconSize?: number;
    /** Container size (default 20, matches bloom SettingsListItem icon slot) */
    size?: number;
}
export declare const SettingsIcon: React.NamedExoticComponent<SettingsIconProps>;
export default SettingsIcon;
//# sourceMappingURL=SettingsIcon.d.ts.map