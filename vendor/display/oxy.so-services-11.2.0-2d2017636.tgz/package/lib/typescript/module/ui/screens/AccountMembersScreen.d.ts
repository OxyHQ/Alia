import type React from 'react';
import type { BaseScreenProps } from '../types/navigation.js';
/**
 * Manage the members of an account (invite by email, change roles,
 * remove, transfer ownership). Gated on the caller's `callerMembership`
 * permissions. Receives the target `accountId` via navigation props.
 */
declare const AccountMembersScreen: React.FC<BaseScreenProps>;
export default AccountMembersScreen;
//# sourceMappingURL=AccountMembersScreen.d.ts.map