import type { FeedbackType, PriorityLevel } from './types.js';
export declare const FEEDBACK_TYPES: FeedbackType[];
export declare const PRIORITY_LEVELS: PriorityLevel[];
export declare const CATEGORIES: Record<string, string[]>;
//# sourceMappingURL=constants.d.ts.map