import type React from 'react';
import type { FileManagementScreenProps } from '../types/fileManagement.js';
declare const FileManagementScreen: React.FC<FileManagementScreenProps>;
export default FileManagementScreen;
//# sourceMappingURL=FileManagementScreen.d.ts.map