import type { ApiError, User } from '@oxy.so/core';
import type { AuthStateStore, IdentityBinding, SessionClient } from '@oxy.so/core/session';
import type { OxyRuntime } from '../../runtime/index.js';
import type { LogoutResult } from '../oxyContextTypes.js';
import type { StorageInterface } from '../../utils/storageHelpers.js';
import type { OxyServices } from '@oxy.so/core';
export interface UseAuthOperationsOptions {
    oxyServices: OxyServices;
    ensureDeviceSessionLane: () => void | Promise<void>;
    storage: StorageInterface | null;
    /**
     * The device-first persisted auth-state store. On EXPLICIT full sign-out the
     * session blob is cleared (`store.clear()`) so a reload's cold boot finds no
     * device credential to restore; on sign-in the returned zero-cookie device
     * credential (`deviceId` + `deviceSecret`) is persisted so the next boot
     * warm-restores without a redirect.
     */
    store: AuthStateStore;
    /**
     * The one owner of the session facts. Reads (`activeSessionId`) and writes
     * (the account, the session mirror, the loading/error gates) both go through
     * it, so this hook holds no copy of anything to fall out of step.
     */
    runtime: OxyRuntime;
    saveActiveSessionId: (sessionId: string) => Promise<void>;
    clearSessionState: () => Promise<void>;
    /** Used only by `performSignIn`'s same-user duplicate-session dedup (legacy session-validate path; unrelated to the SessionClient device-account set). */
    switchSession: (sessionId: string) => Promise<User>;
    /**
     * The Phase 3-A/3-B `SessionClient` (server-authoritative device account
     * set). Device-scoped sign-out routes through `sessionClient.signOut(...)`.
     * `logoutAll` additionally uses the global bearer endpoint so sessions on
     * other devices and their refresh-token families are revoked.
     */
    sessionClient: SessionClient;
    /** Reprojects `sessionClient.getState()` onto sessions/activeSessionId/user (Task 1's callback). Awaited after a partial `signOut` so the exposed state reflects the server truth before the call resolves. */
    syncFromClient: () => Promise<void>;
    onAuthStateChange?: (user: User | null) => void;
    onError?: (error: ApiError) => void;
    logger?: (message: string, error?: unknown) => void;
    /**
     * Identity-bound session (`sessionMode: 'identity'`). When set, a successful
     * key sign-in writes the durable `{publicKey, accountId}` pin so pinned
     * re-mints and projections bind immediately instead of waiting for a second
     * `establishIdentitySession` round-trip.
     */
    identityBinding?: IdentityBinding;
    /** Refreshes the provider's memoised pinned account id after the pin lands. */
    refreshPinnedAccountId?: () => Promise<string | null>;
}
export interface UseAuthOperationsResult {
    /** Sign in with existing public key */
    signIn: (publicKey: string, deviceName?: string) => Promise<User>;
    /** Logout from current session. Never rejects — see {@link LogoutResult}. */
    logout: (targetSessionId?: string) => Promise<LogoutResult>;
    /** Logout from all sessions */
    logoutAll: () => Promise<void>;
}
/**
 * Clear the persisted device credential on an explicit full sign-out.
 * Best-effort and non-blocking: sign-out must never fail because a storage
 * write threw. Exported so `OxyContext`'s zero-account branch (a REMOTE full
 * sign-out pushed over the socket) runs the EXACT same cleanup as the local
 * `logout` / `logoutAll` paths — a remote sign-out is indistinguishable from a
 * local one to the next cold boot.
 */
export declare function clearPersistedAuthSafe(store: AuthStateStore, logger?: (message: string, error?: unknown) => void): Promise<void>;
/**
 * Authentication operations using public key cryptography.
 * Accepts public key as parameter - identity management is handled by the app layer.
 */
export declare const useAuthOperations: ({ oxyServices, ensureDeviceSessionLane, store, runtime, saveActiveSessionId, clearSessionState, switchSession, sessionClient, syncFromClient, onAuthStateChange, onError, logger, identityBinding, refreshPinnedAccountId, }: UseAuthOperationsOptions) => UseAuthOperationsResult;
//# sourceMappingURL=useAuthOperations.d.ts.map