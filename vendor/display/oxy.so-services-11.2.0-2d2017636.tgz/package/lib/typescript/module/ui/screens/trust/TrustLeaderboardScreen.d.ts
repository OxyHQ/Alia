import type React from 'react';
import type { BaseScreenProps } from '../../types/navigation.js';
declare const TrustLeaderboardScreen: React.FC<BaseScreenProps>;
export default TrustLeaderboardScreen;
//# sourceMappingURL=TrustLeaderboardScreen.d.ts.map