/**
 * Runtime validation for the popup OAuth `postMessage` channel.
 *
 * Everything arriving on `window`'s `message` event is untrusted: any frame on
 * the page, any other popup, and any browser extension can post to us. This
 * module is the ONLY place that decides whether an incoming event is a genuine
 * authorization response, and it answers with a value — never a thrown error.
 *
 * A message is accepted only when ALL of these hold:
 *   1. `event.origin` is EXACTLY the authorize endpoint's origin,
 *   2. `event.source` is the exact `Window` reference we opened,
 *   3. `event.data` matches one of the two frozen message shapes,
 *   4. the `state` it carries matches the one this RP sent.
 *
 * Failing (1)–(3) is indistinguishable from unrelated page traffic, so the
 * message is IGNORED and the flow keeps waiting. Failing (4) means our own
 * popup answered a different request than the one in flight, which is terminal:
 * it is reported as a mismatch rather than left to hang until the timeout.
 */
import type { OAuthPopupHandle, OxyOAuthMessage } from './types.js';
/** `postMessage` discriminator for a successful authorization. */
export declare const OXY_OAUTH_CODE_MESSAGE_TYPE = "oxy:oauth:code";
/** `postMessage` discriminator for a typed OAuth failure. */
export declare const OXY_OAUTH_ERROR_MESSAGE_TYPE = "oxy:oauth:error";
/** Verdict for one incoming `message` event. */
export type OAuthPopupMessageVerdict = 
/** Not ours (wrong origin/source) or not a valid message — keep waiting. */
{
    kind: 'ignore';
} | {
    kind: 'code';
    code: string;
    state: string;
} | {
    kind: 'oauth-error';
    error: string;
    errorDescription?: string;
}
/** Well-formed, from our popup, but bound to a different authorize request. */
 | {
    kind: 'state-mismatch';
};
/** What {@link readOAuthPopupMessage} validates an event against. */
export interface OAuthPopupMessageContext {
    /** Exact origin of the authorize endpoint (`new URL(authorizeUrl).origin`). */
    expectedOrigin: string;
    /** The CSRF `state` this RP sent on the authorize request. */
    expectedState: string;
    /** The exact popup reference `window.open()` returned. */
    popup: OAuthPopupHandle;
}
/**
 * Parse untrusted `event.data` into one of the two frozen message shapes, or
 * `null` when it is anything else (including `null`, primitives, arrays, and
 * objects with missing/wrong-typed fields).
 *
 * Unknown extra properties are tolerated but never read: only the fields below
 * are ever surfaced, so a hostile sender cannot smuggle values past this point.
 */
export declare function parseOAuthPopupMessage(data: unknown): OxyOAuthMessage | null;
/**
 * Classify one `message` event against the in-flight authorize request.
 *
 * Never throws. See the module header for the acceptance rules.
 */
export declare function readOAuthPopupMessage(event: MessageEvent, context: OAuthPopupMessageContext): OAuthPopupMessageVerdict;
//# sourceMappingURL=oauthPopupMessages.d.ts.map