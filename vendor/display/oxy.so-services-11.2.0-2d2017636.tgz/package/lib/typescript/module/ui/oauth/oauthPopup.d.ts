/**
 * Popup lifecycle for the web OAuth transport.
 *
 * Owns the window itself — opening it, navigating it, watching it, and tearing
 * every listener and timer down — and nothing else: message validation lives in
 * `oauthPopupMessages.ts`, and the code exchange in `completeOAuthCode.ts`.
 *
 * Three browser realities shape this module:
 *
 * - **Gesture attribution.** `window.open` only succeeds while the user's click
 *   is still being handled. Anything awaited first (resolving the application,
 *   generating PKCE) loses it and the popup is silently blocked. So the window
 *   is opened EMPTY up front and navigated once the authorize URL exists —
 *   a plain function a test can substitute.
 * - **No close event.** A cross-origin popup fires nothing when the user
 *   dismisses it; polling `closed` is the only mechanism.
 * - **No cross-origin reads.** The popup's URL, title, and document are all
 *   opaque. The authorization result arrives ONLY as a `postMessage`.
 */
import type { OAuthPopupHandle, OAuthPopupOutcome } from './types.js';
/**
 * Window name for the sign-in popup. Naming the target means a second press
 * REUSES the same window instead of stacking a new one behind the first.
 */
export declare const OXY_OAUTH_POPUP_WINDOW_NAME = "oxy-oauth";
/**
 * How long a popup sign-in may stay unanswered (ms).
 *
 * Generous on purpose: the IdP surface can involve scanning a QR and approving
 * on a phone, so this tracks the authorize handle's own ~5-minute lifetime
 * rather than a UI-scale timeout. It is a backstop against a wedged popup, not
 * a pace-setter — a user who gives up closes the window and gets the faster
 * `closed` outcome.
 */
export declare const DEFAULT_OAUTH_POPUP_TIMEOUT_MS = 300000;
/**
 * Open a new, EMPTY sign-in popup.
 *
 * MUST be called SYNCHRONOUSLY from a user-gesture handler, before any `await`.
 * Returns `null` when the browser blocked it, when `window.open` threw, and on
 * hosts with no DOM (native / SSR) — never throws, because "no popup" is an
 * ordinary outcome the caller answers by falling back to a redirect.
 */
export declare function openOAuthPopup(): OAuthPopupHandle | null;
/**
 * Point an already-open popup at the authorize URL. Returns `false` when the
 * assignment threw (a window closed between opening and navigating), so the
 * caller can fall back to a redirect instead of waiting on a dead window.
 */
export declare function navigateOAuthPopup(popup: OAuthPopupHandle, url: string): boolean;
/** Close the popup if it is still open. Idempotent, null-safe, never throws. */
export declare function closeOAuthPopup(popup: OAuthPopupHandle | null): void;
/** Inputs for {@link awaitOAuthPopupResult}. */
export interface AwaitOAuthPopupOptions {
    /** The exact window reference returned by {@link openOAuthPopup}. */
    popup: OAuthPopupHandle;
    /** Exact origin the IdP will post from (`new URL(authorizeUrl).origin`). */
    expectedOrigin: string;
    /** The CSRF `state` sent on the authorize request. */
    expectedState: string;
    /**
     * EXACT registered redirect URI for this attempt. When the IdP cannot
     * `postMessage` (no usable opener) it falls back to redirecting the popup;
     * if that lands on the same origin, the result is read from the popup URL.
     */
    redirectUri: string;
    /** @default DEFAULT_OAUTH_POPUP_TIMEOUT_MS */
    timeoutMs?: number;
}
/**
 * Wait for the popup to deliver an authorization result.
 *
 * Settles EXACTLY once, with a typed outcome for every path — code, IdP error,
 * state mismatch, user-closed, timeout — and removes its listener, its close
 * poll, and both timers before resolving, whatever the outcome. Messages that
 * arrive after settling reach nothing, so a duplicate delivery is inert.
 *
 * Never rejects: closing the window and running out of time are expected
 * outcomes, not exceptions.
 */
export declare function awaitOAuthPopupResult(options: AwaitOAuthPopupOptions): Promise<OAuthPopupOutcome>;
//# sourceMappingURL=oauthPopup.d.ts.map