import React from 'react';
import type { BaseScreenProps } from '../types/navigation.js';
declare const _default: React.NamedExoticComponent<BaseScreenProps>;
export default _default;
//# sourceMappingURL=NotificationsScreen.d.ts.map