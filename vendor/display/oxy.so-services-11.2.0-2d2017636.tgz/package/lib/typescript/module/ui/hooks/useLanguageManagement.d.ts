import type { ApiError, User, SupportedLanguage } from '@oxy.so/core';
import type { StorageInterface } from '../utils/storageHelpers.js';
export interface UseLanguageManagementOptions {
    storage: StorageInterface | null;
    languageKey: string;
    /**
     * The active account, when signed in. When present, the account's primary
     * locale (`languages[0]`) is authoritative for the app's UI locale; when
     * `null` the device locale (or a locally-chosen guest override) is used.
     */
    user: User | null;
    onError?: (error: ApiError) => void;
    logger?: (message: string, error?: unknown) => void;
}
export interface UseLanguageManagementResult {
    /**
     * The active UI locale (a canonical `language-REGION` tag). Derived, never
     * stored: the account's primary locale when signed in, otherwise the
     * locally-chosen guest override, otherwise the device locale.
     */
    currentLanguage: string;
    /**
     * The ordered account locales (primary first) when signed in, or the single
     * guest override when signed out. Empty only before the guest override loads
     * and no device locale resolves.
     */
    languages: string[];
    metadata: SupportedLanguage | null;
    languageName: string;
    nativeLanguageName: string;
    /**
     * Persist a single locally-owned locale (guest / device override) and mark it
     * primary. For signed-in accounts, locale changes are written to the account
     * (`updateProfile({ languages })`) instead — the derived `currentLanguage`
     * then follows the refreshed `user`.
     */
    setLanguage: (locale: string) => Promise<void>;
    hydrateLanguage: () => Promise<void>;
}
/**
 * Append `locale` to an ordered locale list if not already present. Canonical
 * order is preserved; the new locale lands last (non-primary).
 */
export declare function addLocale(languages: readonly string[], locale: string): string[];
/**
 * Remove `locale` from an ordered locale list. The list's new first element
 * becomes the primary locale.
 */
export declare function removeLocale(languages: readonly string[], locale: string): string[];
/**
 * Move `locale` to the front of an ordered locale list, making it primary.
 * Adds it if it was not already present.
 */
export declare function setPrimaryLocale(languages: readonly string[], locale: string): string[];
/**
 * Resolve and manage the app's active UI locale.
 *
 * The active locale is DERIVED, not stored:
 *  - Signed in  → the account's primary locale (`getPrimaryLanguage(user)`),
 *    falling back to {@link FALLBACK_LOCALE}. This is what makes every Oxy app
 *    follow the account's language automatically.
 *  - Signed out → a locally-chosen guest override if one exists, otherwise the
 *    device locale.
 *
 * The only external system this hook synchronizes with is local storage (the
 * guest override), which is loaded once on mount.
 */
export declare const useLanguageManagement: ({ storage, languageKey, user, onError, logger, }: UseLanguageManagementOptions) => UseLanguageManagementResult;
//# sourceMappingURL=useLanguageManagement.d.ts.map