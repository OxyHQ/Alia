import type React from 'react';
import type { BaseScreenProps } from '../../types/navigation.js';
declare const TrustAboutScreen: React.FC<BaseScreenProps>;
export default TrustAboutScreen;
//# sourceMappingURL=TrustAboutScreen.d.ts.map