import type React from 'react';
import type { FollowGraphSort } from '@oxy.so/core';
import type { BaseScreenProps } from '../types/navigation.js';
interface FollowersListScreenProps extends BaseScreenProps {
    userId: string;
    initialCount?: number;
    /** List ordering — see `UserListScreen`. Omitted ⇒ the server default. */
    sort?: FollowGraphSort;
}
declare const FollowersListScreen: React.FC<FollowersListScreenProps>;
export default FollowersListScreen;
//# sourceMappingURL=FollowersListScreen.d.ts.map