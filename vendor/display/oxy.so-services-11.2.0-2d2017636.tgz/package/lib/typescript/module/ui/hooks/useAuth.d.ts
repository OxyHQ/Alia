/**
 * Unified Auth Hook
 *
 * Provides a clean, standard interface for authentication across all platforms.
 * This is the recommended way to access auth state in Oxy apps.
 *
 * Usage:
 * ```tsx
 * import { useAuth } from '@oxy.so/services';
 *
 * function MyComponent() {
 *   const { user, isAuthenticated, isLoading, signIn, signOut } = useAuth();
 *
 *   if (isLoading) return <Loading />;
 *   if (!isAuthenticated) return <SignInButton onClick={() => signIn()} />;
 *   return <Welcome user={user} />;
 * }
 * ```
 *
 * Session restore (zero cookies):
 * - Web: this origin's own persisted `{deviceId, deviceSecret}` — a signed-out
 *   origin stays signed out until the user presses "Continue with Oxy". There is
 *   no cross-origin silent SSO: the SDK never navigates the tab on its own.
 * - Native: shared Keychain / app-group identity (Commons)
 * - Realtime sync: Socket.IO `session_state` on `device:<deviceId>` once authenticated
 * - Manual sign-in: signIn() opens the in-app account dialog (web + native)
 */
import { useOxyAuthActions } from '../context/OxyContext.js';
import type { User } from '@oxy.so/core';
export interface AuthState {
    /** Current authenticated user, null if not authenticated */
    user: User | null;
    /** Whether user is authenticated */
    isAuthenticated: boolean;
    /** Whether auth state is being determined (initial load) */
    isLoading: boolean;
    /** Whether the auth token is ready for API calls */
    isReady: boolean;
    /** Whether the current OxyServices instance currently holds an access token */
    hasAccessToken: boolean;
    /**
     * True only when auth cold-boot is resolved, the user is authenticated, and a
     * bearer token is available for private backend requests.
     */
    canUsePrivateApi: boolean;
    /**
     * True while the SDK is still resolving auth or an authenticated session is
     * waiting for its bearer token. Use this to hold private API screens in a
     * loading state instead of firing unauthenticated requests.
     */
    isPrivateApiPending: boolean;
    /**
     * Whether the initial auth determination has concluded.
     *
     * `false` from mount until the first cold-boot session restore finishes;
     * while `false`, `isAuthenticated: false` is UNDETERMINED (not a definitive
     * "logged out"). Flips to `true` once — when a session is committed or none
     * is found — and never reverts. Defer the first auth-dependent fetch until
     * this is `true` so a cold-boot reload with an existing session does not load
     * anonymous data.
     */
    isAuthResolved: boolean;
    /** Current error message, if any */
    error: string | null;
}
export interface AuthActions {
    /**
     * Sign in
     * - Web + native: opens the in-app Oxy account dialog (`openAccountDialog('signin')`).
     *   Never navigates to auth.oxy.so — that origin is third-party OAuth only.
     *
     * @param publicKey - Native: identity public key. Ignored on web.
     */
    signIn: (publicKey?: string) => Promise<SignInOutcome>;
    /**
     * Sign out current session
     */
    signOut: () => Promise<void>;
    /**
     * Sign out all sessions across all devices
     */
    signOutAll: () => Promise<void>;
    /**
     * Refresh auth state (re-check session validity)
     */
    refresh: () => Promise<void>;
}
export interface UseAuthReturn extends AuthState, AuthActions {
    /** Access to full OxyServices instance for advanced usage */
    oxyServices: ReturnType<typeof useOxyAuthActions>['oxyServices'];
    /** Switch the device session to another account on this device */
    switchToAccount: ReturnType<typeof useOxyAuthActions>['switchToAccount'];
    /** Open a bottom sheet screen (e.g. 'ManageAccount', 'FileManagement') */
    showBottomSheet: ReturnType<typeof useOxyAuthActions>['showBottomSheet'];
    /** Open the avatar picker bottom sheet */
    openAvatarPicker: ReturnType<typeof useOxyAuthActions>['openAvatarPicker'];
}
export type SignInOutcome = {
    status: 'authenticated';
    user: User;
} | {
    status: 'dialog-opened';
};
/**
 * Unified auth hook for all Oxy apps
 *
 * Features:
 * - Zero config: Just wrap with OxyProvider and use
 * - Cross-platform: Same API on native and web
 * - Auto session restore: device-first cold boot (`deviceId` + `deviceSecret` mint);
 *   never auto-redirects to the IdP
 * - Type-safe: Full TypeScript support
 */
export declare function useAuth(): UseAuthReturn;
//# sourceMappingURL=useAuth.d.ts.map