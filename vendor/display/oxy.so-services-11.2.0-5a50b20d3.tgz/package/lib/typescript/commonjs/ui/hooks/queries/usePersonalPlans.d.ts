/** Public discovery; deliberately outside persisted customer payment queries. */
export declare function usePersonalPlans(): import("@tanstack/react-query").UseQueryResult<{
    schemaVersion: 1;
    state: "unconfigured" | "configured";
    purchase: "unavailable" | "available";
    plans: {
        offerId: string;
        offerVersion: number;
        displayName: string;
        audience: "personal";
        kind: "oxy_one";
        benefits: {
            displayName: string;
            benefit: {
                kind: "capability";
                productId: string;
                key: string;
            } | {
                kind: "quota";
                productId: string;
                key: string;
                unit: string;
                included: number;
                combination: "maximum" | "sum" | "exclusive";
            };
        }[];
        price?: {
            currency: string;
            amountMinorUnits: number;
            interval: "month";
            trial: "none";
            taxTreatment: "inclusive";
            merchantTotal: "final";
        } | undefined;
    }[];
}, Error>;
/** Account and session partitioning plus a server-side expected-subject fence. */
export declare function usePersonalPlanSubscriptions(): import("@tanstack/react-query").UseQueryResult<{
    sourceId: string;
    status: "active" | "trialing" | "past_due" | "unpaid" | "canceled" | "paused" | "incomplete" | "incomplete_expired";
    period: {
        start: string;
        end: string;
    };
    cancelAtPeriodEnd: boolean;
    canCancel: boolean;
    offers: {
        period: {
            start: string;
            end: string;
        };
        segmentId: string;
        offerId: string;
        offerVersion: number;
        displayName: string;
        origin: "individual" | "bundle";
        current: boolean;
        products: {
            displayName: string;
            id: string;
        }[];
    }[];
    canRenew?: boolean | undefined;
}[], Error>;
//# sourceMappingURL=usePersonalPlans.d.ts.map