import type { AssetMetadata, AssetUploadInput, NotificationPreferences, PrivacySettings, User, UserPreferences } from '@oxy.so/core';
/**
 * Update user profile with optimistic updates and offline queue support
 */
export declare const useUpdateProfile: () => import("@tanstack/react-query").UseMutationResult<User, Error, import("zod").objectOutputType<{
    name: import("zod").ZodOptional<import("zod").ZodObject<{
        first: import("zod").ZodOptional<import("zod").ZodString>;
        last: import("zod").ZodOptional<import("zod").ZodString>;
        displayName: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        first?: string | undefined;
        last?: string | undefined;
        displayName?: string | undefined;
    }, {
        first?: string | undefined;
        last?: string | undefined;
        displayName?: string | undefined;
    }>>;
    username: import("zod").ZodOptional<import("zod").ZodString>;
    email: import("zod").ZodOptional<import("zod").ZodString>;
    avatar: import("zod").ZodOptional<import("zod").ZodString>;
    color: import("zod").ZodOptional<import("zod").ZodNullable<import("zod").ZodString>>;
    bio: import("zod").ZodOptional<import("zod").ZodString>;
    description: import("zod").ZodOptional<import("zod").ZodString>;
    phone: import("zod").ZodOptional<import("zod").ZodString>;
    address: import("zod").ZodOptional<import("zod").ZodString>;
    birthday: import("zod").ZodOptional<import("zod").ZodString>;
    dateOfBirth: import("zod").ZodOptional<import("zod").ZodNullable<import("zod").ZodEffects<import("zod").ZodEffects<import("zod").ZodEffects<import("zod").ZodString, string, string>, string, string>, string, string>>>;
    locations: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodUnknown, "many">>;
    links: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodString, "many">>;
    linksMetadata: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        url: import("zod").ZodString;
        title: import("zod").ZodOptional<import("zod").ZodString>;
        description: import("zod").ZodOptional<import("zod").ZodString>;
        image: import("zod").ZodOptional<import("zod").ZodString>;
        id: import("zod").ZodOptional<import("zod").ZodString>;
    }, "strip", import("zod").ZodTypeAny, {
        url: string;
        description?: string | undefined;
        id?: string | undefined;
        title?: string | undefined;
        image?: string | undefined;
    }, {
        url: string;
        description?: string | undefined;
        id?: string | undefined;
        title?: string | undefined;
        image?: string | undefined;
    }>, "many">>;
    languages: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodString, "many">>;
    accountExpiresAfterInactivityDays: import("zod").ZodOptional<import("zod").ZodNullable<import("zod").ZodNumber>>;
    notificationPreferences: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnknown>>;
    userPreferences: import("zod").ZodOptional<import("zod").ZodObject<{
        displayCurrency: import("zod").ZodOptional<import("zod").ZodEnum<["USD", "EUR", "FAIR"]>>;
    }, "strip", import("zod").ZodUnknown, import("zod").objectOutputType<{
        displayCurrency: import("zod").ZodOptional<import("zod").ZodEnum<["USD", "EUR", "FAIR"]>>;
    }, import("zod").ZodUnknown, "strip">, import("zod").objectInputType<{
        displayCurrency: import("zod").ZodOptional<import("zod").ZodEnum<["USD", "EUR", "FAIR"]>>;
    }, import("zod").ZodUnknown, "strip">>>;
    privacySettings: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodUnknown>>;
    themePreference: import("zod").ZodOptional<import("zod").ZodType<import("@oxy.so/contracts").ThemePreference, import("zod").ZodTypeDef, import("@oxy.so/contracts").ThemePreference>>;
}, import("zod").ZodTypeAny, "passthrough">, {
    previousUser: User | undefined;
}>;
/**
 * Upload avatar with progress tracking and offline queue support
 */
export declare const useUploadAvatar: () => import("@tanstack/react-query").UseMutationResult<User, Error, {
    uri: string;
    type?: string;
    name?: string;
    size?: number;
}, {
    previousUser: User | undefined;
}>;
/**
 * Variables accepted by the `useUpdateAccountSettings` mutation.
 *
 * `currentUser` is captured at dispatch time so the rebuilt user object the
 * mutation returns is computed against a stable snapshot — NOT the cache
 * value at the moment the API call settles. Reading from the cache inside
 * `mutationFn` would race with sibling optimistic updates: a concurrent
 * write could already have overwritten the cache by the time the privacy
 * update returns, causing the rebuilt user to clobber the sibling's
 * optimistic value.
 */
interface UpdateAccountSettingsVariables {
    /** Subset of privacy fields to write. */
    updates: Partial<PrivacySettings>;
    /**
     * The User snapshot captured at mutation dispatch time. The mutation
     * rebuilds this user with the updated `privacySettings` and returns it
     * to `onSuccess`. Required to avoid the race described above.
     */
    currentUser: User;
}
/**
 * Update account settings (privacy preferences).
 *
 * Privacy settings are not part of the `PUT /users/me` allow-list; the API
 * would silently drop them. Route through `updatePrivacySettings` so the
 * dedicated `PATCH /privacy/:id/privacy` endpoint performs a dot-path merge
 * and returns the updated `privacySettings` object.
 *
 * The returned object exposes the standard mutation surface PLUS a
 * convenience `mutate(updates)` / `mutateAsync(updates)` that snapshots
 * the current user from `useOxy()` at dispatch time. Callers that need to
 * supply their own user snapshot (testing, server-side) can call the
 * underlying `.mutate({ updates, currentUser })` form via `.mutation`.
 */
export declare const useUpdateAccountSettings: () => {
    mutate: (updates: Partial<PrivacySettings>) => void;
    mutateAsync: (updates: Partial<PrivacySettings>) => Promise<User>;
    data: undefined;
    variables: undefined;
    error: null;
    isError: false;
    isIdle: true;
    isPending: false;
    isSuccess: false;
    status: "idle";
    reset: () => void;
    context: {
        previousUser: User | undefined;
    } | undefined;
    failureCount: number;
    failureReason: Error | null;
    isPaused: boolean;
    submittedAt: number;
} | {
    mutate: (updates: Partial<PrivacySettings>) => void;
    mutateAsync: (updates: Partial<PrivacySettings>) => Promise<User>;
    data: undefined;
    variables: UpdateAccountSettingsVariables;
    error: null;
    isError: false;
    isIdle: false;
    isPending: true;
    isSuccess: false;
    status: "pending";
    reset: () => void;
    context: {
        previousUser: User | undefined;
    } | undefined;
    failureCount: number;
    failureReason: Error | null;
    isPaused: boolean;
    submittedAt: number;
} | {
    mutate: (updates: Partial<PrivacySettings>) => void;
    mutateAsync: (updates: Partial<PrivacySettings>) => Promise<User>;
    data: undefined;
    error: Error;
    variables: UpdateAccountSettingsVariables;
    isError: true;
    isIdle: false;
    isPending: false;
    isSuccess: false;
    status: "error";
    reset: () => void;
    context: {
        previousUser: User | undefined;
    } | undefined;
    failureCount: number;
    failureReason: Error | null;
    isPaused: boolean;
    submittedAt: number;
} | {
    mutate: (updates: Partial<PrivacySettings>) => void;
    mutateAsync: (updates: Partial<PrivacySettings>) => Promise<User>;
    data: {
        privacySettings: PrivacySettings;
        id: string;
        publicKey: string;
        username: string;
        email?: string;
        avatar?: string | null;
        color?: string | null;
        name: import("@oxy.so/contracts").UserNameResponse;
        bio?: string;
        description?: string;
        alsoKnownAs?: string[];
        phone?: string;
        address?: string;
        birthday?: string;
        dateOfBirth?: string | null;
        isAdult?: boolean;
        website?: string;
        createdAt?: string;
        updatedAt?: string;
        links?: string[];
        linksMetadata?: Array<{
            url: string;
            title?: string;
            description?: string;
            image?: string;
            id?: string;
        }>;
        _count?: {
            followers?: number;
            following?: number;
        };
        accountExpiresAfterInactivityDays?: number | null;
        kind?: import("@oxy.so/contracts").AccountKind;
        type?: "local" | "federated" | "agent" | "automated";
        isFederated?: boolean;
        fediverseSharing?: boolean;
        isAgent?: boolean;
        isAutomated?: boolean;
        instance?: string;
        federation?: {
            actorUri?: string;
            domain?: string;
            actorId?: string;
        };
        automation?: {
            ownerId?: string;
        };
        isManagedAccount?: boolean;
        managedBy?: string;
        accountCategories?: import("@oxy.so/contracts").AccountCategoryId[];
        languages?: string[];
        notificationPreferences?: NotificationPreferences;
        userPreferences?: UserPreferences;
        themePreference?: import("@oxy.so/contracts").ThemePreference;
        personalization?: {
            mentionMono: {
                allowed: boolean;
                expiresAt: string | null;
            };
        };
        relationship?: import("@oxy.so/contracts").UserRelationship;
    };
    error: null;
    variables: UpdateAccountSettingsVariables;
    isError: false;
    isIdle: false;
    isPending: false;
    isSuccess: true;
    status: "success";
    reset: () => void;
    context: {
        previousUser: User | undefined;
    } | undefined;
    failureCount: number;
    failureReason: Error | null;
    isPaused: boolean;
    submittedAt: number;
};
/**
 * Update privacy settings with optimistic updates and authentication handling
 */
export declare const useUpdatePrivacySettings: () => import("@tanstack/react-query").UseMutationResult<PrivacySettings, Error, {
    settings: Partial<PrivacySettings>;
    userId?: string;
}, {
    previousPrivacySettings: unknown;
    previousUser: User | undefined;
} | undefined>;
/** Uploaded file data structure from API */
interface UploadedFile {
    id: string;
    originalName?: string;
    sha256?: string;
    mime?: string;
    size?: number;
    createdAt?: string;
    metadata?: Record<string, unknown>;
    variants?: Array<{
        type: string;
        key: string;
        width?: number;
        height?: number;
        readyAt?: string;
        metadata?: Record<string, unknown>;
    }>;
}
/** Upload result type that supports both single file and batch responses */
interface UploadResult {
    file?: UploadedFile;
    files?: UploadedFile[];
    id?: string;
}
/**
 * Update the authenticated user's notification preferences with optimistic
 * updates. Persisted on the User document via `PUT /users/me` — same cache-
 * invalidation behaviour as `useUpdateProfile`.
 */
export declare const useUpdateNotificationPreferences: () => import("@tanstack/react-query").UseMutationResult<User, Error, Partial<NotificationPreferences>, {
    previousUser: User | undefined;
}>;
/**
 * Update the authenticated user's general preferences (language, theme,
 * reduce-motion, timezone). Persisted on the User document via
 * `PUT /users/me`.
 */
export declare const useUpdateUserPreferences: () => import("@tanstack/react-query").UseMutationResult<User, Error, Partial<UserPreferences>, {
    previousUser: User | undefined;
}>;
/**
 * Revoke the current user's grant for a connected application (by its
 * `applicationId`). Removes the grant so the app no longer appears in the user's
 * "Connected apps" list — next sign-in for that app will require explicit
 * re-consent.
 */
export declare const useRevokeConnectedApp: () => import("@tanstack/react-query").UseMutationResult<void, Error, string, unknown>;
/**
 * Upload file with authentication handling and progress tracking
 */
export declare const useUploadFile: () => import("@tanstack/react-query").UseMutationResult<UploadResult, Error, {
    file: AssetUploadInput;
    visibility?: "private" | "public" | "unlisted";
    metadata?: AssetMetadata;
    onProgress?: (progress: number) => void;
}, unknown>;
export {};
//# sourceMappingURL=useAccountMutations.d.ts.map